"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "QueryManager", {
  enumerable: true,
  get: function () {
    return _ppl_query_manager.QueryManager;
  }
});
var _ppl_query_manager = require("./ppl_query_manager");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcHBsX3F1ZXJ5X21hbmFnZXIiLCJyZXF1aXJlIl0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5leHBvcnQgeyBRdWVyeU1hbmFnZXIgfSBmcm9tICcuL3BwbF9xdWVyeV9tYW5hZ2VyJztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFLQSxJQUFBQSxrQkFBQSxHQUFBQyxPQUFBIn0=