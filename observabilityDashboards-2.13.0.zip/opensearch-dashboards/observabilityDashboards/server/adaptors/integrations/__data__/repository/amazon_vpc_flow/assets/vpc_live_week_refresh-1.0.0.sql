REFRESH MATERIALIZED VIEW {table_name}__week_live_mview
