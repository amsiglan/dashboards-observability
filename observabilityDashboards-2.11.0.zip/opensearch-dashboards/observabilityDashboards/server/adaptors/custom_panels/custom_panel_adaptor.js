"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CustomPanelsAdaptor = void 0;
var _uuid = require("uuid");
var _custom_panels = require("../../../common/constants/custom_panels");
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); } /*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomPanelsAdaptor {
  constructor() {
    // index a panel
    _defineProperty(this, "indexPanel", async function (client, panelBody) {
      try {
        const response = await client.callAsCurrentUser('observability.createObject', {
          body: {
            operationalPanel: panelBody
          }
        });
        return response;
      } catch (error) {
        throw new Error('Index Panel Error:' + error);
      }
    });
    // update a panel
    _defineProperty(this, "updatePanel", async function (client, panelId, updatePanelBody) {
      try {
        const response = await client.callAsCurrentUser('observability.updateObjectById', {
          objectId: panelId,
          body: {
            operationalPanel: updatePanelBody
          }
        });
        return response;
      } catch (error) {
        throw new Error('Update Panel Error:' + error);
      }
    });
    // fetch a panel by id
    _defineProperty(this, "getPanel", async function (client, panelId) {
      try {
        const response = await client.callAsCurrentUser('observability.getObjectById', {
          objectId: panelId
        });
        return response.observabilityObjectList[0];
      } catch (error) {
        throw new Error('Get Panel Error:' + error);
      }
    });
    // gets list of panels stored in index
    _defineProperty(this, "viewPanelList", async function (client) {
      try {
        const response = await client.callAsCurrentUser('observability.getObject', {
          objectType: 'operationalPanel',
          maxItems: 10000
        });
        return response.observabilityObjectList.filter(panel => !panel.operationalPanel.applicationId).map(panel => ({
          name: panel.operationalPanel.name,
          id: panel.objectId,
          dateCreated: panel.createdTimeMs,
          dateModified: panel.lastUpdatedTimeMs
        }));
      } catch (error) {
        throw new Error('View Panel List Error:' + error);
      }
    });
    // Delete a panel by Id
    _defineProperty(this, "deletePanel", async function (client, panelId) {
      try {
        const response = await client.callAsCurrentUser('observability.deleteObjectById', {
          objectId: panelId
        });
        return {
          status: 'OK',
          message: response
        };
      } catch (error) {
        throw new Error('Delete Panel Error:' + error);
      }
    });
    // Delete a panel by Id
    _defineProperty(this, "deletePanelList", async function (client, panelIdList) {
      try {
        const response = await client.callAsCurrentUser('observability.deleteObjectByIdList', {
          objectIdList: panelIdList
        });
        return {
          status: 'OK',
          message: response
        };
      } catch (error) {
        throw new Error('Delete Panel List Error:' + error);
      }
    });
    // Create a new Panel
    _defineProperty(this, "createNewPanel", async (client, panelName, appId) => {
      const panelBody = {
        name: panelName,
        visualizations: [],
        timeRange: {
          to: 'now',
          from: 'now-1d'
        },
        queryFilter: {
          query: '',
          language: 'ppl'
        }
      };
      if (appId) {
        panelBody.applicationId = appId;
        panelBody.timeRange = {
          to: 'now',
          from: 'now-24h'
        };
      }
      try {
        const response = await this.indexPanel(client, panelBody);
        return response.objectId;
      } catch (error) {
        throw new Error('Create Panel Error:' + error);
      }
    });
    // Rename an existing panel
    _defineProperty(this, "renamePanel", async (client, panelId, panelName) => {
      const updatePanelBody = {
        name: panelName
      };
      try {
        const response = await this.updatePanel(client, panelId, updatePanelBody);
        return response.objectId;
      } catch (error) {
        throw new Error('Rename Panel Error:' + error);
      }
    });
    // Clone an existing panel
    _defineProperty(this, "clonePanel", async (client, panelId, panelName) => {
      const updatePanelBody = {
        name: panelName
      };
      try {
        const getPanel = await this.getPanel(client, panelId);
        const clonePanelBody = {
          name: panelName,
          visualizations: getPanel.operationalPanel.visualizations,
          timeRange: getPanel.operationalPanel.timeRange,
          queryFilter: getPanel.operationalPanel.queryFilter
        };
        const indexResponse = await this.indexPanel(client, clonePanelBody);
        const getClonedPanel = await this.getPanel(client, indexResponse.objectId);
        return {
          clonePanelId: getClonedPanel.objectId,
          dateCreated: getClonedPanel.createdTimeMs,
          dateModified: getClonedPanel.lastUpdatedTimeMs
        };
      } catch (error) {
        throw new Error('Clone Panel Error:' + error);
      }
    });
    // Add filters to an existing panel
    _defineProperty(this, "addPanelFilter", async (client, panelId, query, language, to, from) => {
      const updatePanelBody = {
        timeRange: {
          to,
          from
        },
        queryFilter: {
          query,
          language
        }
      };
      try {
        const response = await this.updatePanel(client, panelId, updatePanelBody);
        return response.objectId;
      } catch (error) {
        throw new Error('Add Panel Filter Error:' + error);
      }
    });
    // parses fetched saved visualization
    _defineProperty(this, "parseSavedVisualizations", visualization => {
      return {
        id: visualization.objectId,
        name: visualization.savedVisualization.name,
        query: visualization.savedVisualization.query,
        type: visualization.savedVisualization.type,
        timeField: visualization.savedVisualization.selected_timestamp.name,
        selected_date_range: visualization.savedVisualization.selected_date_range,
        selected_fields: visualization.savedVisualization.selected_fields,
        user_configs: visualization.savedVisualization.hasOwnProperty('user_configs') ? JSON.parse(visualization.savedVisualization.user_configs) : {},
        sub_type: visualization.savedVisualization.hasOwnProperty('sub_type') ? visualization.savedVisualization.sub_type : '',
        units_of_measure: visualization.savedVisualization.hasOwnProperty('units_of_measure') ? visualization.savedVisualization.units_of_measure : '',
        ...(visualization.savedVisualization.application_id ? {
          application_id: visualization.savedVisualization.application_id
        } : {})
      };
    });
    // gets all saved visualizations
    _defineProperty(this, "getAllSavedVisualizations", async client => {
      try {
        const response = await client.callAsCurrentUser('observability.getObject', {
          objectType: 'savedVisualization'
        });
        return response.observabilityObjectList.map(visualization => this.parseSavedVisualizations(visualization));
      } catch (error) {
        throw new Error('View Saved Visualizations Error:' + error);
      }
    });
    // gets list of savedVisualizations by Id
    _defineProperty(this, "getSavedVisualizationById", async (client, savedVisualizationId) => {
      try {
        const response = await client.callAsCurrentUser('observability.getObjectById', {
          objectId: savedVisualizationId
        });
        const visualization = response.observabilityObjectList[0];
        return this.parseSavedVisualizations(visualization);
      } catch (error) {
        throw new Error('Fetch Saved Visualizations By Id Error:' + error);
      }
    });
    // Get All Visualizations from a Panel
    _defineProperty(this, "getVisualizations", async (client, panelId) => {
      try {
        const response = await client.callAsCurrentUser('observability.getObjectById', {
          objectId: panelId
        });
        return response.observabilityObjectList[0].operationalPanel.visualizations;
      } catch (error) {
        throw new Error('Get Visualizations Error:' + error);
      }
    });
    _defineProperty(this, "calculatOverlapArea", (bb1, bb2) => {
      const xLeft = Math.max(bb1.x1, bb2.x1);
      const yTop = Math.max(bb1.y1, bb2.y1);
      const xRight = Math.min(bb1.x2, bb2.x2);
      const yBottom = Math.min(bb1.y2, bb2.y2);
      if (xRight < xLeft || yBottom < yTop) return 0;
      return (xRight - xLeft) * (yBottom - yTop);
    });
    _defineProperty(this, "getTotalOverlapArea", panelVisualizations => {
      const newVizBox = {
        x1: 0,
        y1: 0,
        x2: 6,
        y2: 4
      };
      const currentVizBoxes = panelVisualizations.map(visualization => {
        return {
          x1: visualization.x,
          y1: visualization.y,
          x2: visualization.x + visualization.w,
          y2: visualization.y + visualization.h
        };
      });
      let isOverlapping = 0;
      currentVizBoxes.map(viz => {
        isOverlapping += this.calculatOverlapArea(viz, newVizBox);
      });
      return isOverlapping;
    });
    // We want to check if the new visualization being added, can be placed at { x: 0, y: 0, w: 6, h: 4 };
    // To check this we try to calculate overlap between all the current visualizations and new visualization
    // if there is no overalap (i.e Total Overlap Area is 0), we place the new viz. in default position
    // else, we add it to the bottom of the panel
    _defineProperty(this, "getNewVizDimensions", panelVisualizations => {
      let maxY = 0;
      let maxYH = 0;

      // check if we can place the new visualization at default location
      if (this.getTotalOverlapArea(panelVisualizations) === 0) {
        return {
          x: 0,
          y: 0,
          w: 6,
          h: 4
        };
      }

      // else place the new visualization at the bottom of the panel
      panelVisualizations.map(panelVisualization => {
        if (panelVisualization.y >= maxY) {
          maxY = panelVisualization.y;
          maxYH = panelVisualization.h;
        }
      });
      return {
        x: 0,
        y: maxY + maxYH,
        w: 6,
        h: 4
      };
    });
    // Add Visualization in the  Panel
    _defineProperty(this, "addVisualization", async (client, panelId, savedVisualizationId, oldVisualizationId) => {
      try {
        const allPanelVisualizations = await this.getVisualizations(client, panelId);
        let newDimensions;
        let visualizationsList = [];
        if (oldVisualizationId === undefined) {
          newDimensions = this.getNewVizDimensions(allPanelVisualizations);
          visualizationsList = allPanelVisualizations;
        } else {
          allPanelVisualizations.map(visualization => {
            if (visualization.id !== oldVisualizationId) {
              visualizationsList.push(visualization);
            } else {
              newDimensions = {
                x: visualization.x,
                y: visualization.y,
                w: visualization.w,
                h: visualization.h
              };
            }
          });
        }
        const newPanelVisualizations = [...visualizationsList, {
          id: 'panel_viz_' + (0, _uuid.v4)(),
          savedVisualizationId,
          ...newDimensions
        }];
        const updatePanelResponse = await this.updatePanel(client, panelId, {
          visualizations: newPanelVisualizations
        });
        return newPanelVisualizations;
      } catch (error) {
        throw new Error('Add/Replace Visualization Error:' + error);
      }
    });
    // Add Multiple visualizations in a Panel
    _defineProperty(this, "addMultipleVisualizations", async (client, panelId, savedVisualizationIds) => {
      try {
        const allPanelVisualizations = await this.getVisualizations(client, panelId);
        let newDimensions;
        let visualizationsList = [...allPanelVisualizations];
        savedVisualizationIds.map(savedVisualizationId => {
          newDimensions = this.getNewVizDimensions(visualizationsList);
          visualizationsList = [...visualizationsList, {
            id: 'panel_viz_' + (0, _uuid.v4)(),
            savedVisualizationId,
            ...newDimensions
          }];
        });
        const updatePanelResponse = await this.updatePanel(client, panelId, {
          visualizations: visualizationsList
        });
        return visualizationsList;
      } catch (error) {
        throw new Error('Add/Replace Visualization Error:' + error);
      }
    });
    // Edits all Visualizations in the Panel
    _defineProperty(this, "editVisualization", async (client, panelId, visualizationParams) => {
      try {
        const allPanelVisualizations = await this.getVisualizations(client, panelId);
        const filteredPanelVisualizations = [];
        for (let i = 0; i < allPanelVisualizations.length; i++) {
          for (let j = 0; j < visualizationParams.length; j++) {
            if (allPanelVisualizations[i].id === visualizationParams[j].i) {
              filteredPanelVisualizations.push({
                ...allPanelVisualizations[i],
                x: visualizationParams[j].x,
                y: visualizationParams[j].y,
                w: visualizationParams[j].w,
                h: visualizationParams[j].h
              });
            }
          }
        }
        const updatePanelResponse = await this.updatePanel(client, panelId, {
          visualizations: filteredPanelVisualizations
        });
        return filteredPanelVisualizations;
      } catch (error) {
        throw new Error('Edit Visualizations Error:' + error);
      }
    });
    // Create Sample Panels
    _defineProperty(this, "addSamplePanels", async (client, savedVisualizationIds) => {
      try {
        const panelBody = (0, _custom_panels.createDemoPanel)(savedVisualizationIds);
        const indexResponse = await this.indexPanel(client, panelBody);
        const fetchPanel = await this.getPanel(client, indexResponse.objectId);
        const fetchResponse = {
          name: fetchPanel.operationalPanel.name,
          id: fetchPanel.objectId,
          dateCreated: fetchPanel.createdTimeMs,
          dateModified: fetchPanel.lastUpdatedTimeMs
        };
        return [fetchResponse];
      } catch (error) {
        throw new Error('Create Panel Error:' + error);
      }
    });
  }
}
exports.CustomPanelsAdaptor = CustomPanelsAdaptor;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdXVpZCIsInJlcXVpcmUiLCJfY3VzdG9tX3BhbmVscyIsIl9kZWZpbmVQcm9wZXJ0eSIsIm9iaiIsImtleSIsInZhbHVlIiwiX3RvUHJvcGVydHlLZXkiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJ3cml0YWJsZSIsImFyZyIsIl90b1ByaW1pdGl2ZSIsIlN0cmluZyIsImlucHV0IiwiaGludCIsInByaW0iLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsInVuZGVmaW5lZCIsInJlcyIsImNhbGwiLCJUeXBlRXJyb3IiLCJOdW1iZXIiLCJDdXN0b21QYW5lbHNBZGFwdG9yIiwiY29uc3RydWN0b3IiLCJjbGllbnQiLCJwYW5lbEJvZHkiLCJyZXNwb25zZSIsImNhbGxBc0N1cnJlbnRVc2VyIiwiYm9keSIsIm9wZXJhdGlvbmFsUGFuZWwiLCJlcnJvciIsIkVycm9yIiwicGFuZWxJZCIsInVwZGF0ZVBhbmVsQm9keSIsIm9iamVjdElkIiwib2JzZXJ2YWJpbGl0eU9iamVjdExpc3QiLCJvYmplY3RUeXBlIiwibWF4SXRlbXMiLCJmaWx0ZXIiLCJwYW5lbCIsImFwcGxpY2F0aW9uSWQiLCJtYXAiLCJuYW1lIiwiaWQiLCJkYXRlQ3JlYXRlZCIsImNyZWF0ZWRUaW1lTXMiLCJkYXRlTW9kaWZpZWQiLCJsYXN0VXBkYXRlZFRpbWVNcyIsInN0YXR1cyIsIm1lc3NhZ2UiLCJwYW5lbElkTGlzdCIsIm9iamVjdElkTGlzdCIsInBhbmVsTmFtZSIsImFwcElkIiwidmlzdWFsaXphdGlvbnMiLCJ0aW1lUmFuZ2UiLCJ0byIsImZyb20iLCJxdWVyeUZpbHRlciIsInF1ZXJ5IiwibGFuZ3VhZ2UiLCJpbmRleFBhbmVsIiwidXBkYXRlUGFuZWwiLCJnZXRQYW5lbCIsImNsb25lUGFuZWxCb2R5IiwiaW5kZXhSZXNwb25zZSIsImdldENsb25lZFBhbmVsIiwiY2xvbmVQYW5lbElkIiwidmlzdWFsaXphdGlvbiIsInNhdmVkVmlzdWFsaXphdGlvbiIsInR5cGUiLCJ0aW1lRmllbGQiLCJzZWxlY3RlZF90aW1lc3RhbXAiLCJzZWxlY3RlZF9kYXRlX3JhbmdlIiwic2VsZWN0ZWRfZmllbGRzIiwidXNlcl9jb25maWdzIiwiaGFzT3duUHJvcGVydHkiLCJKU09OIiwicGFyc2UiLCJzdWJfdHlwZSIsInVuaXRzX29mX21lYXN1cmUiLCJhcHBsaWNhdGlvbl9pZCIsInBhcnNlU2F2ZWRWaXN1YWxpemF0aW9ucyIsInNhdmVkVmlzdWFsaXphdGlvbklkIiwiYmIxIiwiYmIyIiwieExlZnQiLCJNYXRoIiwibWF4IiwieDEiLCJ5VG9wIiwieTEiLCJ4UmlnaHQiLCJtaW4iLCJ4MiIsInlCb3R0b20iLCJ5MiIsInBhbmVsVmlzdWFsaXphdGlvbnMiLCJuZXdWaXpCb3giLCJjdXJyZW50Vml6Qm94ZXMiLCJ4IiwieSIsInciLCJoIiwiaXNPdmVybGFwcGluZyIsInZpeiIsImNhbGN1bGF0T3ZlcmxhcEFyZWEiLCJtYXhZIiwibWF4WUgiLCJnZXRUb3RhbE92ZXJsYXBBcmVhIiwicGFuZWxWaXN1YWxpemF0aW9uIiwib2xkVmlzdWFsaXphdGlvbklkIiwiYWxsUGFuZWxWaXN1YWxpemF0aW9ucyIsImdldFZpc3VhbGl6YXRpb25zIiwibmV3RGltZW5zaW9ucyIsInZpc3VhbGl6YXRpb25zTGlzdCIsImdldE5ld1ZpekRpbWVuc2lvbnMiLCJwdXNoIiwibmV3UGFuZWxWaXN1YWxpemF0aW9ucyIsInV1aWR2NCIsInVwZGF0ZVBhbmVsUmVzcG9uc2UiLCJzYXZlZFZpc3VhbGl6YXRpb25JZHMiLCJ2aXN1YWxpemF0aW9uUGFyYW1zIiwiZmlsdGVyZWRQYW5lbFZpc3VhbGl6YXRpb25zIiwiaSIsImxlbmd0aCIsImoiLCJjcmVhdGVEZW1vUGFuZWwiLCJmZXRjaFBhbmVsIiwiZmV0Y2hSZXNwb25zZSIsImV4cG9ydHMiXSwic291cmNlcyI6WyJjdXN0b21fcGFuZWxfYWRhcHRvci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gJ3V1aWQnO1xuaW1wb3J0IHsgUGFuZWxUeXBlLCBWaXN1YWxpemF0aW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uL2NvbW1vbi90eXBlcy9jdXN0b21fcGFuZWxzJztcbmltcG9ydCB7IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IGNyZWF0ZURlbW9QYW5lbCB9IGZyb20gJy4uLy4uLy4uL2NvbW1vbi9jb25zdGFudHMvY3VzdG9tX3BhbmVscyc7XG5cbmludGVyZmFjZSBCb3hUeXBlIHtcbiAgeDE6IG51bWJlcjtcbiAgeTE6IG51bWJlcjtcbiAgeDI6IG51bWJlcjtcbiAgeTI6IG51bWJlcjtcbn1cblxuZXhwb3J0IGNsYXNzIEN1c3RvbVBhbmVsc0FkYXB0b3Ige1xuICAvLyBpbmRleCBhIHBhbmVsXG4gIGluZGV4UGFuZWwgPSBhc3luYyBmdW5jdGlvbiAoXG4gICAgY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCxcbiAgICBwYW5lbEJvZHk6IFBhbmVsVHlwZVxuICApOiBQcm9taXNlPHsgb2JqZWN0SWQ6IHN0cmluZyB9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvYnNlcnZhYmlsaXR5LmNyZWF0ZU9iamVjdCcsIHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9wZXJhdGlvbmFsUGFuZWw6IHBhbmVsQm9keSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0luZGV4IFBhbmVsIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8vIHVwZGF0ZSBhIHBhbmVsXG4gIHVwZGF0ZVBhbmVsID0gYXN5bmMgZnVuY3Rpb24gKFxuICAgIGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQsXG4gICAgcGFuZWxJZDogc3RyaW5nLFxuICAgIHVwZGF0ZVBhbmVsQm9keTogUGFydGlhbDxQYW5lbFR5cGU+XG4gICkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb2JzZXJ2YWJpbGl0eS51cGRhdGVPYmplY3RCeUlkJywge1xuICAgICAgICBvYmplY3RJZDogcGFuZWxJZCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIG9wZXJhdGlvbmFsUGFuZWw6IHVwZGF0ZVBhbmVsQm9keSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VwZGF0ZSBQYW5lbCBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvLyBmZXRjaCBhIHBhbmVsIGJ5IGlkXG4gIGdldFBhbmVsID0gYXN5bmMgZnVuY3Rpb24gKGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQsIHBhbmVsSWQ6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb2JzZXJ2YWJpbGl0eS5nZXRPYmplY3RCeUlkJywge1xuICAgICAgICBvYmplY3RJZDogcGFuZWxJZCxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9ic2VydmFiaWxpdHlPYmplY3RMaXN0WzBdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0dldCBQYW5lbCBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvLyBnZXRzIGxpc3Qgb2YgcGFuZWxzIHN0b3JlZCBpbiBpbmRleFxuICB2aWV3UGFuZWxMaXN0ID0gYXN5bmMgZnVuY3Rpb24gKGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29ic2VydmFiaWxpdHkuZ2V0T2JqZWN0Jywge1xuICAgICAgICBvYmplY3RUeXBlOiAnb3BlcmF0aW9uYWxQYW5lbCcsXG4gICAgICAgIG1heEl0ZW1zOiAxMDAwMCxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9ic2VydmFiaWxpdHlPYmplY3RMaXN0XG4gICAgICAgIC5maWx0ZXIoKHBhbmVsOiBhbnkpID0+ICFwYW5lbC5vcGVyYXRpb25hbFBhbmVsLmFwcGxpY2F0aW9uSWQpXG4gICAgICAgIC5tYXAoKHBhbmVsOiBhbnkpID0+ICh7XG4gICAgICAgICAgbmFtZTogcGFuZWwub3BlcmF0aW9uYWxQYW5lbC5uYW1lLFxuICAgICAgICAgIGlkOiBwYW5lbC5vYmplY3RJZCxcbiAgICAgICAgICBkYXRlQ3JlYXRlZDogcGFuZWwuY3JlYXRlZFRpbWVNcyxcbiAgICAgICAgICBkYXRlTW9kaWZpZWQ6IHBhbmVsLmxhc3RVcGRhdGVkVGltZU1zLFxuICAgICAgICB9KSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVmlldyBQYW5lbCBMaXN0IEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8vIERlbGV0ZSBhIHBhbmVsIGJ5IElkXG4gIGRlbGV0ZVBhbmVsID0gYXN5bmMgZnVuY3Rpb24gKGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQsIHBhbmVsSWQ6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb2JzZXJ2YWJpbGl0eS5kZWxldGVPYmplY3RCeUlkJywge1xuICAgICAgICBvYmplY3RJZDogcGFuZWxJZCxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHsgc3RhdHVzOiAnT0snLCBtZXNzYWdlOiByZXNwb25zZSB9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0RlbGV0ZSBQYW5lbCBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvLyBEZWxldGUgYSBwYW5lbCBieSBJZFxuICBkZWxldGVQYW5lbExpc3QgPSBhc3luYyBmdW5jdGlvbiAoY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCwgcGFuZWxJZExpc3Q6IHN0cmluZykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb2JzZXJ2YWJpbGl0eS5kZWxldGVPYmplY3RCeUlkTGlzdCcsIHtcbiAgICAgICAgb2JqZWN0SWRMaXN0OiBwYW5lbElkTGlzdCxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHsgc3RhdHVzOiAnT0snLCBtZXNzYWdlOiByZXNwb25zZSB9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0RlbGV0ZSBQYW5lbCBMaXN0IEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8vIENyZWF0ZSBhIG5ldyBQYW5lbFxuICBjcmVhdGVOZXdQYW5lbCA9IGFzeW5jIChcbiAgICBjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LFxuICAgIHBhbmVsTmFtZTogc3RyaW5nLFxuICAgIGFwcElkPzogc3RyaW5nXG4gICkgPT4ge1xuICAgIGNvbnN0IHBhbmVsQm9keTogUGFuZWxUeXBlID0ge1xuICAgICAgbmFtZTogcGFuZWxOYW1lLFxuICAgICAgdmlzdWFsaXphdGlvbnM6IFtdLFxuICAgICAgdGltZVJhbmdlOiB7XG4gICAgICAgIHRvOiAnbm93JyxcbiAgICAgICAgZnJvbTogJ25vdy0xZCcsXG4gICAgICB9LFxuICAgICAgcXVlcnlGaWx0ZXI6IHtcbiAgICAgICAgcXVlcnk6ICcnLFxuICAgICAgICBsYW5ndWFnZTogJ3BwbCcsXG4gICAgICB9LFxuICAgIH07XG4gICAgaWYgKGFwcElkKSB7XG4gICAgICBwYW5lbEJvZHkuYXBwbGljYXRpb25JZCA9IGFwcElkO1xuICAgICAgcGFuZWxCb2R5LnRpbWVSYW5nZSA9IHtcbiAgICAgICAgdG86ICdub3cnLFxuICAgICAgICBmcm9tOiAnbm93LTI0aCcsXG4gICAgICB9O1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMuaW5kZXhQYW5lbChjbGllbnQsIHBhbmVsQm9keSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2JqZWN0SWQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ3JlYXRlIFBhbmVsIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8vIFJlbmFtZSBhbiBleGlzdGluZyBwYW5lbFxuICByZW5hbWVQYW5lbCA9IGFzeW5jIChjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LCBwYW5lbElkOiBzdHJpbmcsIHBhbmVsTmFtZTogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlUGFuZWxCb2R5ID0ge1xuICAgICAgbmFtZTogcGFuZWxOYW1lLFxuICAgIH07XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy51cGRhdGVQYW5lbChjbGllbnQsIHBhbmVsSWQsIHVwZGF0ZVBhbmVsQm9keSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2JqZWN0SWQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignUmVuYW1lIFBhbmVsIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8vIENsb25lIGFuIGV4aXN0aW5nIHBhbmVsXG4gIGNsb25lUGFuZWwgPSBhc3luYyAoY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCwgcGFuZWxJZDogc3RyaW5nLCBwYW5lbE5hbWU6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZVBhbmVsQm9keSA9IHtcbiAgICAgIG5hbWU6IHBhbmVsTmFtZSxcbiAgICB9O1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBnZXRQYW5lbCA9IGF3YWl0IHRoaXMuZ2V0UGFuZWwoY2xpZW50LCBwYW5lbElkKTtcbiAgICAgIGNvbnN0IGNsb25lUGFuZWxCb2R5ID0ge1xuICAgICAgICBuYW1lOiBwYW5lbE5hbWUsXG4gICAgICAgIHZpc3VhbGl6YXRpb25zOiBnZXRQYW5lbC5vcGVyYXRpb25hbFBhbmVsLnZpc3VhbGl6YXRpb25zLFxuICAgICAgICB0aW1lUmFuZ2U6IGdldFBhbmVsLm9wZXJhdGlvbmFsUGFuZWwudGltZVJhbmdlLFxuICAgICAgICBxdWVyeUZpbHRlcjogZ2V0UGFuZWwub3BlcmF0aW9uYWxQYW5lbC5xdWVyeUZpbHRlcixcbiAgICAgIH07XG4gICAgICBjb25zdCBpbmRleFJlc3BvbnNlID0gYXdhaXQgdGhpcy5pbmRleFBhbmVsKGNsaWVudCwgY2xvbmVQYW5lbEJvZHkpO1xuICAgICAgY29uc3QgZ2V0Q2xvbmVkUGFuZWwgPSBhd2FpdCB0aGlzLmdldFBhbmVsKGNsaWVudCwgaW5kZXhSZXNwb25zZS5vYmplY3RJZCk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBjbG9uZVBhbmVsSWQ6IGdldENsb25lZFBhbmVsLm9iamVjdElkLFxuICAgICAgICBkYXRlQ3JlYXRlZDogZ2V0Q2xvbmVkUGFuZWwuY3JlYXRlZFRpbWVNcyxcbiAgICAgICAgZGF0ZU1vZGlmaWVkOiBnZXRDbG9uZWRQYW5lbC5sYXN0VXBkYXRlZFRpbWVNcyxcbiAgICAgIH07XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2xvbmUgUGFuZWwgRXJyb3I6JyArIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gQWRkIGZpbHRlcnMgdG8gYW4gZXhpc3RpbmcgcGFuZWxcbiAgYWRkUGFuZWxGaWx0ZXIgPSBhc3luYyAoXG4gICAgY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCxcbiAgICBwYW5lbElkOiBzdHJpbmcsXG4gICAgcXVlcnk6IHN0cmluZyxcbiAgICBsYW5ndWFnZTogc3RyaW5nLFxuICAgIHRvOiBzdHJpbmcsXG4gICAgZnJvbTogc3RyaW5nXG4gICkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZVBhbmVsQm9keSA9IHtcbiAgICAgIHRpbWVSYW5nZToge1xuICAgICAgICB0byxcbiAgICAgICAgZnJvbSxcbiAgICAgIH0sXG4gICAgICBxdWVyeUZpbHRlcjoge1xuICAgICAgICBxdWVyeSxcbiAgICAgICAgbGFuZ3VhZ2UsXG4gICAgICB9LFxuICAgIH07XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy51cGRhdGVQYW5lbChjbGllbnQsIHBhbmVsSWQsIHVwZGF0ZVBhbmVsQm9keSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2JqZWN0SWQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQWRkIFBhbmVsIEZpbHRlciBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvLyBwYXJzZXMgZmV0Y2hlZCBzYXZlZCB2aXN1YWxpemF0aW9uXG4gIHBhcnNlU2F2ZWRWaXN1YWxpemF0aW9ucyA9ICh2aXN1YWxpemF0aW9uOiBhbnkpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgaWQ6IHZpc3VhbGl6YXRpb24ub2JqZWN0SWQsXG4gICAgICBuYW1lOiB2aXN1YWxpemF0aW9uLnNhdmVkVmlzdWFsaXphdGlvbi5uYW1lLFxuICAgICAgcXVlcnk6IHZpc3VhbGl6YXRpb24uc2F2ZWRWaXN1YWxpemF0aW9uLnF1ZXJ5LFxuICAgICAgdHlwZTogdmlzdWFsaXphdGlvbi5zYXZlZFZpc3VhbGl6YXRpb24udHlwZSxcbiAgICAgIHRpbWVGaWVsZDogdmlzdWFsaXphdGlvbi5zYXZlZFZpc3VhbGl6YXRpb24uc2VsZWN0ZWRfdGltZXN0YW1wLm5hbWUsXG4gICAgICBzZWxlY3RlZF9kYXRlX3JhbmdlOiB2aXN1YWxpemF0aW9uLnNhdmVkVmlzdWFsaXphdGlvbi5zZWxlY3RlZF9kYXRlX3JhbmdlLFxuICAgICAgc2VsZWN0ZWRfZmllbGRzOiB2aXN1YWxpemF0aW9uLnNhdmVkVmlzdWFsaXphdGlvbi5zZWxlY3RlZF9maWVsZHMsXG4gICAgICB1c2VyX2NvbmZpZ3M6IHZpc3VhbGl6YXRpb24uc2F2ZWRWaXN1YWxpemF0aW9uLmhhc093blByb3BlcnR5KCd1c2VyX2NvbmZpZ3MnKVxuICAgICAgICA/IEpTT04ucGFyc2UodmlzdWFsaXphdGlvbi5zYXZlZFZpc3VhbGl6YXRpb24udXNlcl9jb25maWdzKVxuICAgICAgICA6IHt9LFxuICAgICAgc3ViX3R5cGU6IHZpc3VhbGl6YXRpb24uc2F2ZWRWaXN1YWxpemF0aW9uLmhhc093blByb3BlcnR5KCdzdWJfdHlwZScpXG4gICAgICAgID8gdmlzdWFsaXphdGlvbi5zYXZlZFZpc3VhbGl6YXRpb24uc3ViX3R5cGVcbiAgICAgICAgOiAnJyxcbiAgICAgIHVuaXRzX29mX21lYXN1cmU6IHZpc3VhbGl6YXRpb24uc2F2ZWRWaXN1YWxpemF0aW9uLmhhc093blByb3BlcnR5KCd1bml0c19vZl9tZWFzdXJlJylcbiAgICAgICAgPyB2aXN1YWxpemF0aW9uLnNhdmVkVmlzdWFsaXphdGlvbi51bml0c19vZl9tZWFzdXJlXG4gICAgICAgIDogJycsXG4gICAgICAuLi4odmlzdWFsaXphdGlvbi5zYXZlZFZpc3VhbGl6YXRpb24uYXBwbGljYXRpb25faWRcbiAgICAgICAgPyB7IGFwcGxpY2F0aW9uX2lkOiB2aXN1YWxpemF0aW9uLnNhdmVkVmlzdWFsaXphdGlvbi5hcHBsaWNhdGlvbl9pZCB9XG4gICAgICAgIDoge30pLFxuICAgIH07XG4gIH07XG5cbiAgLy8gZ2V0cyBhbGwgc2F2ZWQgdmlzdWFsaXphdGlvbnNcbiAgZ2V0QWxsU2F2ZWRWaXN1YWxpemF0aW9ucyA9IGFzeW5jIChjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvYnNlcnZhYmlsaXR5LmdldE9iamVjdCcsIHtcbiAgICAgICAgb2JqZWN0VHlwZTogJ3NhdmVkVmlzdWFsaXphdGlvbicsXG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vYnNlcnZhYmlsaXR5T2JqZWN0TGlzdC5tYXAoKHZpc3VhbGl6YXRpb246IGFueSkgPT5cbiAgICAgICAgdGhpcy5wYXJzZVNhdmVkVmlzdWFsaXphdGlvbnModmlzdWFsaXphdGlvbilcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVmlldyBTYXZlZCBWaXN1YWxpemF0aW9ucyBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvLyBnZXRzIGxpc3Qgb2Ygc2F2ZWRWaXN1YWxpemF0aW9ucyBieSBJZFxuICBnZXRTYXZlZFZpc3VhbGl6YXRpb25CeUlkID0gYXN5bmMgKFxuICAgIGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQsXG4gICAgc2F2ZWRWaXN1YWxpemF0aW9uSWQ6IHN0cmluZ1xuICApID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29ic2VydmFiaWxpdHkuZ2V0T2JqZWN0QnlJZCcsIHtcbiAgICAgICAgb2JqZWN0SWQ6IHNhdmVkVmlzdWFsaXphdGlvbklkLFxuICAgICAgfSk7XG4gICAgICBjb25zdCB2aXN1YWxpemF0aW9uID0gcmVzcG9uc2Uub2JzZXJ2YWJpbGl0eU9iamVjdExpc3RbMF07XG4gICAgICByZXR1cm4gdGhpcy5wYXJzZVNhdmVkVmlzdWFsaXphdGlvbnModmlzdWFsaXphdGlvbik7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRmV0Y2ggU2F2ZWQgVmlzdWFsaXphdGlvbnMgQnkgSWQgRXJyb3I6JyArIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gR2V0IEFsbCBWaXN1YWxpemF0aW9ucyBmcm9tIGEgUGFuZWxcbiAgZ2V0VmlzdWFsaXphdGlvbnMgPSBhc3luYyAoY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCwgcGFuZWxJZDogc3RyaW5nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvYnNlcnZhYmlsaXR5LmdldE9iamVjdEJ5SWQnLCB7XG4gICAgICAgIG9iamVjdElkOiBwYW5lbElkLFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2JzZXJ2YWJpbGl0eU9iamVjdExpc3RbMF0ub3BlcmF0aW9uYWxQYW5lbC52aXN1YWxpemF0aW9ucztcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdHZXQgVmlzdWFsaXphdGlvbnMgRXJyb3I6JyArIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgY2FsY3VsYXRPdmVybGFwQXJlYSA9IChiYjE6IEJveFR5cGUsIGJiMjogQm94VHlwZSkgPT4ge1xuICAgIGNvbnN0IHhMZWZ0ID0gTWF0aC5tYXgoYmIxLngxLCBiYjIueDEpO1xuICAgIGNvbnN0IHlUb3AgPSBNYXRoLm1heChiYjEueTEsIGJiMi55MSk7XG4gICAgY29uc3QgeFJpZ2h0ID0gTWF0aC5taW4oYmIxLngyLCBiYjIueDIpO1xuICAgIGNvbnN0IHlCb3R0b20gPSBNYXRoLm1pbihiYjEueTIsIGJiMi55Mik7XG5cbiAgICBpZiAoeFJpZ2h0IDwgeExlZnQgfHwgeUJvdHRvbSA8IHlUb3ApIHJldHVybiAwO1xuICAgIHJldHVybiAoeFJpZ2h0IC0geExlZnQpICogKHlCb3R0b20gLSB5VG9wKTtcbiAgfTtcblxuICBnZXRUb3RhbE92ZXJsYXBBcmVhID0gKHBhbmVsVmlzdWFsaXphdGlvbnM6IFZpc3VhbGl6YXRpb25UeXBlW10pID0+IHtcbiAgICBjb25zdCBuZXdWaXpCb3ggPSB7IHgxOiAwLCB5MTogMCwgeDI6IDYsIHkyOiA0IH07XG4gICAgY29uc3QgY3VycmVudFZpekJveGVzID0gcGFuZWxWaXN1YWxpemF0aW9ucy5tYXAoKHZpc3VhbGl6YXRpb24pID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHgxOiB2aXN1YWxpemF0aW9uLngsXG4gICAgICAgIHkxOiB2aXN1YWxpemF0aW9uLnksXG4gICAgICAgIHgyOiB2aXN1YWxpemF0aW9uLnggKyB2aXN1YWxpemF0aW9uLncsXG4gICAgICAgIHkyOiB2aXN1YWxpemF0aW9uLnkgKyB2aXN1YWxpemF0aW9uLmgsXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgbGV0IGlzT3ZlcmxhcHBpbmcgPSAwO1xuICAgIGN1cnJlbnRWaXpCb3hlcy5tYXAoKHZpeikgPT4ge1xuICAgICAgaXNPdmVybGFwcGluZyArPSB0aGlzLmNhbGN1bGF0T3ZlcmxhcEFyZWEodml6LCBuZXdWaXpCb3gpO1xuICAgIH0pO1xuICAgIHJldHVybiBpc092ZXJsYXBwaW5nO1xuICB9O1xuXG4gIC8vIFdlIHdhbnQgdG8gY2hlY2sgaWYgdGhlIG5ldyB2aXN1YWxpemF0aW9uIGJlaW5nIGFkZGVkLCBjYW4gYmUgcGxhY2VkIGF0IHsgeDogMCwgeTogMCwgdzogNiwgaDogNCB9O1xuICAvLyBUbyBjaGVjayB0aGlzIHdlIHRyeSB0byBjYWxjdWxhdGUgb3ZlcmxhcCBiZXR3ZWVuIGFsbCB0aGUgY3VycmVudCB2aXN1YWxpemF0aW9ucyBhbmQgbmV3IHZpc3VhbGl6YXRpb25cbiAgLy8gaWYgdGhlcmUgaXMgbm8gb3ZlcmFsYXAgKGkuZSBUb3RhbCBPdmVybGFwIEFyZWEgaXMgMCksIHdlIHBsYWNlIHRoZSBuZXcgdml6LiBpbiBkZWZhdWx0IHBvc2l0aW9uXG4gIC8vIGVsc2UsIHdlIGFkZCBpdCB0byB0aGUgYm90dG9tIG9mIHRoZSBwYW5lbFxuICBnZXROZXdWaXpEaW1lbnNpb25zID0gKHBhbmVsVmlzdWFsaXphdGlvbnM6IFZpc3VhbGl6YXRpb25UeXBlW10pID0+IHtcbiAgICBsZXQgbWF4WTogbnVtYmVyID0gMDtcbiAgICBsZXQgbWF4WUg6IG51bWJlciA9IDA7XG5cbiAgICAvLyBjaGVjayBpZiB3ZSBjYW4gcGxhY2UgdGhlIG5ldyB2aXN1YWxpemF0aW9uIGF0IGRlZmF1bHQgbG9jYXRpb25cbiAgICBpZiAodGhpcy5nZXRUb3RhbE92ZXJsYXBBcmVhKHBhbmVsVmlzdWFsaXphdGlvbnMpID09PSAwKSB7XG4gICAgICByZXR1cm4geyB4OiAwLCB5OiAwLCB3OiA2LCBoOiA0IH07XG4gICAgfVxuXG4gICAgLy8gZWxzZSBwbGFjZSB0aGUgbmV3IHZpc3VhbGl6YXRpb24gYXQgdGhlIGJvdHRvbSBvZiB0aGUgcGFuZWxcbiAgICBwYW5lbFZpc3VhbGl6YXRpb25zLm1hcCgocGFuZWxWaXN1YWxpemF0aW9uOiBWaXN1YWxpemF0aW9uVHlwZSkgPT4ge1xuICAgICAgaWYgKHBhbmVsVmlzdWFsaXphdGlvbi55ID49IG1heFkpIHtcbiAgICAgICAgbWF4WSA9IHBhbmVsVmlzdWFsaXphdGlvbi55O1xuICAgICAgICBtYXhZSCA9IHBhbmVsVmlzdWFsaXphdGlvbi5oO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgcmV0dXJuIHsgeDogMCwgeTogbWF4WSArIG1heFlILCB3OiA2LCBoOiA0IH07XG4gIH07XG5cbiAgLy8gQWRkIFZpc3VhbGl6YXRpb24gaW4gdGhlICBQYW5lbFxuICBhZGRWaXN1YWxpemF0aW9uID0gYXN5bmMgKFxuICAgIGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQsXG4gICAgcGFuZWxJZDogc3RyaW5nLFxuICAgIHNhdmVkVmlzdWFsaXphdGlvbklkOiBzdHJpbmcsXG4gICAgb2xkVmlzdWFsaXphdGlvbklkPzogc3RyaW5nXG4gICkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBhbGxQYW5lbFZpc3VhbGl6YXRpb25zID0gYXdhaXQgdGhpcy5nZXRWaXN1YWxpemF0aW9ucyhjbGllbnQsIHBhbmVsSWQpO1xuXG4gICAgICBsZXQgbmV3RGltZW5zaW9ucztcbiAgICAgIGxldCB2aXN1YWxpemF0aW9uc0xpc3QgPSBbXSBhcyBWaXN1YWxpemF0aW9uVHlwZVtdO1xuICAgICAgaWYgKG9sZFZpc3VhbGl6YXRpb25JZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIG5ld0RpbWVuc2lvbnMgPSB0aGlzLmdldE5ld1ZpekRpbWVuc2lvbnMoYWxsUGFuZWxWaXN1YWxpemF0aW9ucyk7XG4gICAgICAgIHZpc3VhbGl6YXRpb25zTGlzdCA9IGFsbFBhbmVsVmlzdWFsaXphdGlvbnM7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhbGxQYW5lbFZpc3VhbGl6YXRpb25zLm1hcCgodmlzdWFsaXphdGlvbjogVmlzdWFsaXphdGlvblR5cGUpID0+IHtcbiAgICAgICAgICBpZiAodmlzdWFsaXphdGlvbi5pZCAhPT0gb2xkVmlzdWFsaXphdGlvbklkKSB7XG4gICAgICAgICAgICB2aXN1YWxpemF0aW9uc0xpc3QucHVzaCh2aXN1YWxpemF0aW9uKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbmV3RGltZW5zaW9ucyA9IHtcbiAgICAgICAgICAgICAgeDogdmlzdWFsaXphdGlvbi54LFxuICAgICAgICAgICAgICB5OiB2aXN1YWxpemF0aW9uLnksXG4gICAgICAgICAgICAgIHc6IHZpc3VhbGl6YXRpb24udyxcbiAgICAgICAgICAgICAgaDogdmlzdWFsaXphdGlvbi5oLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgbmV3UGFuZWxWaXN1YWxpemF0aW9ucyA9IFtcbiAgICAgICAgLi4udmlzdWFsaXphdGlvbnNMaXN0LFxuICAgICAgICB7XG4gICAgICAgICAgaWQ6ICdwYW5lbF92aXpfJyArIHV1aWR2NCgpLFxuICAgICAgICAgIHNhdmVkVmlzdWFsaXphdGlvbklkLFxuICAgICAgICAgIC4uLm5ld0RpbWVuc2lvbnMsXG4gICAgICAgIH0sXG4gICAgICBdO1xuICAgICAgY29uc3QgdXBkYXRlUGFuZWxSZXNwb25zZSA9IGF3YWl0IHRoaXMudXBkYXRlUGFuZWwoY2xpZW50LCBwYW5lbElkLCB7XG4gICAgICAgIHZpc3VhbGl6YXRpb25zOiBuZXdQYW5lbFZpc3VhbGl6YXRpb25zLFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gbmV3UGFuZWxWaXN1YWxpemF0aW9ucztcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdBZGQvUmVwbGFjZSBWaXN1YWxpemF0aW9uIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8vIEFkZCBNdWx0aXBsZSB2aXN1YWxpemF0aW9ucyBpbiBhIFBhbmVsXG4gIGFkZE11bHRpcGxlVmlzdWFsaXphdGlvbnMgPSBhc3luYyAoXG4gICAgY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCxcbiAgICBwYW5lbElkOiBzdHJpbmcsXG4gICAgc2F2ZWRWaXN1YWxpemF0aW9uSWRzOiBzdHJpbmdbXVxuICApID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgYWxsUGFuZWxWaXN1YWxpemF0aW9ucyA9IGF3YWl0IHRoaXMuZ2V0VmlzdWFsaXphdGlvbnMoY2xpZW50LCBwYW5lbElkKTtcblxuICAgICAgbGV0IG5ld0RpbWVuc2lvbnM7XG4gICAgICBsZXQgdmlzdWFsaXphdGlvbnNMaXN0ID0gWy4uLmFsbFBhbmVsVmlzdWFsaXphdGlvbnNdO1xuXG4gICAgICBzYXZlZFZpc3VhbGl6YXRpb25JZHMubWFwKChzYXZlZFZpc3VhbGl6YXRpb25JZCkgPT4ge1xuICAgICAgICBuZXdEaW1lbnNpb25zID0gdGhpcy5nZXROZXdWaXpEaW1lbnNpb25zKHZpc3VhbGl6YXRpb25zTGlzdCk7XG4gICAgICAgIHZpc3VhbGl6YXRpb25zTGlzdCA9IFtcbiAgICAgICAgICAuLi52aXN1YWxpemF0aW9uc0xpc3QsXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICdwYW5lbF92aXpfJyArIHV1aWR2NCgpLFxuICAgICAgICAgICAgc2F2ZWRWaXN1YWxpemF0aW9uSWQsXG4gICAgICAgICAgICAuLi5uZXdEaW1lbnNpb25zLFxuICAgICAgICAgIH0sXG4gICAgICAgIF07XG4gICAgICB9KTtcblxuICAgICAgY29uc3QgdXBkYXRlUGFuZWxSZXNwb25zZSA9IGF3YWl0IHRoaXMudXBkYXRlUGFuZWwoY2xpZW50LCBwYW5lbElkLCB7XG4gICAgICAgIHZpc3VhbGl6YXRpb25zOiB2aXN1YWxpemF0aW9uc0xpc3QsXG4gICAgICB9KTtcbiAgICAgIHJldHVybiB2aXN1YWxpemF0aW9uc0xpc3Q7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQWRkL1JlcGxhY2UgVmlzdWFsaXphdGlvbiBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvLyBFZGl0cyBhbGwgVmlzdWFsaXphdGlvbnMgaW4gdGhlIFBhbmVsXG4gIGVkaXRWaXN1YWxpemF0aW9uID0gYXN5bmMgKFxuICAgIGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQsXG4gICAgcGFuZWxJZDogc3RyaW5nLFxuICAgIHZpc3VhbGl6YXRpb25QYXJhbXM6IEFycmF5PHtcbiAgICAgIGk6IHN0cmluZztcbiAgICAgIHg6IG51bWJlcjtcbiAgICAgIHk6IG51bWJlcjtcbiAgICAgIHc6IG51bWJlcjtcbiAgICAgIGg6IG51bWJlcjtcbiAgICB9PlxuICApID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgYWxsUGFuZWxWaXN1YWxpemF0aW9ucyA9IGF3YWl0IHRoaXMuZ2V0VmlzdWFsaXphdGlvbnMoY2xpZW50LCBwYW5lbElkKTtcbiAgICAgIGNvbnN0IGZpbHRlcmVkUGFuZWxWaXN1YWxpemF0aW9ucyA9IFtdIGFzIFZpc3VhbGl6YXRpb25UeXBlW107XG5cbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYWxsUGFuZWxWaXN1YWxpemF0aW9ucy5sZW5ndGg7IGkrKykge1xuICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHZpc3VhbGl6YXRpb25QYXJhbXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICBpZiAoYWxsUGFuZWxWaXN1YWxpemF0aW9uc1tpXS5pZCA9PT0gdmlzdWFsaXphdGlvblBhcmFtc1tqXS5pKSB7XG4gICAgICAgICAgICBmaWx0ZXJlZFBhbmVsVmlzdWFsaXphdGlvbnMucHVzaCh7XG4gICAgICAgICAgICAgIC4uLmFsbFBhbmVsVmlzdWFsaXphdGlvbnNbaV0sXG4gICAgICAgICAgICAgIHg6IHZpc3VhbGl6YXRpb25QYXJhbXNbal0ueCxcbiAgICAgICAgICAgICAgeTogdmlzdWFsaXphdGlvblBhcmFtc1tqXS55LFxuICAgICAgICAgICAgICB3OiB2aXN1YWxpemF0aW9uUGFyYW1zW2pdLncsXG4gICAgICAgICAgICAgIGg6IHZpc3VhbGl6YXRpb25QYXJhbXNbal0uaCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29uc3QgdXBkYXRlUGFuZWxSZXNwb25zZSA9IGF3YWl0IHRoaXMudXBkYXRlUGFuZWwoY2xpZW50LCBwYW5lbElkLCB7XG4gICAgICAgIHZpc3VhbGl6YXRpb25zOiBmaWx0ZXJlZFBhbmVsVmlzdWFsaXphdGlvbnMsXG4gICAgICB9KTtcbiAgICAgIHJldHVybiBmaWx0ZXJlZFBhbmVsVmlzdWFsaXphdGlvbnM7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRWRpdCBWaXN1YWxpemF0aW9ucyBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvLyBDcmVhdGUgU2FtcGxlIFBhbmVsc1xuICBhZGRTYW1wbGVQYW5lbHMgPSBhc3luYyAoY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCwgc2F2ZWRWaXN1YWxpemF0aW9uSWRzOiBzdHJpbmdbXSkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwYW5lbEJvZHkgPSBjcmVhdGVEZW1vUGFuZWwoc2F2ZWRWaXN1YWxpemF0aW9uSWRzKTtcbiAgICAgIGNvbnN0IGluZGV4UmVzcG9uc2UgPSBhd2FpdCB0aGlzLmluZGV4UGFuZWwoY2xpZW50LCBwYW5lbEJvZHkpO1xuICAgICAgY29uc3QgZmV0Y2hQYW5lbCA9IGF3YWl0IHRoaXMuZ2V0UGFuZWwoY2xpZW50LCBpbmRleFJlc3BvbnNlLm9iamVjdElkKTtcbiAgICAgIGNvbnN0IGZldGNoUmVzcG9uc2UgPSB7XG4gICAgICAgIG5hbWU6IGZldGNoUGFuZWwub3BlcmF0aW9uYWxQYW5lbC5uYW1lLFxuICAgICAgICBpZDogZmV0Y2hQYW5lbC5vYmplY3RJZCxcbiAgICAgICAgZGF0ZUNyZWF0ZWQ6IGZldGNoUGFuZWwuY3JlYXRlZFRpbWVNcyxcbiAgICAgICAgZGF0ZU1vZGlmaWVkOiBmZXRjaFBhbmVsLmxhc3RVcGRhdGVkVGltZU1zLFxuICAgICAgfTtcbiAgICAgIHJldHVybiBbZmV0Y2hSZXNwb25zZV07XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ3JlYXRlIFBhbmVsIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxLQUFBLEdBQUFDLE9BQUE7QUFHQSxJQUFBQyxjQUFBLEdBQUFELE9BQUE7QUFBMEUsU0FBQUUsZ0JBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxLQUFBLElBQUFELEdBQUEsR0FBQUUsY0FBQSxDQUFBRixHQUFBLE9BQUFBLEdBQUEsSUFBQUQsR0FBQSxJQUFBSSxNQUFBLENBQUFDLGNBQUEsQ0FBQUwsR0FBQSxFQUFBQyxHQUFBLElBQUFDLEtBQUEsRUFBQUEsS0FBQSxFQUFBSSxVQUFBLFFBQUFDLFlBQUEsUUFBQUMsUUFBQSxvQkFBQVIsR0FBQSxDQUFBQyxHQUFBLElBQUFDLEtBQUEsV0FBQUYsR0FBQTtBQUFBLFNBQUFHLGVBQUFNLEdBQUEsUUFBQVIsR0FBQSxHQUFBUyxZQUFBLENBQUFELEdBQUEsMkJBQUFSLEdBQUEsZ0JBQUFBLEdBQUEsR0FBQVUsTUFBQSxDQUFBVixHQUFBO0FBQUEsU0FBQVMsYUFBQUUsS0FBQSxFQUFBQyxJQUFBLGVBQUFELEtBQUEsaUJBQUFBLEtBQUEsa0JBQUFBLEtBQUEsTUFBQUUsSUFBQSxHQUFBRixLQUFBLENBQUFHLE1BQUEsQ0FBQUMsV0FBQSxPQUFBRixJQUFBLEtBQUFHLFNBQUEsUUFBQUMsR0FBQSxHQUFBSixJQUFBLENBQUFLLElBQUEsQ0FBQVAsS0FBQSxFQUFBQyxJQUFBLDJCQUFBSyxHQUFBLHNCQUFBQSxHQUFBLFlBQUFFLFNBQUEsNERBQUFQLElBQUEsZ0JBQUFGLE1BQUEsR0FBQVUsTUFBQSxFQUFBVCxLQUFBLEtBUjFFO0FBQ0E7QUFDQTtBQUNBO0FBY08sTUFBTVUsbUJBQW1CLENBQUM7RUFBQUMsWUFBQTtJQUMvQjtJQUFBeEIsZUFBQSxxQkFDYSxnQkFDWHlCLE1BQWtDLEVBQ2xDQyxTQUFvQixFQUNXO01BQy9CLElBQUk7UUFDRixNQUFNQyxRQUFRLEdBQUcsTUFBTUYsTUFBTSxDQUFDRyxpQkFBaUIsQ0FBQyw0QkFBNEIsRUFBRTtVQUM1RUMsSUFBSSxFQUFFO1lBQ0pDLGdCQUFnQixFQUFFSjtVQUNwQjtRQUNGLENBQUMsQ0FBQztRQUNGLE9BQU9DLFFBQVE7TUFDakIsQ0FBQyxDQUFDLE9BQU9JLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLG9CQUFvQixHQUFHRCxLQUFLLENBQUM7TUFDL0M7SUFDRixDQUFDO0lBRUQ7SUFBQS9CLGVBQUEsc0JBQ2MsZ0JBQ1p5QixNQUFrQyxFQUNsQ1EsT0FBZSxFQUNmQyxlQUFtQyxFQUNuQztNQUNBLElBQUk7UUFDRixNQUFNUCxRQUFRLEdBQUcsTUFBTUYsTUFBTSxDQUFDRyxpQkFBaUIsQ0FBQyxnQ0FBZ0MsRUFBRTtVQUNoRk8sUUFBUSxFQUFFRixPQUFPO1VBQ2pCSixJQUFJLEVBQUU7WUFDSkMsZ0JBQWdCLEVBQUVJO1VBQ3BCO1FBQ0YsQ0FBQyxDQUFDO1FBQ0YsT0FBT1AsUUFBUTtNQUNqQixDQUFDLENBQUMsT0FBT0ksS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMscUJBQXFCLEdBQUdELEtBQUssQ0FBQztNQUNoRDtJQUNGLENBQUM7SUFFRDtJQUFBL0IsZUFBQSxtQkFDVyxnQkFBZ0J5QixNQUFrQyxFQUFFUSxPQUFlLEVBQUU7TUFDOUUsSUFBSTtRQUNGLE1BQU1OLFFBQVEsR0FBRyxNQUFNRixNQUFNLENBQUNHLGlCQUFpQixDQUFDLDZCQUE2QixFQUFFO1VBQzdFTyxRQUFRLEVBQUVGO1FBQ1osQ0FBQyxDQUFDO1FBQ0YsT0FBT04sUUFBUSxDQUFDUyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7TUFDNUMsQ0FBQyxDQUFDLE9BQU9MLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLGtCQUFrQixHQUFHRCxLQUFLLENBQUM7TUFDN0M7SUFDRixDQUFDO0lBRUQ7SUFBQS9CLGVBQUEsd0JBQ2dCLGdCQUFnQnlCLE1BQWtDLEVBQUU7TUFDbEUsSUFBSTtRQUNGLE1BQU1FLFFBQVEsR0FBRyxNQUFNRixNQUFNLENBQUNHLGlCQUFpQixDQUFDLHlCQUF5QixFQUFFO1VBQ3pFUyxVQUFVLEVBQUUsa0JBQWtCO1VBQzlCQyxRQUFRLEVBQUU7UUFDWixDQUFDLENBQUM7UUFDRixPQUFPWCxRQUFRLENBQUNTLHVCQUF1QixDQUNwQ0csTUFBTSxDQUFFQyxLQUFVLElBQUssQ0FBQ0EsS0FBSyxDQUFDVixnQkFBZ0IsQ0FBQ1csYUFBYSxDQUFDLENBQzdEQyxHQUFHLENBQUVGLEtBQVUsS0FBTTtVQUNwQkcsSUFBSSxFQUFFSCxLQUFLLENBQUNWLGdCQUFnQixDQUFDYSxJQUFJO1VBQ2pDQyxFQUFFLEVBQUVKLEtBQUssQ0FBQ0wsUUFBUTtVQUNsQlUsV0FBVyxFQUFFTCxLQUFLLENBQUNNLGFBQWE7VUFDaENDLFlBQVksRUFBRVAsS0FBSyxDQUFDUTtRQUN0QixDQUFDLENBQUMsQ0FBQztNQUNQLENBQUMsQ0FBQyxPQUFPakIsS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMsd0JBQXdCLEdBQUdELEtBQUssQ0FBQztNQUNuRDtJQUNGLENBQUM7SUFFRDtJQUFBL0IsZUFBQSxzQkFDYyxnQkFBZ0J5QixNQUFrQyxFQUFFUSxPQUFlLEVBQUU7TUFDakYsSUFBSTtRQUNGLE1BQU1OLFFBQVEsR0FBRyxNQUFNRixNQUFNLENBQUNHLGlCQUFpQixDQUFDLGdDQUFnQyxFQUFFO1VBQ2hGTyxRQUFRLEVBQUVGO1FBQ1osQ0FBQyxDQUFDO1FBQ0YsT0FBTztVQUFFZ0IsTUFBTSxFQUFFLElBQUk7VUFBRUMsT0FBTyxFQUFFdkI7UUFBUyxDQUFDO01BQzVDLENBQUMsQ0FBQyxPQUFPSSxLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyxxQkFBcUIsR0FBR0QsS0FBSyxDQUFDO01BQ2hEO0lBQ0YsQ0FBQztJQUVEO0lBQUEvQixlQUFBLDBCQUNrQixnQkFBZ0J5QixNQUFrQyxFQUFFMEIsV0FBbUIsRUFBRTtNQUN6RixJQUFJO1FBQ0YsTUFBTXhCLFFBQVEsR0FBRyxNQUFNRixNQUFNLENBQUNHLGlCQUFpQixDQUFDLG9DQUFvQyxFQUFFO1VBQ3BGd0IsWUFBWSxFQUFFRDtRQUNoQixDQUFDLENBQUM7UUFDRixPQUFPO1VBQUVGLE1BQU0sRUFBRSxJQUFJO1VBQUVDLE9BQU8sRUFBRXZCO1FBQVMsQ0FBQztNQUM1QyxDQUFDLENBQUMsT0FBT0ksS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMsMEJBQTBCLEdBQUdELEtBQUssQ0FBQztNQUNyRDtJQUNGLENBQUM7SUFFRDtJQUFBL0IsZUFBQSx5QkFDaUIsT0FDZnlCLE1BQWtDLEVBQ2xDNEIsU0FBaUIsRUFDakJDLEtBQWMsS0FDWDtNQUNILE1BQU01QixTQUFvQixHQUFHO1FBQzNCaUIsSUFBSSxFQUFFVSxTQUFTO1FBQ2ZFLGNBQWMsRUFBRSxFQUFFO1FBQ2xCQyxTQUFTLEVBQUU7VUFDVEMsRUFBRSxFQUFFLEtBQUs7VUFDVEMsSUFBSSxFQUFFO1FBQ1IsQ0FBQztRQUNEQyxXQUFXLEVBQUU7VUFDWEMsS0FBSyxFQUFFLEVBQUU7VUFDVEMsUUFBUSxFQUFFO1FBQ1o7TUFDRixDQUFDO01BQ0QsSUFBSVAsS0FBSyxFQUFFO1FBQ1Q1QixTQUFTLENBQUNlLGFBQWEsR0FBR2EsS0FBSztRQUMvQjVCLFNBQVMsQ0FBQzhCLFNBQVMsR0FBRztVQUNwQkMsRUFBRSxFQUFFLEtBQUs7VUFDVEMsSUFBSSxFQUFFO1FBQ1IsQ0FBQztNQUNIO01BRUEsSUFBSTtRQUNGLE1BQU0vQixRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUNtQyxVQUFVLENBQUNyQyxNQUFNLEVBQUVDLFNBQVMsQ0FBQztRQUN6RCxPQUFPQyxRQUFRLENBQUNRLFFBQVE7TUFDMUIsQ0FBQyxDQUFDLE9BQU9KLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLHFCQUFxQixHQUFHRCxLQUFLLENBQUM7TUFDaEQ7SUFDRixDQUFDO0lBRUQ7SUFBQS9CLGVBQUEsc0JBQ2MsT0FBT3lCLE1BQWtDLEVBQUVRLE9BQWUsRUFBRW9CLFNBQWlCLEtBQUs7TUFDOUYsTUFBTW5CLGVBQWUsR0FBRztRQUN0QlMsSUFBSSxFQUFFVTtNQUNSLENBQUM7TUFDRCxJQUFJO1FBQ0YsTUFBTTFCLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQ29DLFdBQVcsQ0FBQ3RDLE1BQU0sRUFBRVEsT0FBTyxFQUFFQyxlQUFlLENBQUM7UUFDekUsT0FBT1AsUUFBUSxDQUFDUSxRQUFRO01BQzFCLENBQUMsQ0FBQyxPQUFPSixLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyxxQkFBcUIsR0FBR0QsS0FBSyxDQUFDO01BQ2hEO0lBQ0YsQ0FBQztJQUVEO0lBQUEvQixlQUFBLHFCQUNhLE9BQU95QixNQUFrQyxFQUFFUSxPQUFlLEVBQUVvQixTQUFpQixLQUFLO01BQzdGLE1BQU1uQixlQUFlLEdBQUc7UUFDdEJTLElBQUksRUFBRVU7TUFDUixDQUFDO01BQ0QsSUFBSTtRQUNGLE1BQU1XLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQ0EsUUFBUSxDQUFDdkMsTUFBTSxFQUFFUSxPQUFPLENBQUM7UUFDckQsTUFBTWdDLGNBQWMsR0FBRztVQUNyQnRCLElBQUksRUFBRVUsU0FBUztVQUNmRSxjQUFjLEVBQUVTLFFBQVEsQ0FBQ2xDLGdCQUFnQixDQUFDeUIsY0FBYztVQUN4REMsU0FBUyxFQUFFUSxRQUFRLENBQUNsQyxnQkFBZ0IsQ0FBQzBCLFNBQVM7VUFDOUNHLFdBQVcsRUFBRUssUUFBUSxDQUFDbEMsZ0JBQWdCLENBQUM2QjtRQUN6QyxDQUFDO1FBQ0QsTUFBTU8sYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDSixVQUFVLENBQUNyQyxNQUFNLEVBQUV3QyxjQUFjLENBQUM7UUFDbkUsTUFBTUUsY0FBYyxHQUFHLE1BQU0sSUFBSSxDQUFDSCxRQUFRLENBQUN2QyxNQUFNLEVBQUV5QyxhQUFhLENBQUMvQixRQUFRLENBQUM7UUFDMUUsT0FBTztVQUNMaUMsWUFBWSxFQUFFRCxjQUFjLENBQUNoQyxRQUFRO1VBQ3JDVSxXQUFXLEVBQUVzQixjQUFjLENBQUNyQixhQUFhO1VBQ3pDQyxZQUFZLEVBQUVvQixjQUFjLENBQUNuQjtRQUMvQixDQUFDO01BQ0gsQ0FBQyxDQUFDLE9BQU9qQixLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyxvQkFBb0IsR0FBR0QsS0FBSyxDQUFDO01BQy9DO0lBQ0YsQ0FBQztJQUVEO0lBQUEvQixlQUFBLHlCQUNpQixPQUNmeUIsTUFBa0MsRUFDbENRLE9BQWUsRUFDZjJCLEtBQWEsRUFDYkMsUUFBZ0IsRUFDaEJKLEVBQVUsRUFDVkMsSUFBWSxLQUNUO01BQ0gsTUFBTXhCLGVBQWUsR0FBRztRQUN0QnNCLFNBQVMsRUFBRTtVQUNUQyxFQUFFO1VBQ0ZDO1FBQ0YsQ0FBQztRQUNEQyxXQUFXLEVBQUU7VUFDWEMsS0FBSztVQUNMQztRQUNGO01BQ0YsQ0FBQztNQUNELElBQUk7UUFDRixNQUFNbEMsUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDb0MsV0FBVyxDQUFDdEMsTUFBTSxFQUFFUSxPQUFPLEVBQUVDLGVBQWUsQ0FBQztRQUN6RSxPQUFPUCxRQUFRLENBQUNRLFFBQVE7TUFDMUIsQ0FBQyxDQUFDLE9BQU9KLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLHlCQUF5QixHQUFHRCxLQUFLLENBQUM7TUFDcEQ7SUFDRixDQUFDO0lBRUQ7SUFBQS9CLGVBQUEsbUNBQzRCcUUsYUFBa0IsSUFBSztNQUNqRCxPQUFPO1FBQ0x6QixFQUFFLEVBQUV5QixhQUFhLENBQUNsQyxRQUFRO1FBQzFCUSxJQUFJLEVBQUUwQixhQUFhLENBQUNDLGtCQUFrQixDQUFDM0IsSUFBSTtRQUMzQ2lCLEtBQUssRUFBRVMsYUFBYSxDQUFDQyxrQkFBa0IsQ0FBQ1YsS0FBSztRQUM3Q1csSUFBSSxFQUFFRixhQUFhLENBQUNDLGtCQUFrQixDQUFDQyxJQUFJO1FBQzNDQyxTQUFTLEVBQUVILGFBQWEsQ0FBQ0Msa0JBQWtCLENBQUNHLGtCQUFrQixDQUFDOUIsSUFBSTtRQUNuRStCLG1CQUFtQixFQUFFTCxhQUFhLENBQUNDLGtCQUFrQixDQUFDSSxtQkFBbUI7UUFDekVDLGVBQWUsRUFBRU4sYUFBYSxDQUFDQyxrQkFBa0IsQ0FBQ0ssZUFBZTtRQUNqRUMsWUFBWSxFQUFFUCxhQUFhLENBQUNDLGtCQUFrQixDQUFDTyxjQUFjLENBQUMsY0FBYyxDQUFDLEdBQ3pFQyxJQUFJLENBQUNDLEtBQUssQ0FBQ1YsYUFBYSxDQUFDQyxrQkFBa0IsQ0FBQ00sWUFBWSxDQUFDLEdBQ3pELENBQUMsQ0FBQztRQUNOSSxRQUFRLEVBQUVYLGFBQWEsQ0FBQ0Msa0JBQWtCLENBQUNPLGNBQWMsQ0FBQyxVQUFVLENBQUMsR0FDakVSLGFBQWEsQ0FBQ0Msa0JBQWtCLENBQUNVLFFBQVEsR0FDekMsRUFBRTtRQUNOQyxnQkFBZ0IsRUFBRVosYUFBYSxDQUFDQyxrQkFBa0IsQ0FBQ08sY0FBYyxDQUFDLGtCQUFrQixDQUFDLEdBQ2pGUixhQUFhLENBQUNDLGtCQUFrQixDQUFDVyxnQkFBZ0IsR0FDakQsRUFBRTtRQUNOLElBQUlaLGFBQWEsQ0FBQ0Msa0JBQWtCLENBQUNZLGNBQWMsR0FDL0M7VUFBRUEsY0FBYyxFQUFFYixhQUFhLENBQUNDLGtCQUFrQixDQUFDWTtRQUFlLENBQUMsR0FDbkUsQ0FBQyxDQUFDO01BQ1IsQ0FBQztJQUNILENBQUM7SUFFRDtJQUFBbEYsZUFBQSxvQ0FDNEIsTUFBT3lCLE1BQWtDLElBQUs7TUFDeEUsSUFBSTtRQUNGLE1BQU1FLFFBQVEsR0FBRyxNQUFNRixNQUFNLENBQUNHLGlCQUFpQixDQUFDLHlCQUF5QixFQUFFO1VBQ3pFUyxVQUFVLEVBQUU7UUFDZCxDQUFDLENBQUM7UUFDRixPQUFPVixRQUFRLENBQUNTLHVCQUF1QixDQUFDTSxHQUFHLENBQUUyQixhQUFrQixJQUM3RCxJQUFJLENBQUNjLHdCQUF3QixDQUFDZCxhQUFhLENBQzdDLENBQUM7TUFDSCxDQUFDLENBQUMsT0FBT3RDLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLGtDQUFrQyxHQUFHRCxLQUFLLENBQUM7TUFDN0Q7SUFDRixDQUFDO0lBRUQ7SUFBQS9CLGVBQUEsb0NBQzRCLE9BQzFCeUIsTUFBa0MsRUFDbEMyRCxvQkFBNEIsS0FDekI7TUFDSCxJQUFJO1FBQ0YsTUFBTXpELFFBQVEsR0FBRyxNQUFNRixNQUFNLENBQUNHLGlCQUFpQixDQUFDLDZCQUE2QixFQUFFO1VBQzdFTyxRQUFRLEVBQUVpRDtRQUNaLENBQUMsQ0FBQztRQUNGLE1BQU1mLGFBQWEsR0FBRzFDLFFBQVEsQ0FBQ1MsdUJBQXVCLENBQUMsQ0FBQyxDQUFDO1FBQ3pELE9BQU8sSUFBSSxDQUFDK0Msd0JBQXdCLENBQUNkLGFBQWEsQ0FBQztNQUNyRCxDQUFDLENBQUMsT0FBT3RDLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLHlDQUF5QyxHQUFHRCxLQUFLLENBQUM7TUFDcEU7SUFDRixDQUFDO0lBRUQ7SUFBQS9CLGVBQUEsNEJBQ29CLE9BQU95QixNQUFrQyxFQUFFUSxPQUFlLEtBQUs7TUFDakYsSUFBSTtRQUNGLE1BQU1OLFFBQVEsR0FBRyxNQUFNRixNQUFNLENBQUNHLGlCQUFpQixDQUFDLDZCQUE2QixFQUFFO1VBQzdFTyxRQUFRLEVBQUVGO1FBQ1osQ0FBQyxDQUFDO1FBQ0YsT0FBT04sUUFBUSxDQUFDUyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQ04sZ0JBQWdCLENBQUN5QixjQUFjO01BQzVFLENBQUMsQ0FBQyxPQUFPeEIsS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMsMkJBQTJCLEdBQUdELEtBQUssQ0FBQztNQUN0RDtJQUNGLENBQUM7SUFBQS9CLGVBQUEsOEJBRXFCLENBQUNxRixHQUFZLEVBQUVDLEdBQVksS0FBSztNQUNwRCxNQUFNQyxLQUFLLEdBQUdDLElBQUksQ0FBQ0MsR0FBRyxDQUFDSixHQUFHLENBQUNLLEVBQUUsRUFBRUosR0FBRyxDQUFDSSxFQUFFLENBQUM7TUFDdEMsTUFBTUMsSUFBSSxHQUFHSCxJQUFJLENBQUNDLEdBQUcsQ0FBQ0osR0FBRyxDQUFDTyxFQUFFLEVBQUVOLEdBQUcsQ0FBQ00sRUFBRSxDQUFDO01BQ3JDLE1BQU1DLE1BQU0sR0FBR0wsSUFBSSxDQUFDTSxHQUFHLENBQUNULEdBQUcsQ0FBQ1UsRUFBRSxFQUFFVCxHQUFHLENBQUNTLEVBQUUsQ0FBQztNQUN2QyxNQUFNQyxPQUFPLEdBQUdSLElBQUksQ0FBQ00sR0FBRyxDQUFDVCxHQUFHLENBQUNZLEVBQUUsRUFBRVgsR0FBRyxDQUFDVyxFQUFFLENBQUM7TUFFeEMsSUFBSUosTUFBTSxHQUFHTixLQUFLLElBQUlTLE9BQU8sR0FBR0wsSUFBSSxFQUFFLE9BQU8sQ0FBQztNQUM5QyxPQUFPLENBQUNFLE1BQU0sR0FBR04sS0FBSyxLQUFLUyxPQUFPLEdBQUdMLElBQUksQ0FBQztJQUM1QyxDQUFDO0lBQUEzRixlQUFBLDhCQUVzQmtHLG1CQUF3QyxJQUFLO01BQ2xFLE1BQU1DLFNBQVMsR0FBRztRQUFFVCxFQUFFLEVBQUUsQ0FBQztRQUFFRSxFQUFFLEVBQUUsQ0FBQztRQUFFRyxFQUFFLEVBQUUsQ0FBQztRQUFFRSxFQUFFLEVBQUU7TUFBRSxDQUFDO01BQ2hELE1BQU1HLGVBQWUsR0FBR0YsbUJBQW1CLENBQUN4RCxHQUFHLENBQUUyQixhQUFhLElBQUs7UUFDakUsT0FBTztVQUNMcUIsRUFBRSxFQUFFckIsYUFBYSxDQUFDZ0MsQ0FBQztVQUNuQlQsRUFBRSxFQUFFdkIsYUFBYSxDQUFDaUMsQ0FBQztVQUNuQlAsRUFBRSxFQUFFMUIsYUFBYSxDQUFDZ0MsQ0FBQyxHQUFHaEMsYUFBYSxDQUFDa0MsQ0FBQztVQUNyQ04sRUFBRSxFQUFFNUIsYUFBYSxDQUFDaUMsQ0FBQyxHQUFHakMsYUFBYSxDQUFDbUM7UUFDdEMsQ0FBQztNQUNILENBQUMsQ0FBQztNQUVGLElBQUlDLGFBQWEsR0FBRyxDQUFDO01BQ3JCTCxlQUFlLENBQUMxRCxHQUFHLENBQUVnRSxHQUFHLElBQUs7UUFDM0JELGFBQWEsSUFBSSxJQUFJLENBQUNFLG1CQUFtQixDQUFDRCxHQUFHLEVBQUVQLFNBQVMsQ0FBQztNQUMzRCxDQUFDLENBQUM7TUFDRixPQUFPTSxhQUFhO0lBQ3RCLENBQUM7SUFFRDtJQUNBO0lBQ0E7SUFDQTtJQUFBekcsZUFBQSw4QkFDdUJrRyxtQkFBd0MsSUFBSztNQUNsRSxJQUFJVSxJQUFZLEdBQUcsQ0FBQztNQUNwQixJQUFJQyxLQUFhLEdBQUcsQ0FBQzs7TUFFckI7TUFDQSxJQUFJLElBQUksQ0FBQ0MsbUJBQW1CLENBQUNaLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQ3ZELE9BQU87VUFBRUcsQ0FBQyxFQUFFLENBQUM7VUFBRUMsQ0FBQyxFQUFFLENBQUM7VUFBRUMsQ0FBQyxFQUFFLENBQUM7VUFBRUMsQ0FBQyxFQUFFO1FBQUUsQ0FBQztNQUNuQzs7TUFFQTtNQUNBTixtQkFBbUIsQ0FBQ3hELEdBQUcsQ0FBRXFFLGtCQUFxQyxJQUFLO1FBQ2pFLElBQUlBLGtCQUFrQixDQUFDVCxDQUFDLElBQUlNLElBQUksRUFBRTtVQUNoQ0EsSUFBSSxHQUFHRyxrQkFBa0IsQ0FBQ1QsQ0FBQztVQUMzQk8sS0FBSyxHQUFHRSxrQkFBa0IsQ0FBQ1AsQ0FBQztRQUM5QjtNQUNGLENBQUMsQ0FBQztNQUVGLE9BQU87UUFBRUgsQ0FBQyxFQUFFLENBQUM7UUFBRUMsQ0FBQyxFQUFFTSxJQUFJLEdBQUdDLEtBQUs7UUFBRU4sQ0FBQyxFQUFFLENBQUM7UUFBRUMsQ0FBQyxFQUFFO01BQUUsQ0FBQztJQUM5QyxDQUFDO0lBRUQ7SUFBQXhHLGVBQUEsMkJBQ21CLE9BQ2pCeUIsTUFBa0MsRUFDbENRLE9BQWUsRUFDZm1ELG9CQUE0QixFQUM1QjRCLGtCQUEyQixLQUN4QjtNQUNILElBQUk7UUFDRixNQUFNQyxzQkFBc0IsR0FBRyxNQUFNLElBQUksQ0FBQ0MsaUJBQWlCLENBQUN6RixNQUFNLEVBQUVRLE9BQU8sQ0FBQztRQUU1RSxJQUFJa0YsYUFBYTtRQUNqQixJQUFJQyxrQkFBa0IsR0FBRyxFQUF5QjtRQUNsRCxJQUFJSixrQkFBa0IsS0FBSzlGLFNBQVMsRUFBRTtVQUNwQ2lHLGFBQWEsR0FBRyxJQUFJLENBQUNFLG1CQUFtQixDQUFDSixzQkFBc0IsQ0FBQztVQUNoRUcsa0JBQWtCLEdBQUdILHNCQUFzQjtRQUM3QyxDQUFDLE1BQU07VUFDTEEsc0JBQXNCLENBQUN2RSxHQUFHLENBQUUyQixhQUFnQyxJQUFLO1lBQy9ELElBQUlBLGFBQWEsQ0FBQ3pCLEVBQUUsS0FBS29FLGtCQUFrQixFQUFFO2NBQzNDSSxrQkFBa0IsQ0FBQ0UsSUFBSSxDQUFDakQsYUFBYSxDQUFDO1lBQ3hDLENBQUMsTUFBTTtjQUNMOEMsYUFBYSxHQUFHO2dCQUNkZCxDQUFDLEVBQUVoQyxhQUFhLENBQUNnQyxDQUFDO2dCQUNsQkMsQ0FBQyxFQUFFakMsYUFBYSxDQUFDaUMsQ0FBQztnQkFDbEJDLENBQUMsRUFBRWxDLGFBQWEsQ0FBQ2tDLENBQUM7Z0JBQ2xCQyxDQUFDLEVBQUVuQyxhQUFhLENBQUNtQztjQUNuQixDQUFDO1lBQ0g7VUFDRixDQUFDLENBQUM7UUFDSjtRQUNBLE1BQU1lLHNCQUFzQixHQUFHLENBQzdCLEdBQUdILGtCQUFrQixFQUNyQjtVQUNFeEUsRUFBRSxFQUFFLFlBQVksR0FBRyxJQUFBNEUsUUFBTSxFQUFDLENBQUM7VUFDM0JwQyxvQkFBb0I7VUFDcEIsR0FBRytCO1FBQ0wsQ0FBQyxDQUNGO1FBQ0QsTUFBTU0sbUJBQW1CLEdBQUcsTUFBTSxJQUFJLENBQUMxRCxXQUFXLENBQUN0QyxNQUFNLEVBQUVRLE9BQU8sRUFBRTtVQUNsRXNCLGNBQWMsRUFBRWdFO1FBQ2xCLENBQUMsQ0FBQztRQUNGLE9BQU9BLHNCQUFzQjtNQUMvQixDQUFDLENBQUMsT0FBT3hGLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLGtDQUFrQyxHQUFHRCxLQUFLLENBQUM7TUFDN0Q7SUFDRixDQUFDO0lBRUQ7SUFBQS9CLGVBQUEsb0NBQzRCLE9BQzFCeUIsTUFBa0MsRUFDbENRLE9BQWUsRUFDZnlGLHFCQUErQixLQUM1QjtNQUNILElBQUk7UUFDRixNQUFNVCxzQkFBc0IsR0FBRyxNQUFNLElBQUksQ0FBQ0MsaUJBQWlCLENBQUN6RixNQUFNLEVBQUVRLE9BQU8sQ0FBQztRQUU1RSxJQUFJa0YsYUFBYTtRQUNqQixJQUFJQyxrQkFBa0IsR0FBRyxDQUFDLEdBQUdILHNCQUFzQixDQUFDO1FBRXBEUyxxQkFBcUIsQ0FBQ2hGLEdBQUcsQ0FBRTBDLG9CQUFvQixJQUFLO1VBQ2xEK0IsYUFBYSxHQUFHLElBQUksQ0FBQ0UsbUJBQW1CLENBQUNELGtCQUFrQixDQUFDO1VBQzVEQSxrQkFBa0IsR0FBRyxDQUNuQixHQUFHQSxrQkFBa0IsRUFDckI7WUFDRXhFLEVBQUUsRUFBRSxZQUFZLEdBQUcsSUFBQTRFLFFBQU0sRUFBQyxDQUFDO1lBQzNCcEMsb0JBQW9CO1lBQ3BCLEdBQUcrQjtVQUNMLENBQUMsQ0FDRjtRQUNILENBQUMsQ0FBQztRQUVGLE1BQU1NLG1CQUFtQixHQUFHLE1BQU0sSUFBSSxDQUFDMUQsV0FBVyxDQUFDdEMsTUFBTSxFQUFFUSxPQUFPLEVBQUU7VUFDbEVzQixjQUFjLEVBQUU2RDtRQUNsQixDQUFDLENBQUM7UUFDRixPQUFPQSxrQkFBa0I7TUFDM0IsQ0FBQyxDQUFDLE9BQU9yRixLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyxrQ0FBa0MsR0FBR0QsS0FBSyxDQUFDO01BQzdEO0lBQ0YsQ0FBQztJQUVEO0lBQUEvQixlQUFBLDRCQUNvQixPQUNsQnlCLE1BQWtDLEVBQ2xDUSxPQUFlLEVBQ2YwRixtQkFNRSxLQUNDO01BQ0gsSUFBSTtRQUNGLE1BQU1WLHNCQUFzQixHQUFHLE1BQU0sSUFBSSxDQUFDQyxpQkFBaUIsQ0FBQ3pGLE1BQU0sRUFBRVEsT0FBTyxDQUFDO1FBQzVFLE1BQU0yRiwyQkFBMkIsR0FBRyxFQUF5QjtRQUU3RCxLQUFLLElBQUlDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR1osc0JBQXNCLENBQUNhLE1BQU0sRUFBRUQsQ0FBQyxFQUFFLEVBQUU7VUFDdEQsS0FBSyxJQUFJRSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdKLG1CQUFtQixDQUFDRyxNQUFNLEVBQUVDLENBQUMsRUFBRSxFQUFFO1lBQ25ELElBQUlkLHNCQUFzQixDQUFDWSxDQUFDLENBQUMsQ0FBQ2pGLEVBQUUsS0FBSytFLG1CQUFtQixDQUFDSSxDQUFDLENBQUMsQ0FBQ0YsQ0FBQyxFQUFFO2NBQzdERCwyQkFBMkIsQ0FBQ04sSUFBSSxDQUFDO2dCQUMvQixHQUFHTCxzQkFBc0IsQ0FBQ1ksQ0FBQyxDQUFDO2dCQUM1QnhCLENBQUMsRUFBRXNCLG1CQUFtQixDQUFDSSxDQUFDLENBQUMsQ0FBQzFCLENBQUM7Z0JBQzNCQyxDQUFDLEVBQUVxQixtQkFBbUIsQ0FBQ0ksQ0FBQyxDQUFDLENBQUN6QixDQUFDO2dCQUMzQkMsQ0FBQyxFQUFFb0IsbUJBQW1CLENBQUNJLENBQUMsQ0FBQyxDQUFDeEIsQ0FBQztnQkFDM0JDLENBQUMsRUFBRW1CLG1CQUFtQixDQUFDSSxDQUFDLENBQUMsQ0FBQ3ZCO2NBQzVCLENBQUMsQ0FBQztZQUNKO1VBQ0Y7UUFDRjtRQUNBLE1BQU1pQixtQkFBbUIsR0FBRyxNQUFNLElBQUksQ0FBQzFELFdBQVcsQ0FBQ3RDLE1BQU0sRUFBRVEsT0FBTyxFQUFFO1VBQ2xFc0IsY0FBYyxFQUFFcUU7UUFDbEIsQ0FBQyxDQUFDO1FBQ0YsT0FBT0EsMkJBQTJCO01BQ3BDLENBQUMsQ0FBQyxPQUFPN0YsS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMsNEJBQTRCLEdBQUdELEtBQUssQ0FBQztNQUN2RDtJQUNGLENBQUM7SUFFRDtJQUFBL0IsZUFBQSwwQkFDa0IsT0FBT3lCLE1BQWtDLEVBQUVpRyxxQkFBK0IsS0FBSztNQUMvRixJQUFJO1FBQ0YsTUFBTWhHLFNBQVMsR0FBRyxJQUFBc0csOEJBQWUsRUFBQ04scUJBQXFCLENBQUM7UUFDeEQsTUFBTXhELGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQ0osVUFBVSxDQUFDckMsTUFBTSxFQUFFQyxTQUFTLENBQUM7UUFDOUQsTUFBTXVHLFVBQVUsR0FBRyxNQUFNLElBQUksQ0FBQ2pFLFFBQVEsQ0FBQ3ZDLE1BQU0sRUFBRXlDLGFBQWEsQ0FBQy9CLFFBQVEsQ0FBQztRQUN0RSxNQUFNK0YsYUFBYSxHQUFHO1VBQ3BCdkYsSUFBSSxFQUFFc0YsVUFBVSxDQUFDbkcsZ0JBQWdCLENBQUNhLElBQUk7VUFDdENDLEVBQUUsRUFBRXFGLFVBQVUsQ0FBQzlGLFFBQVE7VUFDdkJVLFdBQVcsRUFBRW9GLFVBQVUsQ0FBQ25GLGFBQWE7VUFDckNDLFlBQVksRUFBRWtGLFVBQVUsQ0FBQ2pGO1FBQzNCLENBQUM7UUFDRCxPQUFPLENBQUNrRixhQUFhLENBQUM7TUFDeEIsQ0FBQyxDQUFDLE9BQU9uRyxLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyxxQkFBcUIsR0FBR0QsS0FBSyxDQUFDO01BQ2hEO0lBQ0YsQ0FBQztFQUFBO0FBQ0g7QUFBQ29HLE9BQUEsQ0FBQTVHLG1CQUFBLEdBQUFBLG1CQUFBIn0=