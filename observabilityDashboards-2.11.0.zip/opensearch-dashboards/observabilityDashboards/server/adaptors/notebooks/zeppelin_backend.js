"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ZeppelinBackend = void 0;
var _wreck_requests = require("../../common/helpers/notebooks/wreck_requests");
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); } /*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
class ZeppelinBackend {
  constructor() {
    _defineProperty(this, "backend", 'Zeppelin Backend');
    // Gets all the notebooks available from Zeppelin Server
    // ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook
    _defineProperty(this, "viewNotes", async function (client, wreckOptions) {
      try {
        let output = [];
        const body = await (0, _wreck_requests.requestor)('GET', 'api/notebook/', wreckOptions);
        output = JSON.parse(body.toString()).body;
        return output;
      } catch (error) {
        throw new Error('View Notebooks Error:' + error);
      }
    });
    /* Fetches a notebook by id from Zeppelin Server
     * Param: noteId -> Id of notebook to be fetched
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/[noteId]
     */
    _defineProperty(this, "fetchNote", async function (client, noteId, wreckOptions) {
      try {
        const body = await (0, _wreck_requests.requestor)('GET', 'api/notebook/' + noteId, wreckOptions);
        return JSON.parse(body.toString()).body.paragraphs;
      } catch (error) {
        throw new Error('Fetching Notebook Error:' + error);
      }
    });
    /* Add a notebook to the Zeppelin Server
     * Param: name -> name of new notebook
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook
     */
    _defineProperty(this, "addNote", async function (client, params, wreckOptions) {
      wreckOptions.payload = params;
      try {
        const body = await (0, _wreck_requests.requestor)('POST', 'api/notebook/', wreckOptions);
        return JSON.parse(body.toString());
      } catch (error) {
        throw new Error('Creating New Notebook Error:' + error);
      }
    });
    /* Rename a notebook in Zeppelin Server
     * Params: name -> new name for the notebook to be renamed
     *         noteId -> Id of notebook to be fetched
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/[noteId]/rename
     */
    _defineProperty(this, "renameNote", async function (client, params, wreckOptions) {
      wreckOptions.payload = {
        name: params.name
      };
      try {
        const body = await (0, _wreck_requests.requestor)('PUT', 'api/notebook/' + params.noteId + '/rename/', wreckOptions);
        return JSON.parse(body.toString());
      } catch (error) {
        throw new Error('Renaming Notebook Error:' + error);
      }
    });
    /* Clone a notebook in Zeppelin Server
     * Params: name -> new name for the cloned notebook
     *         noteId -> Id for the notebook to be cloned
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/[noteId]
     */
    _defineProperty(this, "cloneNote", async function (client, params, wreckOptions) {
      wreckOptions.payload = {
        name: params.name
      };
      try {
        const body = await (0, _wreck_requests.requestor)('POST', 'api/notebook/' + params.noteId, wreckOptions);
        return JSON.parse(body.toString());
      } catch (error) {
        throw new Error('Cloning Notebook Error:' + error);
      }
    });
    /* Delete a notebook in Zeppelin Server
     * Param: noteId -> Id for the notebook to be deleted
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook
     */
    _defineProperty(this, "deleteNote", async function (client, noteId, wreckOptions) {
      try {
        const body = await (0, _wreck_requests.requestor)('DELETE', 'api/notebook/' + noteId, wreckOptions);
        return JSON.parse(body.toString());
      } catch (error) {
        throw new Error('Deleting Notebook Error:' + error);
      }
    });
    /* Export a notebook from Zeppelin Server
     * Param: noteId -> Id for the notebook to be exported
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/export/{noteid}
     */
    _defineProperty(this, "exportNote", async function (client, noteId, wreckOptions) {
      try {
        const body = await (0, _wreck_requests.requestor)('GET', 'api/notebook/export/' + noteId, wreckOptions);
        return JSON.parse(body.toString());
      } catch (error) {
        throw new Error('Export Notebook Error:' + error);
      }
    });
    /* Import a notebook in Zeppelin Server
     * Params: noteObj -> note Object to be imported
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/import
     */
    _defineProperty(this, "importNote", async function (client, noteObj, wreckOptions) {
      wreckOptions.payload = noteObj;
      try {
        const body = await (0, _wreck_requests.requestor)('POST', 'api/notebook/import', wreckOptions);
        const respBody = JSON.parse(body.toString());
        return respBody;
      } catch (error) {
        throw new Error('Import Notebook Error:' + error);
      }
    });
    /* Add a paragraph in notebook
     * Params: noteId -> Id for the notebook
     *         paragraphIndex -> index(position) to add a new paragraph
     *         paragraphInput -> paragraph input code
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/[noteId]/paragraph
     */
    _defineProperty(this, "addParagraph", async function (wreckOptions, params) {
      const visualizationPrefix = '%sh #vizobject:';
      const observabilityVisualizationPrefix = '%sh #observabilityviz:';
      let paragraphText = params.paragraphInput;
      if (params.inputType === 'VISUALIZATION' && params.paragraphInput.substring(0, 15) !== visualizationPrefix) {
        paragraphText = visualizationPrefix + paragraphText;
      }
      if (params.inputType === 'OBSERVABILITY_VISUALIZATION' && params.paragraphInput.substring(0, 22) !== observabilityVisualizationPrefix) {
        paragraphText = visualizationPrefix + paragraphText;
      }
      if (params.paragraphInput === '') {
        paragraphText = '%md\n';
      }
      wreckOptions.payload = {
        title: params.inputType,
        text: paragraphText,
        index: params.paragraphIndex
      };
      try {
        const body = await (0, _wreck_requests.requestor)('POST', 'api/notebook/' + params.noteId + '/paragraph', wreckOptions);
        const respBody = JSON.parse(body.toString());
        return respBody;
      } catch (error) {
        throw new Error('Adding Paragraph Error:' + error);
      }
    });
    /* Update a Paragraph in notebook
     * Params: noteId -> Id of the notebook
     *         paragraphId -> Id of the paragraph to be updated
     *         paragraphInput -> paragraph input code
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/[noteId]/paragraph/[paragraphId]
     */
    _defineProperty(this, "updateParagraph", async function (wreckOptions, params) {
      wreckOptions.payload = {
        text: params.paragraphInput
      };
      if (params.paragraphType !== undefined) wreckOptions.payload.title = params.paragraphType;
      try {
        const body = await (0, _wreck_requests.requestor)('PUT', 'api/notebook/' + params.noteId + '/paragraph/' + params.paragraphId, wreckOptions);
        return JSON.parse(body.toString());
      } catch (error) {
        throw new Error('Updating Paragraph Error:' + error);
      }
    });
    /* Run a Paragraph in notebook
     * Params: noteId -> Id of the notebook
     *         paragraphId -> Id of the paragraph to be run
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/run/[noteId]/[paragraphId]
     */
    _defineProperty(this, "runPara", async function (wreckOptions, params) {
      wreckOptions.payload = {};
      try {
        const body = await (0, _wreck_requests.requestor)('POST', 'api/notebook/run/' + params.noteId + '/' + params.paragraphId, wreckOptions);
        return JSON.parse(body.toString()).status;
      } catch (error) {
        throw new Error('Running Paragraph Error:' + error);
      }
    });
    /* Fetch a Paragraph from notebook
     * Params: noteId -> Id of the notebook
     *         paragraphId -> Id of the paragraph to be fetched
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/[noteId]/paragraph/[paragraphId]
     */
    _defineProperty(this, "fetchParagraph", async function (wreckOptions, params) {
      try {
        const body = await (0, _wreck_requests.requestor)('GET', 'api/notebook/' + params.noteId + '/paragraph/' + params.paragraphId, wreckOptions);
        return JSON.parse(body.toString()).body;
      } catch (error) {
        throw new Error('Fetching Paragraph Error:' + error);
      }
    });
    /* Delete a Paragraph in notebook
     * Params: noteId -> Id of the notebook
     *         paragraphId -> Id of the paragraph to be deleted
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/[noteId]/paragraph/[paragraphId]
     */
    _defineProperty(this, "deleteParagraph", async function (wreckOptions, params) {
      wreckOptions.payload = {};
      try {
        const body = await (0, _wreck_requests.requestor)('DELETE', 'api/notebook/' + params.noteId + '/paragraph/' + params.paragraphId, wreckOptions);
        return JSON.parse(body.toString()).status;
      } catch (error) {
        throw new Error('Deleting Paragraph Error:' + error);
      }
    });
    /* Clear all the paragraphs in the notebook
     * Param: noteId -> Id of notebook to be cleared
     * ZS Endpoint => http://[zeppelin-server]:[zeppelin-port]/api/notebook/[noteId]/clear
     */
    _defineProperty(this, "clearAllParagraphs", async function (wreckOptions, noteid) {
      try {
        const body = await (0, _wreck_requests.requestor)('PUT', 'api/notebook/' + noteid + '/clear', wreckOptions);
        return JSON.parse(body.toString()).status;
      } catch (error) {
        throw new Error('Clearing Paragraph Error:' + error);
      }
    });
    /* --> Updates a Paragraph with input content
     * --> Runs it
     * --> Fetches the updated Paragraph (with new input content and output result)
     * Params: noteId -> Id of the notebook
     *         paragraphId -> Id of the paragraph to be updated
     *         paragraphInput -> paragraph input code
     */
    _defineProperty(this, "updateRunFetchParagraph", async function (client, request, wreckOptions) {
      const params = request.params;
      try {
        const updateInfo = await this.updateParagraph(wreckOptions, params);
        const runInfo = await this.runPara(wreckOptions, params);
        const getInfo = await this.fetchParagraph(wreckOptions, params);
        return getInfo;
      } catch (error) {
        throw new Error('Update/Run Paragraph Error:' + error);
      }
    });
    /* --> Updates a Paragraph with input content
     * --> Fetches the updated Paragraph (with new input content)
     * Params: noteId -> Id of the notebook
     *         paragraphId -> Id of the paragraph to be updated
     *         paragraphInput -> paragraph input code
     */
    _defineProperty(this, "updateFetchParagraph", async function (client, params, wreckOptions) {
      try {
        const updateInfo = await this.updateParagraph(wreckOptions, params);
        const getInfo = await this.fetchParagraph(wreckOptions, params);
        return getInfo;
      } catch (error) {
        throw new Error('Save Paragraph Error:' + error);
      }
    });
    /* --> Adds a Paragraph with input content
     * --> Fetches the Paragraph
     * Params: noteId -> Id of the notebook
     *         paragraphId -> Id of the paragraph to be fetched
     */
    _defineProperty(this, "addFetchNewParagraph", async function (client, params, wreckOptions) {
      try {
        const respBody = await this.addParagraph(wreckOptions, params);
        const payload = {
          ...params,
          paragraphId: respBody.body
        };
        const getinfo = await this.fetchParagraph(wreckOptions, payload);
        return getinfo;
      } catch (error) {
        throw new Error('add/Fetch Paragraph Error:' + error);
      }
    });
    /* --> Deletes a Paragraph with id
     * --> Fetches the all other Paragraphs as a list
     * Params: noteId -> Id of the notebook
     *         paragraphId -> Id of the paragraph to be deleted
     */
    _defineProperty(this, "deleteFetchParagraphs", async function (client, params, wreckOptions) {
      try {
        const delinfo = await this.deleteParagraph(wreckOptions, params);
        const notebookinfo = await this.fetchNote(client, params.noteId, wreckOptions);
        return {
          paragraphs: notebookinfo
        };
      } catch (error) {
        throw new Error('Delete Paragraph Error:' + error);
      }
    });
    /* --> Clears output for all the paragraphs
     * --> Fetches the all Paragraphs as a list (with cleared outputs)
     * Param: noteId -> Id of notebook to be cleared
     */
    _defineProperty(this, "clearAllFetchParagraphs", async function (client, params, wreckOptions) {
      try {
        const clearinfo = await this.clearAllParagraphs(wreckOptions, params.noteId);
        const notebookinfo = await this.fetchNote(client, params.noteId, wreckOptions);
        return {
          paragraphs: notebookinfo
        };
      } catch (error) {
        throw new Error('Clear Paragraph Error:' + error);
      }
    });
  }
}
exports.ZeppelinBackend = ZeppelinBackend;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfd3JlY2tfcmVxdWVzdHMiLCJyZXF1aXJlIiwiX2RlZmluZVByb3BlcnR5Iiwib2JqIiwia2V5IiwidmFsdWUiLCJfdG9Qcm9wZXJ0eUtleSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSIsIndyaXRhYmxlIiwiYXJnIiwiX3RvUHJpbWl0aXZlIiwiU3RyaW5nIiwiaW5wdXQiLCJoaW50IiwicHJpbSIsIlN5bWJvbCIsInRvUHJpbWl0aXZlIiwidW5kZWZpbmVkIiwicmVzIiwiY2FsbCIsIlR5cGVFcnJvciIsIk51bWJlciIsIlplcHBlbGluQmFja2VuZCIsImNvbnN0cnVjdG9yIiwiY2xpZW50Iiwid3JlY2tPcHRpb25zIiwib3V0cHV0IiwiYm9keSIsInJlcXVlc3RvciIsIkpTT04iLCJwYXJzZSIsInRvU3RyaW5nIiwiZXJyb3IiLCJFcnJvciIsIm5vdGVJZCIsInBhcmFncmFwaHMiLCJwYXJhbXMiLCJwYXlsb2FkIiwibmFtZSIsIm5vdGVPYmoiLCJyZXNwQm9keSIsInZpc3VhbGl6YXRpb25QcmVmaXgiLCJvYnNlcnZhYmlsaXR5VmlzdWFsaXphdGlvblByZWZpeCIsInBhcmFncmFwaFRleHQiLCJwYXJhZ3JhcGhJbnB1dCIsImlucHV0VHlwZSIsInN1YnN0cmluZyIsInRpdGxlIiwidGV4dCIsImluZGV4IiwicGFyYWdyYXBoSW5kZXgiLCJwYXJhZ3JhcGhUeXBlIiwicGFyYWdyYXBoSWQiLCJzdGF0dXMiLCJub3RlaWQiLCJyZXF1ZXN0IiwidXBkYXRlSW5mbyIsInVwZGF0ZVBhcmFncmFwaCIsInJ1bkluZm8iLCJydW5QYXJhIiwiZ2V0SW5mbyIsImZldGNoUGFyYWdyYXBoIiwiYWRkUGFyYWdyYXBoIiwiZ2V0aW5mbyIsImRlbGluZm8iLCJkZWxldGVQYXJhZ3JhcGgiLCJub3RlYm9va2luZm8iLCJmZXRjaE5vdGUiLCJjbGVhcmluZm8iLCJjbGVhckFsbFBhcmFncmFwaHMiLCJleHBvcnRzIl0sInNvdXJjZXMiOlsiemVwcGVsaW5fYmFja2VuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IG9wdGlvbnNUeXBlIH0gZnJvbSAnLi4vLi4vLi4vY29tbW9uL3R5cGVzL25vdGVib29rcyc7XG5pbXBvcnQgeyByZXF1ZXN0b3IgfSBmcm9tICcuLi8uLi9jb21tb24vaGVscGVycy9ub3RlYm9va3Mvd3JlY2tfcmVxdWVzdHMnO1xuaW1wb3J0IHsgTm90ZWJvb2tBZGFwdG9yIH0gZnJvbSAnLi9ub3RlYm9va19hZGFwdG9yJztcblxuZXhwb3J0IGNsYXNzIFplcHBlbGluQmFja2VuZCBpbXBsZW1lbnRzIE5vdGVib29rQWRhcHRvciB7XG4gIGJhY2tlbmQgPSAnWmVwcGVsaW4gQmFja2VuZCc7XG5cbiAgLy8gR2V0cyBhbGwgdGhlIG5vdGVib29rcyBhdmFpbGFibGUgZnJvbSBaZXBwZWxpbiBTZXJ2ZXJcbiAgLy8gWlMgRW5kcG9pbnQgPT4gaHR0cDovL1t6ZXBwZWxpbi1zZXJ2ZXJdOlt6ZXBwZWxpbi1wb3J0XS9hcGkvbm90ZWJvb2tcbiAgdmlld05vdGVzID0gYXN5bmMgZnVuY3Rpb24gKGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQsIHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGUpIHtcbiAgICB0cnkge1xuICAgICAgbGV0IG91dHB1dCA9IFtdO1xuICAgICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcXVlc3RvcignR0VUJywgJ2FwaS9ub3RlYm9vay8nLCB3cmVja09wdGlvbnMpO1xuICAgICAgb3V0cHV0ID0gSlNPTi5wYXJzZShib2R5LnRvU3RyaW5nKCkpLmJvZHk7XG4gICAgICByZXR1cm4gb3V0cHV0O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1ZpZXcgTm90ZWJvb2tzIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8qIEZldGNoZXMgYSBub3RlYm9vayBieSBpZCBmcm9tIFplcHBlbGluIFNlcnZlclxuICAgKiBQYXJhbTogbm90ZUlkIC0+IElkIG9mIG5vdGVib29rIHRvIGJlIGZldGNoZWRcbiAgICogWlMgRW5kcG9pbnQgPT4gaHR0cDovL1t6ZXBwZWxpbi1zZXJ2ZXJdOlt6ZXBwZWxpbi1wb3J0XS9hcGkvbm90ZWJvb2svW25vdGVJZF1cbiAgICovXG4gIGZldGNoTm90ZSA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICBjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LFxuICAgIG5vdGVJZDogc3RyaW5nLFxuICAgIHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGVcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0b3IoJ0dFVCcsICdhcGkvbm90ZWJvb2svJyArIG5vdGVJZCwgd3JlY2tPcHRpb25zKTtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGJvZHkudG9TdHJpbmcoKSkuYm9keS5wYXJhZ3JhcGhzO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZldGNoaW5nIE5vdGVib29rIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8qIEFkZCBhIG5vdGVib29rIHRvIHRoZSBaZXBwZWxpbiBTZXJ2ZXJcbiAgICogUGFyYW06IG5hbWUgLT4gbmFtZSBvZiBuZXcgbm90ZWJvb2tcbiAgICogWlMgRW5kcG9pbnQgPT4gaHR0cDovL1t6ZXBwZWxpbi1zZXJ2ZXJdOlt6ZXBwZWxpbi1wb3J0XS9hcGkvbm90ZWJvb2tcbiAgICovXG4gIGFkZE5vdGUgPSBhc3luYyBmdW5jdGlvbiAoXG4gICAgY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCxcbiAgICBwYXJhbXM6IHsgbmFtZTogc3RyaW5nIH0sXG4gICAgd3JlY2tPcHRpb25zOiBvcHRpb25zVHlwZVxuICApIHtcbiAgICB3cmVja09wdGlvbnMucGF5bG9hZCA9IHBhcmFtcztcbiAgICB0cnkge1xuICAgICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcXVlc3RvcignUE9TVCcsICdhcGkvbm90ZWJvb2svJywgd3JlY2tPcHRpb25zKTtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGJvZHkudG9TdHJpbmcoKSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ3JlYXRpbmcgTmV3IE5vdGVib29rIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8qIFJlbmFtZSBhIG5vdGVib29rIGluIFplcHBlbGluIFNlcnZlclxuICAgKiBQYXJhbXM6IG5hbWUgLT4gbmV3IG5hbWUgZm9yIHRoZSBub3RlYm9vayB0byBiZSByZW5hbWVkXG4gICAqICAgICAgICAgbm90ZUlkIC0+IElkIG9mIG5vdGVib29rIHRvIGJlIGZldGNoZWRcbiAgICogWlMgRW5kcG9pbnQgPT4gaHR0cDovL1t6ZXBwZWxpbi1zZXJ2ZXJdOlt6ZXBwZWxpbi1wb3J0XS9hcGkvbm90ZWJvb2svW25vdGVJZF0vcmVuYW1lXG4gICAqL1xuICByZW5hbWVOb3RlID0gYXN5bmMgZnVuY3Rpb24gKFxuICAgIGNsaWVudDogSUxlZ2FjeVNjb3BlZENsdXN0ZXJDbGllbnQsXG4gICAgcGFyYW1zOiB7IG5hbWU6IHN0cmluZzsgbm90ZUlkOiBzdHJpbmcgfSxcbiAgICB3cmVja09wdGlvbnM6IG9wdGlvbnNUeXBlXG4gICkge1xuICAgIHdyZWNrT3B0aW9ucy5wYXlsb2FkID0geyBuYW1lOiBwYXJhbXMubmFtZSB9O1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxdWVzdG9yKFxuICAgICAgICAnUFVUJyxcbiAgICAgICAgJ2FwaS9ub3RlYm9vay8nICsgcGFyYW1zLm5vdGVJZCArICcvcmVuYW1lLycsXG4gICAgICAgIHdyZWNrT3B0aW9uc1xuICAgICAgKTtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGJvZHkudG9TdHJpbmcoKSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignUmVuYW1pbmcgTm90ZWJvb2sgRXJyb3I6JyArIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgLyogQ2xvbmUgYSBub3RlYm9vayBpbiBaZXBwZWxpbiBTZXJ2ZXJcbiAgICogUGFyYW1zOiBuYW1lIC0+IG5ldyBuYW1lIGZvciB0aGUgY2xvbmVkIG5vdGVib29rXG4gICAqICAgICAgICAgbm90ZUlkIC0+IElkIGZvciB0aGUgbm90ZWJvb2sgdG8gYmUgY2xvbmVkXG4gICAqIFpTIEVuZHBvaW50ID0+IGh0dHA6Ly9bemVwcGVsaW4tc2VydmVyXTpbemVwcGVsaW4tcG9ydF0vYXBpL25vdGVib29rL1tub3RlSWRdXG4gICAqL1xuICBjbG9uZU5vdGUgPSBhc3luYyBmdW5jdGlvbiAoXG4gICAgY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCxcbiAgICBwYXJhbXM6IHsgbmFtZTogc3RyaW5nOyBub3RlSWQ6IHN0cmluZyB9LFxuICAgIHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGVcbiAgKSB7XG4gICAgd3JlY2tPcHRpb25zLnBheWxvYWQgPSB7IG5hbWU6IHBhcmFtcy5uYW1lIH07XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0b3IoJ1BPU1QnLCAnYXBpL25vdGVib29rLycgKyBwYXJhbXMubm90ZUlkLCB3cmVja09wdGlvbnMpO1xuICAgICAgcmV0dXJuIEpTT04ucGFyc2UoYm9keS50b1N0cmluZygpKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdDbG9uaW5nIE5vdGVib29rIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8qIERlbGV0ZSBhIG5vdGVib29rIGluIFplcHBlbGluIFNlcnZlclxuICAgKiBQYXJhbTogbm90ZUlkIC0+IElkIGZvciB0aGUgbm90ZWJvb2sgdG8gYmUgZGVsZXRlZFxuICAgKiBaUyBFbmRwb2ludCA9PiBodHRwOi8vW3plcHBlbGluLXNlcnZlcl06W3plcHBlbGluLXBvcnRdL2FwaS9ub3RlYm9va1xuICAgKi9cbiAgZGVsZXRlTm90ZSA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICBjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LFxuICAgIG5vdGVJZDogc3RyaW5nLFxuICAgIHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGVcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0b3IoJ0RFTEVURScsICdhcGkvbm90ZWJvb2svJyArIG5vdGVJZCwgd3JlY2tPcHRpb25zKTtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGJvZHkudG9TdHJpbmcoKSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRGVsZXRpbmcgTm90ZWJvb2sgRXJyb3I6JyArIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgLyogRXhwb3J0IGEgbm90ZWJvb2sgZnJvbSBaZXBwZWxpbiBTZXJ2ZXJcbiAgICogUGFyYW06IG5vdGVJZCAtPiBJZCBmb3IgdGhlIG5vdGVib29rIHRvIGJlIGV4cG9ydGVkXG4gICAqIFpTIEVuZHBvaW50ID0+IGh0dHA6Ly9bemVwcGVsaW4tc2VydmVyXTpbemVwcGVsaW4tcG9ydF0vYXBpL25vdGVib29rL2V4cG9ydC97bm90ZWlkfVxuICAgKi9cbiAgZXhwb3J0Tm90ZSA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICBjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LFxuICAgIG5vdGVJZDogc3RyaW5nLFxuICAgIHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGVcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0b3IoJ0dFVCcsICdhcGkvbm90ZWJvb2svZXhwb3J0LycgKyBub3RlSWQsIHdyZWNrT3B0aW9ucyk7XG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShib2R5LnRvU3RyaW5nKCkpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0V4cG9ydCBOb3RlYm9vayBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvKiBJbXBvcnQgYSBub3RlYm9vayBpbiBaZXBwZWxpbiBTZXJ2ZXJcbiAgICogUGFyYW1zOiBub3RlT2JqIC0+IG5vdGUgT2JqZWN0IHRvIGJlIGltcG9ydGVkXG4gICAqIFpTIEVuZHBvaW50ID0+IGh0dHA6Ly9bemVwcGVsaW4tc2VydmVyXTpbemVwcGVsaW4tcG9ydF0vYXBpL25vdGVib29rL2ltcG9ydFxuICAgKi9cbiAgaW1wb3J0Tm90ZSA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICBjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LFxuICAgIG5vdGVPYmo6IGFueSxcbiAgICB3cmVja09wdGlvbnM6IG9wdGlvbnNUeXBlXG4gICkge1xuICAgIHdyZWNrT3B0aW9ucy5wYXlsb2FkID0gbm90ZU9iajtcbiAgICB0cnkge1xuICAgICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcXVlc3RvcignUE9TVCcsICdhcGkvbm90ZWJvb2svaW1wb3J0Jywgd3JlY2tPcHRpb25zKTtcbiAgICAgIGNvbnN0IHJlc3BCb2R5ID0gSlNPTi5wYXJzZShib2R5LnRvU3RyaW5nKCkpO1xuICAgICAgcmV0dXJuIHJlc3BCb2R5O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ltcG9ydCBOb3RlYm9vayBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvKiBBZGQgYSBwYXJhZ3JhcGggaW4gbm90ZWJvb2tcbiAgICogUGFyYW1zOiBub3RlSWQgLT4gSWQgZm9yIHRoZSBub3RlYm9va1xuICAgKiAgICAgICAgIHBhcmFncmFwaEluZGV4IC0+IGluZGV4KHBvc2l0aW9uKSB0byBhZGQgYSBuZXcgcGFyYWdyYXBoXG4gICAqICAgICAgICAgcGFyYWdyYXBoSW5wdXQgLT4gcGFyYWdyYXBoIGlucHV0IGNvZGVcbiAgICogWlMgRW5kcG9pbnQgPT4gaHR0cDovL1t6ZXBwZWxpbi1zZXJ2ZXJdOlt6ZXBwZWxpbi1wb3J0XS9hcGkvbm90ZWJvb2svW25vdGVJZF0vcGFyYWdyYXBoXG4gICAqL1xuICBhZGRQYXJhZ3JhcGggPSBhc3luYyBmdW5jdGlvbiAoXG4gICAgd3JlY2tPcHRpb25zOiBvcHRpb25zVHlwZSxcbiAgICBwYXJhbXM6IHsgcGFyYWdyYXBoSW5kZXg6IG51bWJlcjsgbm90ZUlkOiBzdHJpbmc7IHBhcmFncmFwaElucHV0OiBzdHJpbmc7IGlucHV0VHlwZTogc3RyaW5nIH1cbiAgKSB7XG4gICAgY29uc3QgdmlzdWFsaXphdGlvblByZWZpeCA9ICclc2ggI3Zpem9iamVjdDonO1xuICAgIGNvbnN0IG9ic2VydmFiaWxpdHlWaXN1YWxpemF0aW9uUHJlZml4ID0gJyVzaCAjb2JzZXJ2YWJpbGl0eXZpejonO1xuICAgIGxldCBwYXJhZ3JhcGhUZXh0ID0gcGFyYW1zLnBhcmFncmFwaElucHV0O1xuXG4gICAgaWYgKFxuICAgICAgcGFyYW1zLmlucHV0VHlwZSA9PT0gJ1ZJU1VBTElaQVRJT04nICYmXG4gICAgICBwYXJhbXMucGFyYWdyYXBoSW5wdXQuc3Vic3RyaW5nKDAsIDE1KSAhPT0gdmlzdWFsaXphdGlvblByZWZpeFxuICAgICkge1xuICAgICAgcGFyYWdyYXBoVGV4dCA9IHZpc3VhbGl6YXRpb25QcmVmaXggKyBwYXJhZ3JhcGhUZXh0O1xuICAgIH1cblxuICAgIGlmIChcbiAgICAgIHBhcmFtcy5pbnB1dFR5cGUgPT09ICdPQlNFUlZBQklMSVRZX1ZJU1VBTElaQVRJT04nICYmXG4gICAgICBwYXJhbXMucGFyYWdyYXBoSW5wdXQuc3Vic3RyaW5nKDAsIDIyKSAhPT0gb2JzZXJ2YWJpbGl0eVZpc3VhbGl6YXRpb25QcmVmaXhcbiAgICApIHtcbiAgICAgIHBhcmFncmFwaFRleHQgPSB2aXN1YWxpemF0aW9uUHJlZml4ICsgcGFyYWdyYXBoVGV4dDtcbiAgICB9XG5cbiAgICBpZiAocGFyYW1zLnBhcmFncmFwaElucHV0ID09PSAnJykge1xuICAgICAgcGFyYWdyYXBoVGV4dCA9ICclbWRcXG4nO1xuICAgIH1cblxuICAgIHdyZWNrT3B0aW9ucy5wYXlsb2FkID0ge1xuICAgICAgdGl0bGU6IHBhcmFtcy5pbnB1dFR5cGUsXG4gICAgICB0ZXh0OiBwYXJhZ3JhcGhUZXh0LFxuICAgICAgaW5kZXg6IHBhcmFtcy5wYXJhZ3JhcGhJbmRleCxcbiAgICB9O1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0b3IoXG4gICAgICAgICdQT1NUJyxcbiAgICAgICAgJ2FwaS9ub3RlYm9vay8nICsgcGFyYW1zLm5vdGVJZCArICcvcGFyYWdyYXBoJyxcbiAgICAgICAgd3JlY2tPcHRpb25zXG4gICAgICApO1xuICAgICAgY29uc3QgcmVzcEJvZHkgPSBKU09OLnBhcnNlKGJvZHkudG9TdHJpbmcoKSk7XG4gICAgICByZXR1cm4gcmVzcEJvZHk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQWRkaW5nIFBhcmFncmFwaCBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvKiBVcGRhdGUgYSBQYXJhZ3JhcGggaW4gbm90ZWJvb2tcbiAgICogUGFyYW1zOiBub3RlSWQgLT4gSWQgb2YgdGhlIG5vdGVib29rXG4gICAqICAgICAgICAgcGFyYWdyYXBoSWQgLT4gSWQgb2YgdGhlIHBhcmFncmFwaCB0byBiZSB1cGRhdGVkXG4gICAqICAgICAgICAgcGFyYWdyYXBoSW5wdXQgLT4gcGFyYWdyYXBoIGlucHV0IGNvZGVcbiAgICogWlMgRW5kcG9pbnQgPT4gaHR0cDovL1t6ZXBwZWxpbi1zZXJ2ZXJdOlt6ZXBwZWxpbi1wb3J0XS9hcGkvbm90ZWJvb2svW25vdGVJZF0vcGFyYWdyYXBoL1twYXJhZ3JhcGhJZF1cbiAgICovXG4gIHVwZGF0ZVBhcmFncmFwaCA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICB3cmVja09wdGlvbnM6IG9wdGlvbnNUeXBlLFxuICAgIHBhcmFtczogeyBub3RlSWQ6IHN0cmluZzsgcGFyYWdyYXBoSWQ6IHN0cmluZzsgcGFyYWdyYXBoSW5wdXQ6IHN0cmluZzsgcGFyYWdyYXBoVHlwZT86IHN0cmluZyB9XG4gICkge1xuICAgIHdyZWNrT3B0aW9ucy5wYXlsb2FkID0ge1xuICAgICAgdGV4dDogcGFyYW1zLnBhcmFncmFwaElucHV0LFxuICAgIH07XG4gICAgaWYgKHBhcmFtcy5wYXJhZ3JhcGhUeXBlICE9PSB1bmRlZmluZWQpIHdyZWNrT3B0aW9ucy5wYXlsb2FkLnRpdGxlID0gcGFyYW1zLnBhcmFncmFwaFR5cGU7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0b3IoXG4gICAgICAgICdQVVQnLFxuICAgICAgICAnYXBpL25vdGVib29rLycgKyBwYXJhbXMubm90ZUlkICsgJy9wYXJhZ3JhcGgvJyArIHBhcmFtcy5wYXJhZ3JhcGhJZCxcbiAgICAgICAgd3JlY2tPcHRpb25zXG4gICAgICApO1xuICAgICAgcmV0dXJuIEpTT04ucGFyc2UoYm9keS50b1N0cmluZygpKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdVcGRhdGluZyBQYXJhZ3JhcGggRXJyb3I6JyArIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgLyogUnVuIGEgUGFyYWdyYXBoIGluIG5vdGVib29rXG4gICAqIFBhcmFtczogbm90ZUlkIC0+IElkIG9mIHRoZSBub3RlYm9va1xuICAgKiAgICAgICAgIHBhcmFncmFwaElkIC0+IElkIG9mIHRoZSBwYXJhZ3JhcGggdG8gYmUgcnVuXG4gICAqIFpTIEVuZHBvaW50ID0+IGh0dHA6Ly9bemVwcGVsaW4tc2VydmVyXTpbemVwcGVsaW4tcG9ydF0vYXBpL25vdGVib29rL3J1bi9bbm90ZUlkXS9bcGFyYWdyYXBoSWRdXG4gICAqL1xuICBydW5QYXJhID0gYXN5bmMgZnVuY3Rpb24gKFxuICAgIHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGUsXG4gICAgcGFyYW1zOiB7IG5vdGVJZDogc3RyaW5nOyBwYXJhZ3JhcGhJZDogc3RyaW5nIH1cbiAgKSB7XG4gICAgd3JlY2tPcHRpb25zLnBheWxvYWQgPSB7fTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcXVlc3RvcihcbiAgICAgICAgJ1BPU1QnLFxuICAgICAgICAnYXBpL25vdGVib29rL3J1bi8nICsgcGFyYW1zLm5vdGVJZCArICcvJyArIHBhcmFtcy5wYXJhZ3JhcGhJZCxcbiAgICAgICAgd3JlY2tPcHRpb25zXG4gICAgICApO1xuICAgICAgcmV0dXJuIEpTT04ucGFyc2UoYm9keS50b1N0cmluZygpKS5zdGF0dXM7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignUnVubmluZyBQYXJhZ3JhcGggRXJyb3I6JyArIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgLyogRmV0Y2ggYSBQYXJhZ3JhcGggZnJvbSBub3RlYm9va1xuICAgKiBQYXJhbXM6IG5vdGVJZCAtPiBJZCBvZiB0aGUgbm90ZWJvb2tcbiAgICogICAgICAgICBwYXJhZ3JhcGhJZCAtPiBJZCBvZiB0aGUgcGFyYWdyYXBoIHRvIGJlIGZldGNoZWRcbiAgICogWlMgRW5kcG9pbnQgPT4gaHR0cDovL1t6ZXBwZWxpbi1zZXJ2ZXJdOlt6ZXBwZWxpbi1wb3J0XS9hcGkvbm90ZWJvb2svW25vdGVJZF0vcGFyYWdyYXBoL1twYXJhZ3JhcGhJZF1cbiAgICovXG4gIGZldGNoUGFyYWdyYXBoID0gYXN5bmMgZnVuY3Rpb24gKFxuICAgIHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGUsXG4gICAgcGFyYW1zOiB7IG5vdGVJZDogc3RyaW5nOyBwYXJhZ3JhcGhJZDogc3RyaW5nIH1cbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0b3IoXG4gICAgICAgICdHRVQnLFxuICAgICAgICAnYXBpL25vdGVib29rLycgKyBwYXJhbXMubm90ZUlkICsgJy9wYXJhZ3JhcGgvJyArIHBhcmFtcy5wYXJhZ3JhcGhJZCxcbiAgICAgICAgd3JlY2tPcHRpb25zXG4gICAgICApO1xuICAgICAgcmV0dXJuIEpTT04ucGFyc2UoYm9keS50b1N0cmluZygpKS5ib2R5O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZldGNoaW5nIFBhcmFncmFwaCBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvKiBEZWxldGUgYSBQYXJhZ3JhcGggaW4gbm90ZWJvb2tcbiAgICogUGFyYW1zOiBub3RlSWQgLT4gSWQgb2YgdGhlIG5vdGVib29rXG4gICAqICAgICAgICAgcGFyYWdyYXBoSWQgLT4gSWQgb2YgdGhlIHBhcmFncmFwaCB0byBiZSBkZWxldGVkXG4gICAqIFpTIEVuZHBvaW50ID0+IGh0dHA6Ly9bemVwcGVsaW4tc2VydmVyXTpbemVwcGVsaW4tcG9ydF0vYXBpL25vdGVib29rL1tub3RlSWRdL3BhcmFncmFwaC9bcGFyYWdyYXBoSWRdXG4gICAqL1xuICBkZWxldGVQYXJhZ3JhcGggPSBhc3luYyBmdW5jdGlvbiAoXG4gICAgd3JlY2tPcHRpb25zOiBvcHRpb25zVHlwZSxcbiAgICBwYXJhbXM6IHsgbm90ZUlkOiBzdHJpbmc7IHBhcmFncmFwaElkOiBzdHJpbmcgfVxuICApIHtcbiAgICB3cmVja09wdGlvbnMucGF5bG9hZCA9IHt9O1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVxdWVzdG9yKFxuICAgICAgICAnREVMRVRFJyxcbiAgICAgICAgJ2FwaS9ub3RlYm9vay8nICsgcGFyYW1zLm5vdGVJZCArICcvcGFyYWdyYXBoLycgKyBwYXJhbXMucGFyYWdyYXBoSWQsXG4gICAgICAgIHdyZWNrT3B0aW9uc1xuICAgICAgKTtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGJvZHkudG9TdHJpbmcoKSkuc3RhdHVzO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0RlbGV0aW5nIFBhcmFncmFwaCBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvKiBDbGVhciBhbGwgdGhlIHBhcmFncmFwaHMgaW4gdGhlIG5vdGVib29rXG4gICAqIFBhcmFtOiBub3RlSWQgLT4gSWQgb2Ygbm90ZWJvb2sgdG8gYmUgY2xlYXJlZFxuICAgKiBaUyBFbmRwb2ludCA9PiBodHRwOi8vW3plcHBlbGluLXNlcnZlcl06W3plcHBlbGluLXBvcnRdL2FwaS9ub3RlYm9vay9bbm90ZUlkXS9jbGVhclxuICAgKi9cbiAgY2xlYXJBbGxQYXJhZ3JhcGhzID0gYXN5bmMgZnVuY3Rpb24gKHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGUsIG5vdGVpZDogc3RyaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0b3IoJ1BVVCcsICdhcGkvbm90ZWJvb2svJyArIG5vdGVpZCArICcvY2xlYXInLCB3cmVja09wdGlvbnMpO1xuICAgICAgcmV0dXJuIEpTT04ucGFyc2UoYm9keS50b1N0cmluZygpKS5zdGF0dXM7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2xlYXJpbmcgUGFyYWdyYXBoIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8qIC0tPiBVcGRhdGVzIGEgUGFyYWdyYXBoIHdpdGggaW5wdXQgY29udGVudFxuICAgKiAtLT4gUnVucyBpdFxuICAgKiAtLT4gRmV0Y2hlcyB0aGUgdXBkYXRlZCBQYXJhZ3JhcGggKHdpdGggbmV3IGlucHV0IGNvbnRlbnQgYW5kIG91dHB1dCByZXN1bHQpXG4gICAqIFBhcmFtczogbm90ZUlkIC0+IElkIG9mIHRoZSBub3RlYm9va1xuICAgKiAgICAgICAgIHBhcmFncmFwaElkIC0+IElkIG9mIHRoZSBwYXJhZ3JhcGggdG8gYmUgdXBkYXRlZFxuICAgKiAgICAgICAgIHBhcmFncmFwaElucHV0IC0+IHBhcmFncmFwaCBpbnB1dCBjb2RlXG4gICAqL1xuICB1cGRhdGVSdW5GZXRjaFBhcmFncmFwaCA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICBjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LFxuICAgIHJlcXVlc3Q6IGFueSxcbiAgICB3cmVja09wdGlvbnM6IG9wdGlvbnNUeXBlXG4gICkge1xuICAgIGNvbnN0IHBhcmFtcyA9IHJlcXVlc3QucGFyYW1zO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1cGRhdGVJbmZvID0gYXdhaXQgdGhpcy51cGRhdGVQYXJhZ3JhcGgod3JlY2tPcHRpb25zLCBwYXJhbXMpO1xuICAgICAgY29uc3QgcnVuSW5mbyA9IGF3YWl0IHRoaXMucnVuUGFyYSh3cmVja09wdGlvbnMsIHBhcmFtcyk7XG4gICAgICBjb25zdCBnZXRJbmZvID0gYXdhaXQgdGhpcy5mZXRjaFBhcmFncmFwaCh3cmVja09wdGlvbnMsIHBhcmFtcyk7XG4gICAgICByZXR1cm4gZ2V0SW5mbztcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdVcGRhdGUvUnVuIFBhcmFncmFwaCBFcnJvcjonICsgZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAvKiAtLT4gVXBkYXRlcyBhIFBhcmFncmFwaCB3aXRoIGlucHV0IGNvbnRlbnRcbiAgICogLS0+IEZldGNoZXMgdGhlIHVwZGF0ZWQgUGFyYWdyYXBoICh3aXRoIG5ldyBpbnB1dCBjb250ZW50KVxuICAgKiBQYXJhbXM6IG5vdGVJZCAtPiBJZCBvZiB0aGUgbm90ZWJvb2tcbiAgICogICAgICAgICBwYXJhZ3JhcGhJZCAtPiBJZCBvZiB0aGUgcGFyYWdyYXBoIHRvIGJlIHVwZGF0ZWRcbiAgICogICAgICAgICBwYXJhZ3JhcGhJbnB1dCAtPiBwYXJhZ3JhcGggaW5wdXQgY29kZVxuICAgKi9cbiAgdXBkYXRlRmV0Y2hQYXJhZ3JhcGggPSBhc3luYyBmdW5jdGlvbiAoXG4gICAgY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCxcbiAgICBwYXJhbXM6IHsgbm90ZUlkOiBzdHJpbmc7IHBhcmFncmFwaElkOiBzdHJpbmc7IHBhcmFncmFwaElucHV0OiBzdHJpbmcgfSxcbiAgICB3cmVja09wdGlvbnM6IG9wdGlvbnNUeXBlXG4gICkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1cGRhdGVJbmZvID0gYXdhaXQgdGhpcy51cGRhdGVQYXJhZ3JhcGgod3JlY2tPcHRpb25zLCBwYXJhbXMpO1xuICAgICAgY29uc3QgZ2V0SW5mbyA9IGF3YWl0IHRoaXMuZmV0Y2hQYXJhZ3JhcGgod3JlY2tPcHRpb25zLCBwYXJhbXMpO1xuICAgICAgcmV0dXJuIGdldEluZm87XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignU2F2ZSBQYXJhZ3JhcGggRXJyb3I6JyArIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgLyogLS0+IEFkZHMgYSBQYXJhZ3JhcGggd2l0aCBpbnB1dCBjb250ZW50XG4gICAqIC0tPiBGZXRjaGVzIHRoZSBQYXJhZ3JhcGhcbiAgICogUGFyYW1zOiBub3RlSWQgLT4gSWQgb2YgdGhlIG5vdGVib29rXG4gICAqICAgICAgICAgcGFyYWdyYXBoSWQgLT4gSWQgb2YgdGhlIHBhcmFncmFwaCB0byBiZSBmZXRjaGVkXG4gICAqL1xuICBhZGRGZXRjaE5ld1BhcmFncmFwaCA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICBjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LFxuICAgIHBhcmFtczogeyBub3RlSWQ6IHN0cmluZzsgcGFyYWdyYXBoSW5kZXg6IG51bWJlcjsgcGFyYWdyYXBoSW5wdXQ6IHN0cmluZzsgaW5wdXRUeXBlOiBzdHJpbmcgfSxcbiAgICB3cmVja09wdGlvbnM6IG9wdGlvbnNUeXBlXG4gICkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwQm9keSA9IGF3YWl0IHRoaXMuYWRkUGFyYWdyYXBoKHdyZWNrT3B0aW9ucywgcGFyYW1zKTtcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7IC4uLnBhcmFtcywgcGFyYWdyYXBoSWQ6IHJlc3BCb2R5LmJvZHkgfTtcbiAgICAgIGNvbnN0IGdldGluZm8gPSBhd2FpdCB0aGlzLmZldGNoUGFyYWdyYXBoKHdyZWNrT3B0aW9ucywgcGF5bG9hZCk7XG4gICAgICByZXR1cm4gZ2V0aW5mbztcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdhZGQvRmV0Y2ggUGFyYWdyYXBoIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8qIC0tPiBEZWxldGVzIGEgUGFyYWdyYXBoIHdpdGggaWRcbiAgICogLS0+IEZldGNoZXMgdGhlIGFsbCBvdGhlciBQYXJhZ3JhcGhzIGFzIGEgbGlzdFxuICAgKiBQYXJhbXM6IG5vdGVJZCAtPiBJZCBvZiB0aGUgbm90ZWJvb2tcbiAgICogICAgICAgICBwYXJhZ3JhcGhJZCAtPiBJZCBvZiB0aGUgcGFyYWdyYXBoIHRvIGJlIGRlbGV0ZWRcbiAgICovXG4gIGRlbGV0ZUZldGNoUGFyYWdyYXBocyA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICBjbGllbnQ6IElMZWdhY3lTY29wZWRDbHVzdGVyQ2xpZW50LFxuICAgIHBhcmFtczogeyBub3RlSWQ6IHN0cmluZzsgcGFyYWdyYXBoSWQ6IHN0cmluZyB9LFxuICAgIHdyZWNrT3B0aW9uczogb3B0aW9uc1R5cGVcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRlbGluZm8gPSBhd2FpdCB0aGlzLmRlbGV0ZVBhcmFncmFwaCh3cmVja09wdGlvbnMsIHBhcmFtcyk7XG4gICAgICBjb25zdCBub3RlYm9va2luZm8gPSBhd2FpdCB0aGlzLmZldGNoTm90ZShjbGllbnQsIHBhcmFtcy5ub3RlSWQsIHdyZWNrT3B0aW9ucyk7XG4gICAgICByZXR1cm4geyBwYXJhZ3JhcGhzOiBub3RlYm9va2luZm8gfTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdEZWxldGUgUGFyYWdyYXBoIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIC8qIC0tPiBDbGVhcnMgb3V0cHV0IGZvciBhbGwgdGhlIHBhcmFncmFwaHNcbiAgICogLS0+IEZldGNoZXMgdGhlIGFsbCBQYXJhZ3JhcGhzIGFzIGEgbGlzdCAod2l0aCBjbGVhcmVkIG91dHB1dHMpXG4gICAqIFBhcmFtOiBub3RlSWQgLT4gSWQgb2Ygbm90ZWJvb2sgdG8gYmUgY2xlYXJlZFxuICAgKi9cbiAgY2xlYXJBbGxGZXRjaFBhcmFncmFwaHMgPSBhc3luYyBmdW5jdGlvbiAoXG4gICAgY2xpZW50OiBJTGVnYWN5U2NvcGVkQ2x1c3RlckNsaWVudCxcbiAgICBwYXJhbXM6IHsgbm90ZUlkOiBzdHJpbmcgfSxcbiAgICB3cmVja09wdGlvbnM6IG9wdGlvbnNUeXBlXG4gICkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjbGVhcmluZm8gPSBhd2FpdCB0aGlzLmNsZWFyQWxsUGFyYWdyYXBocyh3cmVja09wdGlvbnMsIHBhcmFtcy5ub3RlSWQpO1xuICAgICAgY29uc3Qgbm90ZWJvb2tpbmZvID0gYXdhaXQgdGhpcy5mZXRjaE5vdGUoY2xpZW50LCBwYXJhbXMubm90ZUlkLCB3cmVja09wdGlvbnMpO1xuICAgICAgcmV0dXJuIHsgcGFyYWdyYXBoczogbm90ZWJvb2tpbmZvIH07XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2xlYXIgUGFyYWdyYXBoIEVycm9yOicgKyBlcnJvcik7XG4gICAgfVxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFPQSxJQUFBQSxlQUFBLEdBQUFDLE9BQUE7QUFBMEUsU0FBQUMsZ0JBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxLQUFBLElBQUFELEdBQUEsR0FBQUUsY0FBQSxDQUFBRixHQUFBLE9BQUFBLEdBQUEsSUFBQUQsR0FBQSxJQUFBSSxNQUFBLENBQUFDLGNBQUEsQ0FBQUwsR0FBQSxFQUFBQyxHQUFBLElBQUFDLEtBQUEsRUFBQUEsS0FBQSxFQUFBSSxVQUFBLFFBQUFDLFlBQUEsUUFBQUMsUUFBQSxvQkFBQVIsR0FBQSxDQUFBQyxHQUFBLElBQUFDLEtBQUEsV0FBQUYsR0FBQTtBQUFBLFNBQUFHLGVBQUFNLEdBQUEsUUFBQVIsR0FBQSxHQUFBUyxZQUFBLENBQUFELEdBQUEsMkJBQUFSLEdBQUEsZ0JBQUFBLEdBQUEsR0FBQVUsTUFBQSxDQUFBVixHQUFBO0FBQUEsU0FBQVMsYUFBQUUsS0FBQSxFQUFBQyxJQUFBLGVBQUFELEtBQUEsaUJBQUFBLEtBQUEsa0JBQUFBLEtBQUEsTUFBQUUsSUFBQSxHQUFBRixLQUFBLENBQUFHLE1BQUEsQ0FBQUMsV0FBQSxPQUFBRixJQUFBLEtBQUFHLFNBQUEsUUFBQUMsR0FBQSxHQUFBSixJQUFBLENBQUFLLElBQUEsQ0FBQVAsS0FBQSxFQUFBQyxJQUFBLDJCQUFBSyxHQUFBLHNCQUFBQSxHQUFBLFlBQUFFLFNBQUEsNERBQUFQLElBQUEsZ0JBQUFGLE1BQUEsR0FBQVUsTUFBQSxFQUFBVCxLQUFBLEtBUDFFO0FBQ0E7QUFDQTtBQUNBO0FBT08sTUFBTVUsZUFBZSxDQUE0QjtFQUFBQyxZQUFBO0lBQUF4QixlQUFBLGtCQUM1QyxrQkFBa0I7SUFFNUI7SUFDQTtJQUFBQSxlQUFBLG9CQUNZLGdCQUFnQnlCLE1BQWtDLEVBQUVDLFlBQXlCLEVBQUU7TUFDekYsSUFBSTtRQUNGLElBQUlDLE1BQU0sR0FBRyxFQUFFO1FBQ2YsTUFBTUMsSUFBSSxHQUFHLE1BQU0sSUFBQUMseUJBQVMsRUFBQyxLQUFLLEVBQUUsZUFBZSxFQUFFSCxZQUFZLENBQUM7UUFDbEVDLE1BQU0sR0FBR0csSUFBSSxDQUFDQyxLQUFLLENBQUNILElBQUksQ0FBQ0ksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDSixJQUFJO1FBQ3pDLE9BQU9ELE1BQU07TUFDZixDQUFDLENBQUMsT0FBT00sS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMsdUJBQXVCLEdBQUdELEtBQUssQ0FBQztNQUNsRDtJQUNGLENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtJQUhFakMsZUFBQSxvQkFJWSxnQkFDVnlCLE1BQWtDLEVBQ2xDVSxNQUFjLEVBQ2RULFlBQXlCLEVBQ3pCO01BQ0EsSUFBSTtRQUNGLE1BQU1FLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFTLEVBQUMsS0FBSyxFQUFFLGVBQWUsR0FBR00sTUFBTSxFQUFFVCxZQUFZLENBQUM7UUFDM0UsT0FBT0ksSUFBSSxDQUFDQyxLQUFLLENBQUNILElBQUksQ0FBQ0ksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUNRLFVBQVU7TUFDcEQsQ0FBQyxDQUFDLE9BQU9ILEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLDBCQUEwQixHQUFHRCxLQUFLLENBQUM7TUFDckQ7SUFDRixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7SUFIRWpDLGVBQUEsa0JBSVUsZ0JBQ1J5QixNQUFrQyxFQUNsQ1ksTUFBd0IsRUFDeEJYLFlBQXlCLEVBQ3pCO01BQ0FBLFlBQVksQ0FBQ1ksT0FBTyxHQUFHRCxNQUFNO01BQzdCLElBQUk7UUFDRixNQUFNVCxJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBUyxFQUFDLE1BQU0sRUFBRSxlQUFlLEVBQUVILFlBQVksQ0FBQztRQUNuRSxPQUFPSSxJQUFJLENBQUNDLEtBQUssQ0FBQ0gsSUFBSSxDQUFDSSxRQUFRLENBQUMsQ0FBQyxDQUFDO01BQ3BDLENBQUMsQ0FBQyxPQUFPQyxLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyw4QkFBOEIsR0FBR0QsS0FBSyxDQUFDO01BQ3pEO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7SUFKRWpDLGVBQUEscUJBS2EsZ0JBQ1h5QixNQUFrQyxFQUNsQ1ksTUFBd0MsRUFDeENYLFlBQXlCLEVBQ3pCO01BQ0FBLFlBQVksQ0FBQ1ksT0FBTyxHQUFHO1FBQUVDLElBQUksRUFBRUYsTUFBTSxDQUFDRTtNQUFLLENBQUM7TUFDNUMsSUFBSTtRQUNGLE1BQU1YLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFTLEVBQzFCLEtBQUssRUFDTCxlQUFlLEdBQUdRLE1BQU0sQ0FBQ0YsTUFBTSxHQUFHLFVBQVUsRUFDNUNULFlBQ0YsQ0FBQztRQUNELE9BQU9JLElBQUksQ0FBQ0MsS0FBSyxDQUFDSCxJQUFJLENBQUNJLFFBQVEsQ0FBQyxDQUFDLENBQUM7TUFDcEMsQ0FBQyxDQUFDLE9BQU9DLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLDBCQUEwQixHQUFHRCxLQUFLLENBQUM7TUFDckQ7SUFDRixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtJQUpFakMsZUFBQSxvQkFLWSxnQkFDVnlCLE1BQWtDLEVBQ2xDWSxNQUF3QyxFQUN4Q1gsWUFBeUIsRUFDekI7TUFDQUEsWUFBWSxDQUFDWSxPQUFPLEdBQUc7UUFBRUMsSUFBSSxFQUFFRixNQUFNLENBQUNFO01BQUssQ0FBQztNQUM1QyxJQUFJO1FBQ0YsTUFBTVgsSUFBSSxHQUFHLE1BQU0sSUFBQUMseUJBQVMsRUFBQyxNQUFNLEVBQUUsZUFBZSxHQUFHUSxNQUFNLENBQUNGLE1BQU0sRUFBRVQsWUFBWSxDQUFDO1FBQ25GLE9BQU9JLElBQUksQ0FBQ0MsS0FBSyxDQUFDSCxJQUFJLENBQUNJLFFBQVEsQ0FBQyxDQUFDLENBQUM7TUFDcEMsQ0FBQyxDQUFDLE9BQU9DLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLHlCQUF5QixHQUFHRCxLQUFLLENBQUM7TUFDcEQ7SUFDRixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7SUFIRWpDLGVBQUEscUJBSWEsZ0JBQ1h5QixNQUFrQyxFQUNsQ1UsTUFBYyxFQUNkVCxZQUF5QixFQUN6QjtNQUNBLElBQUk7UUFDRixNQUFNRSxJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBUyxFQUFDLFFBQVEsRUFBRSxlQUFlLEdBQUdNLE1BQU0sRUFBRVQsWUFBWSxDQUFDO1FBQzlFLE9BQU9JLElBQUksQ0FBQ0MsS0FBSyxDQUFDSCxJQUFJLENBQUNJLFFBQVEsQ0FBQyxDQUFDLENBQUM7TUFDcEMsQ0FBQyxDQUFDLE9BQU9DLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLDBCQUEwQixHQUFHRCxLQUFLLENBQUM7TUFDckQ7SUFDRixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7SUFIRWpDLGVBQUEscUJBSWEsZ0JBQ1h5QixNQUFrQyxFQUNsQ1UsTUFBYyxFQUNkVCxZQUF5QixFQUN6QjtNQUNBLElBQUk7UUFDRixNQUFNRSxJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBUyxFQUFDLEtBQUssRUFBRSxzQkFBc0IsR0FBR00sTUFBTSxFQUFFVCxZQUFZLENBQUM7UUFDbEYsT0FBT0ksSUFBSSxDQUFDQyxLQUFLLENBQUNILElBQUksQ0FBQ0ksUUFBUSxDQUFDLENBQUMsQ0FBQztNQUNwQyxDQUFDLENBQUMsT0FBT0MsS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMsd0JBQXdCLEdBQUdELEtBQUssQ0FBQztNQUNuRDtJQUNGLENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtJQUhFakMsZUFBQSxxQkFJYSxnQkFDWHlCLE1BQWtDLEVBQ2xDZSxPQUFZLEVBQ1pkLFlBQXlCLEVBQ3pCO01BQ0FBLFlBQVksQ0FBQ1ksT0FBTyxHQUFHRSxPQUFPO01BQzlCLElBQUk7UUFDRixNQUFNWixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBUyxFQUFDLE1BQU0sRUFBRSxxQkFBcUIsRUFBRUgsWUFBWSxDQUFDO1FBQ3pFLE1BQU1lLFFBQVEsR0FBR1gsSUFBSSxDQUFDQyxLQUFLLENBQUNILElBQUksQ0FBQ0ksUUFBUSxDQUFDLENBQUMsQ0FBQztRQUM1QyxPQUFPUyxRQUFRO01BQ2pCLENBQUMsQ0FBQyxPQUFPUixLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyx3QkFBd0IsR0FBR0QsS0FBSyxDQUFDO01BQ25EO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUxFakMsZUFBQSx1QkFNZSxnQkFDYjBCLFlBQXlCLEVBQ3pCVyxNQUE2RixFQUM3RjtNQUNBLE1BQU1LLG1CQUFtQixHQUFHLGlCQUFpQjtNQUM3QyxNQUFNQyxnQ0FBZ0MsR0FBRyx3QkFBd0I7TUFDakUsSUFBSUMsYUFBYSxHQUFHUCxNQUFNLENBQUNRLGNBQWM7TUFFekMsSUFDRVIsTUFBTSxDQUFDUyxTQUFTLEtBQUssZUFBZSxJQUNwQ1QsTUFBTSxDQUFDUSxjQUFjLENBQUNFLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEtBQUtMLG1CQUFtQixFQUM5RDtRQUNBRSxhQUFhLEdBQUdGLG1CQUFtQixHQUFHRSxhQUFhO01BQ3JEO01BRUEsSUFDRVAsTUFBTSxDQUFDUyxTQUFTLEtBQUssNkJBQTZCLElBQ2xEVCxNQUFNLENBQUNRLGNBQWMsQ0FBQ0UsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBS0osZ0NBQWdDLEVBQzNFO1FBQ0FDLGFBQWEsR0FBR0YsbUJBQW1CLEdBQUdFLGFBQWE7TUFDckQ7TUFFQSxJQUFJUCxNQUFNLENBQUNRLGNBQWMsS0FBSyxFQUFFLEVBQUU7UUFDaENELGFBQWEsR0FBRyxPQUFPO01BQ3pCO01BRUFsQixZQUFZLENBQUNZLE9BQU8sR0FBRztRQUNyQlUsS0FBSyxFQUFFWCxNQUFNLENBQUNTLFNBQVM7UUFDdkJHLElBQUksRUFBRUwsYUFBYTtRQUNuQk0sS0FBSyxFQUFFYixNQUFNLENBQUNjO01BQ2hCLENBQUM7TUFFRCxJQUFJO1FBQ0YsTUFBTXZCLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFTLEVBQzFCLE1BQU0sRUFDTixlQUFlLEdBQUdRLE1BQU0sQ0FBQ0YsTUFBTSxHQUFHLFlBQVksRUFDOUNULFlBQ0YsQ0FBQztRQUNELE1BQU1lLFFBQVEsR0FBR1gsSUFBSSxDQUFDQyxLQUFLLENBQUNILElBQUksQ0FBQ0ksUUFBUSxDQUFDLENBQUMsQ0FBQztRQUM1QyxPQUFPUyxRQUFRO01BQ2pCLENBQUMsQ0FBQyxPQUFPUixLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyx5QkFBeUIsR0FBR0QsS0FBSyxDQUFDO01BQ3BEO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUxFakMsZUFBQSwwQkFNa0IsZ0JBQ2hCMEIsWUFBeUIsRUFDekJXLE1BQStGLEVBQy9GO01BQ0FYLFlBQVksQ0FBQ1ksT0FBTyxHQUFHO1FBQ3JCVyxJQUFJLEVBQUVaLE1BQU0sQ0FBQ1E7TUFDZixDQUFDO01BQ0QsSUFBSVIsTUFBTSxDQUFDZSxhQUFhLEtBQUtsQyxTQUFTLEVBQUVRLFlBQVksQ0FBQ1ksT0FBTyxDQUFDVSxLQUFLLEdBQUdYLE1BQU0sQ0FBQ2UsYUFBYTtNQUN6RixJQUFJO1FBQ0YsTUFBTXhCLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFTLEVBQzFCLEtBQUssRUFDTCxlQUFlLEdBQUdRLE1BQU0sQ0FBQ0YsTUFBTSxHQUFHLGFBQWEsR0FBR0UsTUFBTSxDQUFDZ0IsV0FBVyxFQUNwRTNCLFlBQ0YsQ0FBQztRQUNELE9BQU9JLElBQUksQ0FBQ0MsS0FBSyxDQUFDSCxJQUFJLENBQUNJLFFBQVEsQ0FBQyxDQUFDLENBQUM7TUFDcEMsQ0FBQyxDQUFDLE9BQU9DLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLDJCQUEyQixHQUFHRCxLQUFLLENBQUM7TUFDdEQ7SUFDRixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtJQUpFakMsZUFBQSxrQkFLVSxnQkFDUjBCLFlBQXlCLEVBQ3pCVyxNQUErQyxFQUMvQztNQUNBWCxZQUFZLENBQUNZLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDekIsSUFBSTtRQUNGLE1BQU1WLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFTLEVBQzFCLE1BQU0sRUFDTixtQkFBbUIsR0FBR1EsTUFBTSxDQUFDRixNQUFNLEdBQUcsR0FBRyxHQUFHRSxNQUFNLENBQUNnQixXQUFXLEVBQzlEM0IsWUFDRixDQUFDO1FBQ0QsT0FBT0ksSUFBSSxDQUFDQyxLQUFLLENBQUNILElBQUksQ0FBQ0ksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDc0IsTUFBTTtNQUMzQyxDQUFDLENBQUMsT0FBT3JCLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLDBCQUEwQixHQUFHRCxLQUFLLENBQUM7TUFDckQ7SUFDRixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtJQUpFakMsZUFBQSx5QkFLaUIsZ0JBQ2YwQixZQUF5QixFQUN6QlcsTUFBK0MsRUFDL0M7TUFDQSxJQUFJO1FBQ0YsTUFBTVQsSUFBSSxHQUFHLE1BQU0sSUFBQUMseUJBQVMsRUFDMUIsS0FBSyxFQUNMLGVBQWUsR0FBR1EsTUFBTSxDQUFDRixNQUFNLEdBQUcsYUFBYSxHQUFHRSxNQUFNLENBQUNnQixXQUFXLEVBQ3BFM0IsWUFDRixDQUFDO1FBQ0QsT0FBT0ksSUFBSSxDQUFDQyxLQUFLLENBQUNILElBQUksQ0FBQ0ksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDSixJQUFJO01BQ3pDLENBQUMsQ0FBQyxPQUFPSyxLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQywyQkFBMkIsR0FBR0QsS0FBSyxDQUFDO01BQ3REO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7SUFKRWpDLGVBQUEsMEJBS2tCLGdCQUNoQjBCLFlBQXlCLEVBQ3pCVyxNQUErQyxFQUMvQztNQUNBWCxZQUFZLENBQUNZLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDekIsSUFBSTtRQUNGLE1BQU1WLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFTLEVBQzFCLFFBQVEsRUFDUixlQUFlLEdBQUdRLE1BQU0sQ0FBQ0YsTUFBTSxHQUFHLGFBQWEsR0FBR0UsTUFBTSxDQUFDZ0IsV0FBVyxFQUNwRTNCLFlBQ0YsQ0FBQztRQUNELE9BQU9JLElBQUksQ0FBQ0MsS0FBSyxDQUFDSCxJQUFJLENBQUNJLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQ3NCLE1BQU07TUFDM0MsQ0FBQyxDQUFDLE9BQU9yQixLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQywyQkFBMkIsR0FBR0QsS0FBSyxDQUFDO01BQ3REO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0lBSEVqQyxlQUFBLDZCQUlxQixnQkFBZ0IwQixZQUF5QixFQUFFNkIsTUFBYyxFQUFFO01BQzlFLElBQUk7UUFDRixNQUFNM0IsSUFBSSxHQUFHLE1BQU0sSUFBQUMseUJBQVMsRUFBQyxLQUFLLEVBQUUsZUFBZSxHQUFHMEIsTUFBTSxHQUFHLFFBQVEsRUFBRTdCLFlBQVksQ0FBQztRQUN0RixPQUFPSSxJQUFJLENBQUNDLEtBQUssQ0FBQ0gsSUFBSSxDQUFDSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUNzQixNQUFNO01BQzNDLENBQUMsQ0FBQyxPQUFPckIsS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMsMkJBQTJCLEdBQUdELEtBQUssQ0FBQztNQUN0RDtJQUNGLENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQU5FakMsZUFBQSxrQ0FPMEIsZ0JBQ3hCeUIsTUFBa0MsRUFDbEMrQixPQUFZLEVBQ1o5QixZQUF5QixFQUN6QjtNQUNBLE1BQU1XLE1BQU0sR0FBR21CLE9BQU8sQ0FBQ25CLE1BQU07TUFDN0IsSUFBSTtRQUNGLE1BQU1vQixVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUNDLGVBQWUsQ0FBQ2hDLFlBQVksRUFBRVcsTUFBTSxDQUFDO1FBQ25FLE1BQU1zQixPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUNDLE9BQU8sQ0FBQ2xDLFlBQVksRUFBRVcsTUFBTSxDQUFDO1FBQ3hELE1BQU13QixPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUNDLGNBQWMsQ0FBQ3BDLFlBQVksRUFBRVcsTUFBTSxDQUFDO1FBQy9ELE9BQU93QixPQUFPO01BQ2hCLENBQUMsQ0FBQyxPQUFPNUIsS0FBSyxFQUFFO1FBQ2QsTUFBTSxJQUFJQyxLQUFLLENBQUMsNkJBQTZCLEdBQUdELEtBQUssQ0FBQztNQUN4RDtJQUNGLENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFMRWpDLGVBQUEsK0JBTXVCLGdCQUNyQnlCLE1BQWtDLEVBQ2xDWSxNQUF1RSxFQUN2RVgsWUFBeUIsRUFDekI7TUFDQSxJQUFJO1FBQ0YsTUFBTStCLFVBQVUsR0FBRyxNQUFNLElBQUksQ0FBQ0MsZUFBZSxDQUFDaEMsWUFBWSxFQUFFVyxNQUFNLENBQUM7UUFDbkUsTUFBTXdCLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQ0MsY0FBYyxDQUFDcEMsWUFBWSxFQUFFVyxNQUFNLENBQUM7UUFDL0QsT0FBT3dCLE9BQU87TUFDaEIsQ0FBQyxDQUFDLE9BQU81QixLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyx1QkFBdUIsR0FBR0QsS0FBSyxDQUFDO01BQ2xEO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7SUFKRWpDLGVBQUEsK0JBS3VCLGdCQUNyQnlCLE1BQWtDLEVBQ2xDWSxNQUE2RixFQUM3RlgsWUFBeUIsRUFDekI7TUFDQSxJQUFJO1FBQ0YsTUFBTWUsUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDc0IsWUFBWSxDQUFDckMsWUFBWSxFQUFFVyxNQUFNLENBQUM7UUFDOUQsTUFBTUMsT0FBTyxHQUFHO1VBQUUsR0FBR0QsTUFBTTtVQUFFZ0IsV0FBVyxFQUFFWixRQUFRLENBQUNiO1FBQUssQ0FBQztRQUN6RCxNQUFNb0MsT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDRixjQUFjLENBQUNwQyxZQUFZLEVBQUVZLE9BQU8sQ0FBQztRQUNoRSxPQUFPMEIsT0FBTztNQUNoQixDQUFDLENBQUMsT0FBTy9CLEtBQUssRUFBRTtRQUNkLE1BQU0sSUFBSUMsS0FBSyxDQUFDLDRCQUE0QixHQUFHRCxLQUFLLENBQUM7TUFDdkQ7SUFDRixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtJQUpFakMsZUFBQSxnQ0FLd0IsZ0JBQ3RCeUIsTUFBa0MsRUFDbENZLE1BQStDLEVBQy9DWCxZQUF5QixFQUN6QjtNQUNBLElBQUk7UUFDRixNQUFNdUMsT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDQyxlQUFlLENBQUN4QyxZQUFZLEVBQUVXLE1BQU0sQ0FBQztRQUNoRSxNQUFNOEIsWUFBWSxHQUFHLE1BQU0sSUFBSSxDQUFDQyxTQUFTLENBQUMzQyxNQUFNLEVBQUVZLE1BQU0sQ0FBQ0YsTUFBTSxFQUFFVCxZQUFZLENBQUM7UUFDOUUsT0FBTztVQUFFVSxVQUFVLEVBQUUrQjtRQUFhLENBQUM7TUFDckMsQ0FBQyxDQUFDLE9BQU9sQyxLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyx5QkFBeUIsR0FBR0QsS0FBSyxDQUFDO01BQ3BEO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0lBSEVqQyxlQUFBLGtDQUkwQixnQkFDeEJ5QixNQUFrQyxFQUNsQ1ksTUFBMEIsRUFDMUJYLFlBQXlCLEVBQ3pCO01BQ0EsSUFBSTtRQUNGLE1BQU0yQyxTQUFTLEdBQUcsTUFBTSxJQUFJLENBQUNDLGtCQUFrQixDQUFDNUMsWUFBWSxFQUFFVyxNQUFNLENBQUNGLE1BQU0sQ0FBQztRQUM1RSxNQUFNZ0MsWUFBWSxHQUFHLE1BQU0sSUFBSSxDQUFDQyxTQUFTLENBQUMzQyxNQUFNLEVBQUVZLE1BQU0sQ0FBQ0YsTUFBTSxFQUFFVCxZQUFZLENBQUM7UUFDOUUsT0FBTztVQUFFVSxVQUFVLEVBQUUrQjtRQUFhLENBQUM7TUFDckMsQ0FBQyxDQUFDLE9BQU9sQyxLQUFLLEVBQUU7UUFDZCxNQUFNLElBQUlDLEtBQUssQ0FBQyx3QkFBd0IsR0FBR0QsS0FBSyxDQUFDO01BQ25EO0lBQ0YsQ0FBQztFQUFBO0FBQ0g7QUFBQ3NDLE9BQUEsQ0FBQWhELGVBQUEsR0FBQUEsZUFBQSJ9