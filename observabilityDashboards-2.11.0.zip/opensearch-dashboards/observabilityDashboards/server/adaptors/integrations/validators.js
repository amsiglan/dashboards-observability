"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.validateTemplate = exports.validateInstance = void 0;
var _ajv = _interopRequireDefault(require("ajv"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

const ajv = new _ajv.default();
const staticAsset = {
  type: 'object',
  properties: {
    path: {
      type: 'string'
    },
    annotation: {
      type: 'string',
      nullable: true
    }
  },
  required: ['path'],
  additionalProperties: false
};
const templateSchema = {
  type: 'object',
  properties: {
    name: {
      type: 'string'
    },
    version: {
      type: 'string'
    },
    displayName: {
      type: 'string',
      nullable: true
    },
    license: {
      type: 'string'
    },
    type: {
      type: 'string'
    },
    labels: {
      type: 'array',
      items: {
        type: 'string'
      },
      nullable: true
    },
    author: {
      type: 'string',
      nullable: true
    },
    description: {
      type: 'string',
      nullable: true
    },
    sourceUrl: {
      type: 'string',
      nullable: true
    },
    statics: {
      type: 'object',
      properties: {
        logo: {
          ...staticAsset,
          nullable: true
        },
        gallery: {
          type: 'array',
          items: staticAsset,
          nullable: true
        },
        darkModeLogo: {
          ...staticAsset,
          nullable: true
        },
        darkModeGallery: {
          type: 'array',
          items: staticAsset,
          nullable: true
        }
      },
      additionalProperties: false,
      nullable: true
    },
    components: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: {
            type: 'string'
          },
          version: {
            type: 'string'
          }
        },
        required: ['name', 'version']
      }
    },
    assets: {
      type: 'object',
      properties: {
        savedObjects: {
          type: 'object',
          properties: {
            name: {
              type: 'string'
            },
            version: {
              type: 'string'
            }
          },
          required: ['name', 'version'],
          nullable: true,
          additionalProperties: false
        },
        queries: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              name: {
                type: 'string'
              },
              version: {
                type: 'string'
              },
              language: {
                type: 'string'
              }
            },
            required: ['name', 'version', 'language']
          },
          nullable: true
        }
      },
      additionalProperties: false
    },
    sampleData: {
      type: 'object',
      properties: {
        path: {
          type: 'string'
        }
      },
      required: ['path'],
      additionalProperties: false,
      nullable: true
    }
  },
  required: ['name', 'version', 'license', 'type', 'components', 'assets'],
  additionalProperties: false
};
const instanceSchema = {
  type: 'object',
  properties: {
    name: {
      type: 'string'
    },
    templateName: {
      type: 'string'
    },
    dataSource: {
      type: 'string'
    },
    creationDate: {
      type: 'string'
    },
    assets: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          assetType: {
            type: 'string'
          },
          assetId: {
            type: 'string'
          },
          isDefaultAsset: {
            type: 'boolean'
          },
          description: {
            type: 'string'
          }
        },
        required: ['assetType', 'assetId', 'isDefaultAsset', 'description']
      }
    }
  },
  required: ['name', 'templateName', 'dataSource', 'creationDate', 'assets']
};
const templateValidator = ajv.compile(templateSchema);
const instanceValidator = ajv.compile(instanceSchema);

/**
 * Validates an integration template against a predefined schema using the AJV library.
 * Since AJV validators use side effects for errors,
 * this is a more conventional wrapper that simplifies calling.
 *
 * @param data The data to be validated as an IntegrationTemplate.
 * @return A Result indicating whether the validation was successful or not.
 *         If validation succeeds, returns an object with 'ok' set to true and the validated data.
 *         If validation fails, returns an object with 'ok' set to false and an Error object describing the validation error.
 */
const validateTemplate = data => {
  if (!templateValidator(data)) {
    return {
      ok: false,
      error: new Error(ajv.errorsText(templateValidator.errors))
    };
  }
  // We assume an invariant that the type of an integration is connected with its component.
  if (data.components.findIndex(x => x.name === data.type) < 0) {
    return {
      ok: false,
      error: new Error(`The integration type '${data.type}' must be included as a component`)
    };
  }
  return {
    ok: true,
    value: data
  };
};

/**
 * Validates an integration instance against a predefined schema using the AJV library.
 *
 * @param data The data to be validated as an IntegrationInstance.
 * @return A Result indicating whether the validation was successful or not.
 *         If validation succeeds, returns an object with 'ok' set to true and the validated data.
 *         If validation fails, returns an object with 'ok' set to false and an Error object describing the validation error.
 */
exports.validateTemplate = validateTemplate;
const validateInstance = data => {
  if (!instanceValidator(data)) {
    return {
      ok: false,
      error: new Error(ajv.errorsText(instanceValidator.errors))
    };
  }
  return {
    ok: true,
    value: data
  };
};
exports.validateInstance = validateInstance;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYWp2IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJvYmoiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImFqdiIsIkFqdiIsInN0YXRpY0Fzc2V0IiwidHlwZSIsInByb3BlcnRpZXMiLCJwYXRoIiwiYW5ub3RhdGlvbiIsIm51bGxhYmxlIiwicmVxdWlyZWQiLCJhZGRpdGlvbmFsUHJvcGVydGllcyIsInRlbXBsYXRlU2NoZW1hIiwibmFtZSIsInZlcnNpb24iLCJkaXNwbGF5TmFtZSIsImxpY2Vuc2UiLCJsYWJlbHMiLCJpdGVtcyIsImF1dGhvciIsImRlc2NyaXB0aW9uIiwic291cmNlVXJsIiwic3RhdGljcyIsImxvZ28iLCJnYWxsZXJ5IiwiZGFya01vZGVMb2dvIiwiZGFya01vZGVHYWxsZXJ5IiwiY29tcG9uZW50cyIsImFzc2V0cyIsInNhdmVkT2JqZWN0cyIsInF1ZXJpZXMiLCJsYW5ndWFnZSIsInNhbXBsZURhdGEiLCJpbnN0YW5jZVNjaGVtYSIsInRlbXBsYXRlTmFtZSIsImRhdGFTb3VyY2UiLCJjcmVhdGlvbkRhdGUiLCJhc3NldFR5cGUiLCJhc3NldElkIiwiaXNEZWZhdWx0QXNzZXQiLCJ0ZW1wbGF0ZVZhbGlkYXRvciIsImNvbXBpbGUiLCJpbnN0YW5jZVZhbGlkYXRvciIsInZhbGlkYXRlVGVtcGxhdGUiLCJkYXRhIiwib2siLCJlcnJvciIsIkVycm9yIiwiZXJyb3JzVGV4dCIsImVycm9ycyIsImZpbmRJbmRleCIsIngiLCJ2YWx1ZSIsImV4cG9ydHMiLCJ2YWxpZGF0ZUluc3RhbmNlIl0sInNvdXJjZXMiOlsidmFsaWRhdG9ycy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCBBanYsIHsgSlNPTlNjaGVtYVR5cGUgfSBmcm9tICdhanYnO1xuXG5jb25zdCBhanYgPSBuZXcgQWp2KCk7XG5cbmNvbnN0IHN0YXRpY0Fzc2V0OiBKU09OU2NoZW1hVHlwZTxTdGF0aWNBc3NldD4gPSB7XG4gIHR5cGU6ICdvYmplY3QnLFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgcGF0aDogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgIGFubm90YXRpb246IHsgdHlwZTogJ3N0cmluZycsIG51bGxhYmxlOiB0cnVlIH0sXG4gIH0sXG4gIHJlcXVpcmVkOiBbJ3BhdGgnXSxcbiAgYWRkaXRpb25hbFByb3BlcnRpZXM6IGZhbHNlLFxufTtcblxuY29uc3QgdGVtcGxhdGVTY2hlbWE6IEpTT05TY2hlbWFUeXBlPEludGVncmF0aW9uQ29uZmlnPiA9IHtcbiAgdHlwZTogJ29iamVjdCcsXG4gIHByb3BlcnRpZXM6IHtcbiAgICBuYW1lOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgdmVyc2lvbjogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgIGRpc3BsYXlOYW1lOiB7IHR5cGU6ICdzdHJpbmcnLCBudWxsYWJsZTogdHJ1ZSB9LFxuICAgIGxpY2Vuc2U6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICB0eXBlOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgbGFiZWxzOiB7IHR5cGU6ICdhcnJheScsIGl0ZW1zOiB7IHR5cGU6ICdzdHJpbmcnIH0sIG51bGxhYmxlOiB0cnVlIH0sXG4gICAgYXV0aG9yOiB7IHR5cGU6ICdzdHJpbmcnLCBudWxsYWJsZTogdHJ1ZSB9LFxuICAgIGRlc2NyaXB0aW9uOiB7IHR5cGU6ICdzdHJpbmcnLCBudWxsYWJsZTogdHJ1ZSB9LFxuICAgIHNvdXJjZVVybDogeyB0eXBlOiAnc3RyaW5nJywgbnVsbGFibGU6IHRydWUgfSxcbiAgICBzdGF0aWNzOiB7XG4gICAgICB0eXBlOiAnb2JqZWN0JyxcbiAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgbG9nbzogeyAuLi5zdGF0aWNBc3NldCwgbnVsbGFibGU6IHRydWUgfSxcbiAgICAgICAgZ2FsbGVyeTogeyB0eXBlOiAnYXJyYXknLCBpdGVtczogc3RhdGljQXNzZXQsIG51bGxhYmxlOiB0cnVlIH0sXG4gICAgICAgIGRhcmtNb2RlTG9nbzogeyAuLi5zdGF0aWNBc3NldCwgbnVsbGFibGU6IHRydWUgfSxcbiAgICAgICAgZGFya01vZGVHYWxsZXJ5OiB7IHR5cGU6ICdhcnJheScsIGl0ZW1zOiBzdGF0aWNBc3NldCwgbnVsbGFibGU6IHRydWUgfSxcbiAgICAgIH0sXG4gICAgICBhZGRpdGlvbmFsUHJvcGVydGllczogZmFsc2UsXG4gICAgICBudWxsYWJsZTogdHJ1ZSxcbiAgICB9LFxuICAgIGNvbXBvbmVudHM6IHtcbiAgICAgIHR5cGU6ICdhcnJheScsXG4gICAgICBpdGVtczoge1xuICAgICAgICB0eXBlOiAnb2JqZWN0JyxcbiAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgIG5hbWU6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICAgICAgICB2ZXJzaW9uOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHJlcXVpcmVkOiBbJ25hbWUnLCAndmVyc2lvbiddLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzc2V0czoge1xuICAgICAgdHlwZTogJ29iamVjdCcsXG4gICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHNhdmVkT2JqZWN0czoge1xuICAgICAgICAgIHR5cGU6ICdvYmplY3QnLFxuICAgICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICAgIG5hbWU6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICAgICAgICAgIHZlcnNpb246IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHJlcXVpcmVkOiBbJ25hbWUnLCAndmVyc2lvbiddLFxuICAgICAgICAgIG51bGxhYmxlOiB0cnVlLFxuICAgICAgICAgIGFkZGl0aW9uYWxQcm9wZXJ0aWVzOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgcXVlcmllczoge1xuICAgICAgICAgIHR5cGU6ICdhcnJheScsXG4gICAgICAgICAgaXRlbXM6IHtcbiAgICAgICAgICAgIHR5cGU6ICdvYmplY3QnLFxuICAgICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgICBuYW1lOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgICAgICAgICAgIHZlcnNpb246IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICAgICAgICAgICAgbGFuZ3VhZ2U6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXF1aXJlZDogWyduYW1lJywgJ3ZlcnNpb24nLCAnbGFuZ3VhZ2UnXSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIG51bGxhYmxlOiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIGFkZGl0aW9uYWxQcm9wZXJ0aWVzOiBmYWxzZSxcbiAgICB9LFxuICAgIHNhbXBsZURhdGE6IHtcbiAgICAgIHR5cGU6ICdvYmplY3QnLFxuICAgICAgcHJvcGVydGllczoge1xuICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgdHlwZTogJ3N0cmluZycsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgcmVxdWlyZWQ6IFsncGF0aCddLFxuICAgICAgYWRkaXRpb25hbFByb3BlcnRpZXM6IGZhbHNlLFxuICAgICAgbnVsbGFibGU6IHRydWUsXG4gICAgfSxcbiAgfSxcbiAgcmVxdWlyZWQ6IFsnbmFtZScsICd2ZXJzaW9uJywgJ2xpY2Vuc2UnLCAndHlwZScsICdjb21wb25lbnRzJywgJ2Fzc2V0cyddLFxuICBhZGRpdGlvbmFsUHJvcGVydGllczogZmFsc2UsXG59O1xuXG5jb25zdCBpbnN0YW5jZVNjaGVtYTogSlNPTlNjaGVtYVR5cGU8SW50ZWdyYXRpb25JbnN0YW5jZT4gPSB7XG4gIHR5cGU6ICdvYmplY3QnLFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgbmFtZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgIHRlbXBsYXRlTmFtZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgIGRhdGFTb3VyY2U6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICBjcmVhdGlvbkRhdGU6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICBhc3NldHM6IHtcbiAgICAgIHR5cGU6ICdhcnJheScsXG4gICAgICBpdGVtczoge1xuICAgICAgICB0eXBlOiAnb2JqZWN0JyxcbiAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgIGFzc2V0VHlwZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgICAgICAgIGFzc2V0SWQ6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICAgICAgICBpc0RlZmF1bHRBc3NldDogeyB0eXBlOiAnYm9vbGVhbicgfSxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgICAgICB9LFxuICAgICAgICByZXF1aXJlZDogWydhc3NldFR5cGUnLCAnYXNzZXRJZCcsICdpc0RlZmF1bHRBc3NldCcsICdkZXNjcmlwdGlvbiddLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICByZXF1aXJlZDogWyduYW1lJywgJ3RlbXBsYXRlTmFtZScsICdkYXRhU291cmNlJywgJ2NyZWF0aW9uRGF0ZScsICdhc3NldHMnXSxcbn07XG5cbmNvbnN0IHRlbXBsYXRlVmFsaWRhdG9yID0gYWp2LmNvbXBpbGUodGVtcGxhdGVTY2hlbWEpO1xuY29uc3QgaW5zdGFuY2VWYWxpZGF0b3IgPSBhanYuY29tcGlsZShpbnN0YW5jZVNjaGVtYSk7XG5cbi8qKlxuICogVmFsaWRhdGVzIGFuIGludGVncmF0aW9uIHRlbXBsYXRlIGFnYWluc3QgYSBwcmVkZWZpbmVkIHNjaGVtYSB1c2luZyB0aGUgQUpWIGxpYnJhcnkuXG4gKiBTaW5jZSBBSlYgdmFsaWRhdG9ycyB1c2Ugc2lkZSBlZmZlY3RzIGZvciBlcnJvcnMsXG4gKiB0aGlzIGlzIGEgbW9yZSBjb252ZW50aW9uYWwgd3JhcHBlciB0aGF0IHNpbXBsaWZpZXMgY2FsbGluZy5cbiAqXG4gKiBAcGFyYW0gZGF0YSBUaGUgZGF0YSB0byBiZSB2YWxpZGF0ZWQgYXMgYW4gSW50ZWdyYXRpb25UZW1wbGF0ZS5cbiAqIEByZXR1cm4gQSBSZXN1bHQgaW5kaWNhdGluZyB3aGV0aGVyIHRoZSB2YWxpZGF0aW9uIHdhcyBzdWNjZXNzZnVsIG9yIG5vdC5cbiAqICAgICAgICAgSWYgdmFsaWRhdGlvbiBzdWNjZWVkcywgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCAnb2snIHNldCB0byB0cnVlIGFuZCB0aGUgdmFsaWRhdGVkIGRhdGEuXG4gKiAgICAgICAgIElmIHZhbGlkYXRpb24gZmFpbHMsIHJldHVybnMgYW4gb2JqZWN0IHdpdGggJ29rJyBzZXQgdG8gZmFsc2UgYW5kIGFuIEVycm9yIG9iamVjdCBkZXNjcmliaW5nIHRoZSB2YWxpZGF0aW9uIGVycm9yLlxuICovXG5leHBvcnQgY29uc3QgdmFsaWRhdGVUZW1wbGF0ZSA9IChkYXRhOiB1bmtub3duKTogUmVzdWx0PEludGVncmF0aW9uQ29uZmlnPiA9PiB7XG4gIGlmICghdGVtcGxhdGVWYWxpZGF0b3IoZGF0YSkpIHtcbiAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiBuZXcgRXJyb3IoYWp2LmVycm9yc1RleHQodGVtcGxhdGVWYWxpZGF0b3IuZXJyb3JzKSkgfTtcbiAgfVxuICAvLyBXZSBhc3N1bWUgYW4gaW52YXJpYW50IHRoYXQgdGhlIHR5cGUgb2YgYW4gaW50ZWdyYXRpb24gaXMgY29ubmVjdGVkIHdpdGggaXRzIGNvbXBvbmVudC5cbiAgaWYgKGRhdGEuY29tcG9uZW50cy5maW5kSW5kZXgoKHgpID0+IHgubmFtZSA9PT0gZGF0YS50eXBlKSA8IDApIHtcbiAgICByZXR1cm4ge1xuICAgICAgb2s6IGZhbHNlLFxuICAgICAgZXJyb3I6IG5ldyBFcnJvcihgVGhlIGludGVncmF0aW9uIHR5cGUgJyR7ZGF0YS50eXBlfScgbXVzdCBiZSBpbmNsdWRlZCBhcyBhIGNvbXBvbmVudGApLFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBvazogdHJ1ZSxcbiAgICB2YWx1ZTogZGF0YSxcbiAgfTtcbn07XG5cbi8qKlxuICogVmFsaWRhdGVzIGFuIGludGVncmF0aW9uIGluc3RhbmNlIGFnYWluc3QgYSBwcmVkZWZpbmVkIHNjaGVtYSB1c2luZyB0aGUgQUpWIGxpYnJhcnkuXG4gKlxuICogQHBhcmFtIGRhdGEgVGhlIGRhdGEgdG8gYmUgdmFsaWRhdGVkIGFzIGFuIEludGVncmF0aW9uSW5zdGFuY2UuXG4gKiBAcmV0dXJuIEEgUmVzdWx0IGluZGljYXRpbmcgd2hldGhlciB0aGUgdmFsaWRhdGlvbiB3YXMgc3VjY2Vzc2Z1bCBvciBub3QuXG4gKiAgICAgICAgIElmIHZhbGlkYXRpb24gc3VjY2VlZHMsIHJldHVybnMgYW4gb2JqZWN0IHdpdGggJ29rJyBzZXQgdG8gdHJ1ZSBhbmQgdGhlIHZhbGlkYXRlZCBkYXRhLlxuICogICAgICAgICBJZiB2YWxpZGF0aW9uIGZhaWxzLCByZXR1cm5zIGFuIG9iamVjdCB3aXRoICdvaycgc2V0IHRvIGZhbHNlIGFuZCBhbiBFcnJvciBvYmplY3QgZGVzY3JpYmluZyB0aGUgdmFsaWRhdGlvbiBlcnJvci5cbiAqL1xuZXhwb3J0IGNvbnN0IHZhbGlkYXRlSW5zdGFuY2UgPSAoZGF0YTogdW5rbm93bik6IFJlc3VsdDxJbnRlZ3JhdGlvbkluc3RhbmNlPiA9PiB7XG4gIGlmICghaW5zdGFuY2VWYWxpZGF0b3IoZGF0YSkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgb2s6IGZhbHNlLFxuICAgICAgZXJyb3I6IG5ldyBFcnJvcihhanYuZXJyb3JzVGV4dChpbnN0YW5jZVZhbGlkYXRvci5lcnJvcnMpKSxcbiAgICB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgb2s6IHRydWUsXG4gICAgdmFsdWU6IGRhdGEsXG4gIH07XG59O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxJQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFBMEMsU0FBQUQsdUJBQUFFLEdBQUEsV0FBQUEsR0FBQSxJQUFBQSxHQUFBLENBQUFDLFVBQUEsR0FBQUQsR0FBQSxLQUFBRSxPQUFBLEVBQUFGLEdBQUE7QUFMMUM7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsTUFBTUcsR0FBRyxHQUFHLElBQUlDLFlBQUcsQ0FBQyxDQUFDO0FBRXJCLE1BQU1DLFdBQXdDLEdBQUc7RUFDL0NDLElBQUksRUFBRSxRQUFRO0VBQ2RDLFVBQVUsRUFBRTtJQUNWQyxJQUFJLEVBQUU7TUFBRUYsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUN4QkcsVUFBVSxFQUFFO01BQUVILElBQUksRUFBRSxRQUFRO01BQUVJLFFBQVEsRUFBRTtJQUFLO0VBQy9DLENBQUM7RUFDREMsUUFBUSxFQUFFLENBQUMsTUFBTSxDQUFDO0VBQ2xCQyxvQkFBb0IsRUFBRTtBQUN4QixDQUFDO0FBRUQsTUFBTUMsY0FBaUQsR0FBRztFQUN4RFAsSUFBSSxFQUFFLFFBQVE7RUFDZEMsVUFBVSxFQUFFO0lBQ1ZPLElBQUksRUFBRTtNQUFFUixJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQ3hCUyxPQUFPLEVBQUU7TUFBRVQsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUMzQlUsV0FBVyxFQUFFO01BQUVWLElBQUksRUFBRSxRQUFRO01BQUVJLFFBQVEsRUFBRTtJQUFLLENBQUM7SUFDL0NPLE9BQU8sRUFBRTtNQUFFWCxJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQzNCQSxJQUFJLEVBQUU7TUFBRUEsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUN4QlksTUFBTSxFQUFFO01BQUVaLElBQUksRUFBRSxPQUFPO01BQUVhLEtBQUssRUFBRTtRQUFFYixJQUFJLEVBQUU7TUFBUyxDQUFDO01BQUVJLFFBQVEsRUFBRTtJQUFLLENBQUM7SUFDcEVVLE1BQU0sRUFBRTtNQUFFZCxJQUFJLEVBQUUsUUFBUTtNQUFFSSxRQUFRLEVBQUU7SUFBSyxDQUFDO0lBQzFDVyxXQUFXLEVBQUU7TUFBRWYsSUFBSSxFQUFFLFFBQVE7TUFBRUksUUFBUSxFQUFFO0lBQUssQ0FBQztJQUMvQ1ksU0FBUyxFQUFFO01BQUVoQixJQUFJLEVBQUUsUUFBUTtNQUFFSSxRQUFRLEVBQUU7SUFBSyxDQUFDO0lBQzdDYSxPQUFPLEVBQUU7TUFDUGpCLElBQUksRUFBRSxRQUFRO01BQ2RDLFVBQVUsRUFBRTtRQUNWaUIsSUFBSSxFQUFFO1VBQUUsR0FBR25CLFdBQVc7VUFBRUssUUFBUSxFQUFFO1FBQUssQ0FBQztRQUN4Q2UsT0FBTyxFQUFFO1VBQUVuQixJQUFJLEVBQUUsT0FBTztVQUFFYSxLQUFLLEVBQUVkLFdBQVc7VUFBRUssUUFBUSxFQUFFO1FBQUssQ0FBQztRQUM5RGdCLFlBQVksRUFBRTtVQUFFLEdBQUdyQixXQUFXO1VBQUVLLFFBQVEsRUFBRTtRQUFLLENBQUM7UUFDaERpQixlQUFlLEVBQUU7VUFBRXJCLElBQUksRUFBRSxPQUFPO1VBQUVhLEtBQUssRUFBRWQsV0FBVztVQUFFSyxRQUFRLEVBQUU7UUFBSztNQUN2RSxDQUFDO01BQ0RFLG9CQUFvQixFQUFFLEtBQUs7TUFDM0JGLFFBQVEsRUFBRTtJQUNaLENBQUM7SUFDRGtCLFVBQVUsRUFBRTtNQUNWdEIsSUFBSSxFQUFFLE9BQU87TUFDYmEsS0FBSyxFQUFFO1FBQ0xiLElBQUksRUFBRSxRQUFRO1FBQ2RDLFVBQVUsRUFBRTtVQUNWTyxJQUFJLEVBQUU7WUFBRVIsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN4QlMsT0FBTyxFQUFFO1lBQUVULElBQUksRUFBRTtVQUFTO1FBQzVCLENBQUM7UUFDREssUUFBUSxFQUFFLENBQUMsTUFBTSxFQUFFLFNBQVM7TUFDOUI7SUFDRixDQUFDO0lBQ0RrQixNQUFNLEVBQUU7TUFDTnZCLElBQUksRUFBRSxRQUFRO01BQ2RDLFVBQVUsRUFBRTtRQUNWdUIsWUFBWSxFQUFFO1VBQ1p4QixJQUFJLEVBQUUsUUFBUTtVQUNkQyxVQUFVLEVBQUU7WUFDVk8sSUFBSSxFQUFFO2NBQUVSLElBQUksRUFBRTtZQUFTLENBQUM7WUFDeEJTLE9BQU8sRUFBRTtjQUFFVCxJQUFJLEVBQUU7WUFBUztVQUM1QixDQUFDO1VBQ0RLLFFBQVEsRUFBRSxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7VUFDN0JELFFBQVEsRUFBRSxJQUFJO1VBQ2RFLG9CQUFvQixFQUFFO1FBQ3hCLENBQUM7UUFDRG1CLE9BQU8sRUFBRTtVQUNQekIsSUFBSSxFQUFFLE9BQU87VUFDYmEsS0FBSyxFQUFFO1lBQ0xiLElBQUksRUFBRSxRQUFRO1lBQ2RDLFVBQVUsRUFBRTtjQUNWTyxJQUFJLEVBQUU7Z0JBQUVSLElBQUksRUFBRTtjQUFTLENBQUM7Y0FDeEJTLE9BQU8sRUFBRTtnQkFBRVQsSUFBSSxFQUFFO2NBQVMsQ0FBQztjQUMzQjBCLFFBQVEsRUFBRTtnQkFBRTFCLElBQUksRUFBRTtjQUFTO1lBQzdCLENBQUM7WUFDREssUUFBUSxFQUFFLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxVQUFVO1VBQzFDLENBQUM7VUFDREQsUUFBUSxFQUFFO1FBQ1o7TUFDRixDQUFDO01BQ0RFLG9CQUFvQixFQUFFO0lBQ3hCLENBQUM7SUFDRHFCLFVBQVUsRUFBRTtNQUNWM0IsSUFBSSxFQUFFLFFBQVE7TUFDZEMsVUFBVSxFQUFFO1FBQ1ZDLElBQUksRUFBRTtVQUNKRixJQUFJLEVBQUU7UUFDUjtNQUNGLENBQUM7TUFDREssUUFBUSxFQUFFLENBQUMsTUFBTSxDQUFDO01BQ2xCQyxvQkFBb0IsRUFBRSxLQUFLO01BQzNCRixRQUFRLEVBQUU7SUFDWjtFQUNGLENBQUM7RUFDREMsUUFBUSxFQUFFLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxRQUFRLENBQUM7RUFDeEVDLG9CQUFvQixFQUFFO0FBQ3hCLENBQUM7QUFFRCxNQUFNc0IsY0FBbUQsR0FBRztFQUMxRDVCLElBQUksRUFBRSxRQUFRO0VBQ2RDLFVBQVUsRUFBRTtJQUNWTyxJQUFJLEVBQUU7TUFBRVIsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUN4QjZCLFlBQVksRUFBRTtNQUFFN0IsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUNoQzhCLFVBQVUsRUFBRTtNQUFFOUIsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUM5QitCLFlBQVksRUFBRTtNQUFFL0IsSUFBSSxFQUFFO0lBQVMsQ0FBQztJQUNoQ3VCLE1BQU0sRUFBRTtNQUNOdkIsSUFBSSxFQUFFLE9BQU87TUFDYmEsS0FBSyxFQUFFO1FBQ0xiLElBQUksRUFBRSxRQUFRO1FBQ2RDLFVBQVUsRUFBRTtVQUNWK0IsU0FBUyxFQUFFO1lBQUVoQyxJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQzdCaUMsT0FBTyxFQUFFO1lBQUVqQyxJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQzNCa0MsY0FBYyxFQUFFO1lBQUVsQyxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQ25DZSxXQUFXLEVBQUU7WUFBRWYsSUFBSSxFQUFFO1VBQVM7UUFDaEMsQ0FBQztRQUNESyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLGdCQUFnQixFQUFFLGFBQWE7TUFDcEU7SUFDRjtFQUNGLENBQUM7RUFDREEsUUFBUSxFQUFFLENBQUMsTUFBTSxFQUFFLGNBQWMsRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLFFBQVE7QUFDM0UsQ0FBQztBQUVELE1BQU04QixpQkFBaUIsR0FBR3RDLEdBQUcsQ0FBQ3VDLE9BQU8sQ0FBQzdCLGNBQWMsQ0FBQztBQUNyRCxNQUFNOEIsaUJBQWlCLEdBQUd4QyxHQUFHLENBQUN1QyxPQUFPLENBQUNSLGNBQWMsQ0FBQzs7QUFFckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNVSxnQkFBZ0IsR0FBSUMsSUFBYSxJQUFnQztFQUM1RSxJQUFJLENBQUNKLGlCQUFpQixDQUFDSSxJQUFJLENBQUMsRUFBRTtJQUM1QixPQUFPO01BQUVDLEVBQUUsRUFBRSxLQUFLO01BQUVDLEtBQUssRUFBRSxJQUFJQyxLQUFLLENBQUM3QyxHQUFHLENBQUM4QyxVQUFVLENBQUNSLGlCQUFpQixDQUFDUyxNQUFNLENBQUM7SUFBRSxDQUFDO0VBQ2xGO0VBQ0E7RUFDQSxJQUFJTCxJQUFJLENBQUNqQixVQUFVLENBQUN1QixTQUFTLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDdEMsSUFBSSxLQUFLK0IsSUFBSSxDQUFDdkMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO0lBQzlELE9BQU87TUFDTHdDLEVBQUUsRUFBRSxLQUFLO01BQ1RDLEtBQUssRUFBRSxJQUFJQyxLQUFLLENBQUUseUJBQXdCSCxJQUFJLENBQUN2QyxJQUFLLG1DQUFrQztJQUN4RixDQUFDO0VBQ0g7RUFDQSxPQUFPO0lBQ0x3QyxFQUFFLEVBQUUsSUFBSTtJQUNSTyxLQUFLLEVBQUVSO0VBQ1QsQ0FBQztBQUNILENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVBBUyxPQUFBLENBQUFWLGdCQUFBLEdBQUFBLGdCQUFBO0FBUU8sTUFBTVcsZ0JBQWdCLEdBQUlWLElBQWEsSUFBa0M7RUFDOUUsSUFBSSxDQUFDRixpQkFBaUIsQ0FBQ0UsSUFBSSxDQUFDLEVBQUU7SUFDNUIsT0FBTztNQUNMQyxFQUFFLEVBQUUsS0FBSztNQUNUQyxLQUFLLEVBQUUsSUFBSUMsS0FBSyxDQUFDN0MsR0FBRyxDQUFDOEMsVUFBVSxDQUFDTixpQkFBaUIsQ0FBQ08sTUFBTSxDQUFDO0lBQzNELENBQUM7RUFDSDtFQUNBLE9BQU87SUFDTEosRUFBRSxFQUFFLElBQUk7SUFDUk8sS0FBSyxFQUFFUjtFQUNULENBQUM7QUFDSCxDQUFDO0FBQUNTLE9BQUEsQ0FBQUMsZ0JBQUEsR0FBQUEsZ0JBQUEifQ==