"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Field = void 0;
var _node = require("../node");
/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

class Field extends _node.PPLNode {
  constructor(name, children, fieldExpression) {
    super(name, children);
    this.fieldExpression = fieldExpression;
  }
  getTokens() {
    var _this$fieldExpression;
    return {
      name: (_this$fieldExpression = this.fieldExpression) !== null && _this$fieldExpression !== void 0 ? _this$fieldExpression : ''
    };
  }
  toString() {
    var _this$fieldExpression2;
    return (_this$fieldExpression2 = this.fieldExpression) !== null && _this$fieldExpression2 !== void 0 ? _this$fieldExpression2 : '';
  }
}
exports.Field = Field;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZSIsInJlcXVpcmUiLCJGaWVsZCIsIlBQTE5vZGUiLCJjb25zdHJ1Y3RvciIsIm5hbWUiLCJjaGlsZHJlbiIsImZpZWxkRXhwcmVzc2lvbiIsImdldFRva2VucyIsIl90aGlzJGZpZWxkRXhwcmVzc2lvbiIsInRvU3RyaW5nIiwiX3RoaXMkZmllbGRFeHByZXNzaW9uMiIsImV4cG9ydHMiXSwic291cmNlcyI6WyJmaWVsZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7IFBQTE5vZGUgfSBmcm9tICcuLi9ub2RlJztcblxuZXhwb3J0IGNsYXNzIEZpZWxkIGV4dGVuZHMgUFBMTm9kZSB7XG4gIGNvbnN0cnVjdG9yKG5hbWU6IHN0cmluZywgY2hpbGRyZW46IEFycmF5PFBQTE5vZGU+LCBwcml2YXRlIGZpZWxkRXhwcmVzc2lvbjogc3RyaW5nKSB7XG4gICAgc3VwZXIobmFtZSwgY2hpbGRyZW4pO1xuICB9XG5cbiAgZ2V0VG9rZW5zKCkge1xuICAgIHJldHVybiB7IG5hbWU6IHRoaXMuZmllbGRFeHByZXNzaW9uID8/ICcnIH07XG4gIH1cblxuICB0b1N0cmluZygpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLmZpZWxkRXhwcmVzc2lvbiA/PyAnJztcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxLQUFBLEdBQUFDLE9BQUE7QUFMQTtBQUNBO0FBQ0E7QUFDQTs7QUFJTyxNQUFNQyxLQUFLLFNBQVNDLGFBQU8sQ0FBQztFQUNqQ0MsV0FBV0EsQ0FBQ0MsSUFBWSxFQUFFQyxRQUF3QixFQUFVQyxlQUF1QixFQUFFO0lBQ25GLEtBQUssQ0FBQ0YsSUFBSSxFQUFFQyxRQUFRLENBQUM7SUFBQyxLQURvQ0MsZUFBdUIsR0FBdkJBLGVBQXVCO0VBRW5GO0VBRUFDLFNBQVNBLENBQUEsRUFBRztJQUFBLElBQUFDLHFCQUFBO0lBQ1YsT0FBTztNQUFFSixJQUFJLEdBQUFJLHFCQUFBLEdBQUUsSUFBSSxDQUFDRixlQUFlLGNBQUFFLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUk7SUFBRyxDQUFDO0VBQzdDO0VBRUFDLFFBQVFBLENBQUEsRUFBVztJQUFBLElBQUFDLHNCQUFBO0lBQ2pCLFFBQUFBLHNCQUFBLEdBQU8sSUFBSSxDQUFDSixlQUFlLGNBQUFJLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksRUFBRTtFQUNuQztBQUNGO0FBQUNDLE9BQUEsQ0FBQVYsS0FBQSxHQUFBQSxLQUFBIn0=