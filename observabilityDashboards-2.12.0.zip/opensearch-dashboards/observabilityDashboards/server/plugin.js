"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ObservabilityPlugin = void 0;
var _opensearch_observability_plugin = require("./adaptors/opensearch_observability_plugin");
var _ppl_plugin = require("./adaptors/ppl_plugin");
var _index = require("./routes/index");
var _observability_saved_object = require("./saved_objects/observability_saved_object");
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); } /*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
class ObservabilityPlugin {
  constructor(initializerContext) {
    _defineProperty(this, "logger", void 0);
    this.logger = initializerContext.logger.get();
  }
  setup(core) {
    this.logger.debug('Observability: Setup');
    const router = core.http.createRouter();
    const openSearchObservabilityClient = core.opensearch.legacy.createClient('opensearch_observability', {
      plugins: [_ppl_plugin.PPLPlugin, _opensearch_observability_plugin.OpenSearchObservabilityPlugin]
    });

    // @ts-ignore
    core.http.registerRouteHandlerContext('observability_plugin', (context, request) => {
      return {
        logger: this.logger,
        observabilityClient: openSearchObservabilityClient
      };
    });
    const obsPanelType = {
      name: 'observability-panel',
      hidden: false,
      namespaceType: 'single',
      mappings: {
        dynamic: false,
        properties: {
          title: {
            type: 'text'
          },
          description: {
            type: 'text'
          }
        }
      },
      management: {
        importableAndExportable: true,
        getInAppUrl() {
          return {
            path: `/app/management/observability/settings`,
            uiCapabilitiesPath: 'advancedSettings.show'
          };
        },
        getTitle(obj) {
          return `Observability Settings [${obj.id}]`;
        }
      },
      migrations: {
        '3.0.0': doc => ({
          ...doc,
          description: ''
        }),
        '3.0.1': doc => ({
          ...doc,
          description: 'Some Description Text'
        }),
        '3.0.2': doc => ({
          ...doc,
          dateCreated: parseInt(doc.dateCreated || '0', 10)
        })
      }
    };
    const integrationInstanceType = {
      name: 'integration-instance',
      hidden: false,
      namespaceType: 'single',
      mappings: {
        dynamic: false,
        properties: {
          name: {
            type: 'text'
          },
          templateName: {
            type: 'text'
          },
          dataSource: {
            type: 'text'
          },
          creationDate: {
            type: 'date'
          },
          assets: {
            type: 'nested'
          }
        }
      }
    };
    core.savedObjects.registerType(obsPanelType);
    core.savedObjects.registerType(integrationInstanceType);

    // Register server side APIs
    (0, _index.setupRoutes)({
      router,
      client: openSearchObservabilityClient
    });
    core.savedObjects.registerType(_observability_saved_object.visualizationSavedObject);
    core.savedObjects.registerType(_observability_saved_object.searchSavedObject);
    core.capabilities.registerProvider(() => ({
      observability: {
        show: true
      }
    }));
    return {};
  }
  start(core) {
    this.logger.debug('Observability: Started');
    return {};
  }
  stop() {}
}
exports.ObservabilityPlugin = ObservabilityPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfb3BlbnNlYXJjaF9vYnNlcnZhYmlsaXR5X3BsdWdpbiIsInJlcXVpcmUiLCJfcHBsX3BsdWdpbiIsIl9pbmRleCIsIl9vYnNlcnZhYmlsaXR5X3NhdmVkX29iamVjdCIsIl9kZWZpbmVQcm9wZXJ0eSIsIm9iaiIsImtleSIsInZhbHVlIiwiX3RvUHJvcGVydHlLZXkiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJ3cml0YWJsZSIsImFyZyIsIl90b1ByaW1pdGl2ZSIsIlN0cmluZyIsImlucHV0IiwiaGludCIsInByaW0iLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsInVuZGVmaW5lZCIsInJlcyIsImNhbGwiLCJUeXBlRXJyb3IiLCJOdW1iZXIiLCJPYnNlcnZhYmlsaXR5UGx1Z2luIiwiY29uc3RydWN0b3IiLCJpbml0aWFsaXplckNvbnRleHQiLCJsb2dnZXIiLCJnZXQiLCJzZXR1cCIsImNvcmUiLCJkZWJ1ZyIsInJvdXRlciIsImh0dHAiLCJjcmVhdGVSb3V0ZXIiLCJvcGVuU2VhcmNoT2JzZXJ2YWJpbGl0eUNsaWVudCIsIm9wZW5zZWFyY2giLCJsZWdhY3kiLCJjcmVhdGVDbGllbnQiLCJwbHVnaW5zIiwiUFBMUGx1Z2luIiwiT3BlblNlYXJjaE9ic2VydmFiaWxpdHlQbHVnaW4iLCJyZWdpc3RlclJvdXRlSGFuZGxlckNvbnRleHQiLCJjb250ZXh0IiwicmVxdWVzdCIsIm9ic2VydmFiaWxpdHlDbGllbnQiLCJvYnNQYW5lbFR5cGUiLCJuYW1lIiwiaGlkZGVuIiwibmFtZXNwYWNlVHlwZSIsIm1hcHBpbmdzIiwiZHluYW1pYyIsInByb3BlcnRpZXMiLCJ0aXRsZSIsInR5cGUiLCJkZXNjcmlwdGlvbiIsIm1hbmFnZW1lbnQiLCJpbXBvcnRhYmxlQW5kRXhwb3J0YWJsZSIsImdldEluQXBwVXJsIiwicGF0aCIsInVpQ2FwYWJpbGl0aWVzUGF0aCIsImdldFRpdGxlIiwiaWQiLCJtaWdyYXRpb25zIiwiZG9jIiwiZGF0ZUNyZWF0ZWQiLCJwYXJzZUludCIsImludGVncmF0aW9uSW5zdGFuY2VUeXBlIiwidGVtcGxhdGVOYW1lIiwiZGF0YVNvdXJjZSIsImNyZWF0aW9uRGF0ZSIsImFzc2V0cyIsInNhdmVkT2JqZWN0cyIsInJlZ2lzdGVyVHlwZSIsInNldHVwUm91dGVzIiwiY2xpZW50IiwidmlzdWFsaXphdGlvblNhdmVkT2JqZWN0Iiwic2VhcmNoU2F2ZWRPYmplY3QiLCJjYXBhYmlsaXRpZXMiLCJyZWdpc3RlclByb3ZpZGVyIiwib2JzZXJ2YWJpbGl0eSIsInNob3ciLCJzdGFydCIsInN0b3AiLCJleHBvcnRzIl0sInNvdXJjZXMiOlsicGx1Z2luLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IHtcbiAgQ29yZVNldHVwLFxuICBDb3JlU3RhcnQsXG4gIElMZWdhY3lDbHVzdGVyQ2xpZW50LFxuICBMb2dnZXIsXG4gIFBsdWdpbixcbiAgUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0LFxuICBTYXZlZE9iamVjdHNUeXBlLFxufSBmcm9tICcuLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgT3BlblNlYXJjaE9ic2VydmFiaWxpdHlQbHVnaW4gfSBmcm9tICcuL2FkYXB0b3JzL29wZW5zZWFyY2hfb2JzZXJ2YWJpbGl0eV9wbHVnaW4nO1xuaW1wb3J0IHsgUFBMUGx1Z2luIH0gZnJvbSAnLi9hZGFwdG9ycy9wcGxfcGx1Z2luJztcbmltcG9ydCB7IHNldHVwUm91dGVzIH0gZnJvbSAnLi9yb3V0ZXMvaW5kZXgnO1xuaW1wb3J0IHtcbiAgc2VhcmNoU2F2ZWRPYmplY3QsXG4gIHZpc3VhbGl6YXRpb25TYXZlZE9iamVjdCxcbn0gZnJvbSAnLi9zYXZlZF9vYmplY3RzL29ic2VydmFiaWxpdHlfc2F2ZWRfb2JqZWN0JztcbmltcG9ydCB7IE9ic2VydmFiaWxpdHlQbHVnaW5TZXR1cCwgT2JzZXJ2YWJpbGl0eVBsdWdpblN0YXJ0IH0gZnJvbSAnLi90eXBlcyc7XG5cbmV4cG9ydCBjbGFzcyBPYnNlcnZhYmlsaXR5UGx1Z2luXG4gIGltcGxlbWVudHMgUGx1Z2luPE9ic2VydmFiaWxpdHlQbHVnaW5TZXR1cCwgT2JzZXJ2YWJpbGl0eVBsdWdpblN0YXJ0PiB7XG4gIHByaXZhdGUgcmVhZG9ubHkgbG9nZ2VyOiBMb2dnZXI7XG5cbiAgY29uc3RydWN0b3IoaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgICB0aGlzLmxvZ2dlciA9IGluaXRpYWxpemVyQ29udGV4dC5sb2dnZXIuZ2V0KCk7XG4gIH1cblxuICBwdWJsaWMgc2V0dXAoY29yZTogQ29yZVNldHVwKSB7XG4gICAgdGhpcy5sb2dnZXIuZGVidWcoJ09ic2VydmFiaWxpdHk6IFNldHVwJyk7XG4gICAgY29uc3Qgcm91dGVyID0gY29yZS5odHRwLmNyZWF0ZVJvdXRlcigpO1xuICAgIGNvbnN0IG9wZW5TZWFyY2hPYnNlcnZhYmlsaXR5Q2xpZW50OiBJTGVnYWN5Q2x1c3RlckNsaWVudCA9IGNvcmUub3BlbnNlYXJjaC5sZWdhY3kuY3JlYXRlQ2xpZW50KFxuICAgICAgJ29wZW5zZWFyY2hfb2JzZXJ2YWJpbGl0eScsXG4gICAgICB7XG4gICAgICAgIHBsdWdpbnM6IFtQUExQbHVnaW4sIE9wZW5TZWFyY2hPYnNlcnZhYmlsaXR5UGx1Z2luXSxcbiAgICAgIH1cbiAgICApO1xuXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIGNvcmUuaHR0cC5yZWdpc3RlclJvdXRlSGFuZGxlckNvbnRleHQoJ29ic2VydmFiaWxpdHlfcGx1Z2luJywgKGNvbnRleHQsIHJlcXVlc3QpID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxvZ2dlcjogdGhpcy5sb2dnZXIsXG4gICAgICAgIG9ic2VydmFiaWxpdHlDbGllbnQ6IG9wZW5TZWFyY2hPYnNlcnZhYmlsaXR5Q2xpZW50LFxuICAgICAgfTtcbiAgICB9KTtcblxuICAgIGNvbnN0IG9ic1BhbmVsVHlwZTogU2F2ZWRPYmplY3RzVHlwZSA9IHtcbiAgICAgIG5hbWU6ICdvYnNlcnZhYmlsaXR5LXBhbmVsJyxcbiAgICAgIGhpZGRlbjogZmFsc2UsXG4gICAgICBuYW1lc3BhY2VUeXBlOiAnc2luZ2xlJyxcbiAgICAgIG1hcHBpbmdzOiB7XG4gICAgICAgIGR5bmFtaWM6IGZhbHNlLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiB7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBtYW5hZ2VtZW50OiB7XG4gICAgICAgIGltcG9ydGFibGVBbmRFeHBvcnRhYmxlOiB0cnVlLFxuICAgICAgICBnZXRJbkFwcFVybCgpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcGF0aDogYC9hcHAvbWFuYWdlbWVudC9vYnNlcnZhYmlsaXR5L3NldHRpbmdzYCxcbiAgICAgICAgICAgIHVpQ2FwYWJpbGl0aWVzUGF0aDogJ2FkdmFuY2VkU2V0dGluZ3Muc2hvdycsXG4gICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0VGl0bGUob2JqKSB7XG4gICAgICAgICAgcmV0dXJuIGBPYnNlcnZhYmlsaXR5IFNldHRpbmdzIFske29iai5pZH1dYDtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBtaWdyYXRpb25zOiB7XG4gICAgICAgICczLjAuMCc6IChkb2MpID0+ICh7IC4uLmRvYywgZGVzY3JpcHRpb246ICcnIH0pLFxuICAgICAgICAnMy4wLjEnOiAoZG9jKSA9PiAoeyAuLi5kb2MsIGRlc2NyaXB0aW9uOiAnU29tZSBEZXNjcmlwdGlvbiBUZXh0JyB9KSxcbiAgICAgICAgJzMuMC4yJzogKGRvYykgPT4gKHsgLi4uZG9jLCBkYXRlQ3JlYXRlZDogcGFyc2VJbnQoZG9jLmRhdGVDcmVhdGVkIHx8ICcwJywgMTApIH0pLFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgY29uc3QgaW50ZWdyYXRpb25JbnN0YW5jZVR5cGU6IFNhdmVkT2JqZWN0c1R5cGUgPSB7XG4gICAgICBuYW1lOiAnaW50ZWdyYXRpb24taW5zdGFuY2UnLFxuICAgICAgaGlkZGVuOiBmYWxzZSxcbiAgICAgIG5hbWVzcGFjZVR5cGU6ICdzaW5nbGUnLFxuICAgICAgbWFwcGluZ3M6IHtcbiAgICAgICAgZHluYW1pYzogZmFsc2UsXG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICBuYW1lOiB7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0ZW1wbGF0ZU5hbWU6IHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGRhdGFTb3VyY2U6IHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNyZWF0aW9uRGF0ZToge1xuICAgICAgICAgICAgdHlwZTogJ2RhdGUnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYXNzZXRzOiB7XG4gICAgICAgICAgICB0eXBlOiAnbmVzdGVkJyxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgY29yZS5zYXZlZE9iamVjdHMucmVnaXN0ZXJUeXBlKG9ic1BhbmVsVHlwZSk7XG4gICAgY29yZS5zYXZlZE9iamVjdHMucmVnaXN0ZXJUeXBlKGludGVncmF0aW9uSW5zdGFuY2VUeXBlKTtcblxuICAgIC8vIFJlZ2lzdGVyIHNlcnZlciBzaWRlIEFQSXNcbiAgICBzZXR1cFJvdXRlcyh7IHJvdXRlciwgY2xpZW50OiBvcGVuU2VhcmNoT2JzZXJ2YWJpbGl0eUNsaWVudCB9KTtcblxuICAgIGNvcmUuc2F2ZWRPYmplY3RzLnJlZ2lzdGVyVHlwZSh2aXN1YWxpemF0aW9uU2F2ZWRPYmplY3QpO1xuICAgIGNvcmUuc2F2ZWRPYmplY3RzLnJlZ2lzdGVyVHlwZShzZWFyY2hTYXZlZE9iamVjdCk7XG4gICAgY29yZS5jYXBhYmlsaXRpZXMucmVnaXN0ZXJQcm92aWRlcigoKSA9PiAoe1xuICAgICAgb2JzZXJ2YWJpbGl0eToge1xuICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgfSxcbiAgICB9KSk7XG5cbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgc3RhcnQoY29yZTogQ29yZVN0YXJ0KSB7XG4gICAgdGhpcy5sb2dnZXIuZGVidWcoJ09ic2VydmFiaWxpdHk6IFN0YXJ0ZWQnKTtcbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgc3RvcCgpIHt9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQWNBLElBQUFBLGdDQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxNQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRywyQkFBQSxHQUFBSCxPQUFBO0FBR29ELFNBQUFJLGdCQUFBQyxHQUFBLEVBQUFDLEdBQUEsRUFBQUMsS0FBQSxJQUFBRCxHQUFBLEdBQUFFLGNBQUEsQ0FBQUYsR0FBQSxPQUFBQSxHQUFBLElBQUFELEdBQUEsSUFBQUksTUFBQSxDQUFBQyxjQUFBLENBQUFMLEdBQUEsRUFBQUMsR0FBQSxJQUFBQyxLQUFBLEVBQUFBLEtBQUEsRUFBQUksVUFBQSxRQUFBQyxZQUFBLFFBQUFDLFFBQUEsb0JBQUFSLEdBQUEsQ0FBQUMsR0FBQSxJQUFBQyxLQUFBLFdBQUFGLEdBQUE7QUFBQSxTQUFBRyxlQUFBTSxHQUFBLFFBQUFSLEdBQUEsR0FBQVMsWUFBQSxDQUFBRCxHQUFBLDJCQUFBUixHQUFBLGdCQUFBQSxHQUFBLEdBQUFVLE1BQUEsQ0FBQVYsR0FBQTtBQUFBLFNBQUFTLGFBQUFFLEtBQUEsRUFBQUMsSUFBQSxlQUFBRCxLQUFBLGlCQUFBQSxLQUFBLGtCQUFBQSxLQUFBLE1BQUFFLElBQUEsR0FBQUYsS0FBQSxDQUFBRyxNQUFBLENBQUFDLFdBQUEsT0FBQUYsSUFBQSxLQUFBRyxTQUFBLFFBQUFDLEdBQUEsR0FBQUosSUFBQSxDQUFBSyxJQUFBLENBQUFQLEtBQUEsRUFBQUMsSUFBQSwyQkFBQUssR0FBQSxzQkFBQUEsR0FBQSxZQUFBRSxTQUFBLDREQUFBUCxJQUFBLGdCQUFBRixNQUFBLEdBQUFVLE1BQUEsRUFBQVQsS0FBQSxLQXBCcEQ7QUFDQTtBQUNBO0FBQ0E7QUFvQk8sTUFBTVUsbUJBQW1CLENBQ3dDO0VBR3RFQyxXQUFXQSxDQUFDQyxrQkFBNEMsRUFBRTtJQUFBekIsZUFBQTtJQUN4RCxJQUFJLENBQUMwQixNQUFNLEdBQUdELGtCQUFrQixDQUFDQyxNQUFNLENBQUNDLEdBQUcsQ0FBQyxDQUFDO0VBQy9DO0VBRU9DLEtBQUtBLENBQUNDLElBQWUsRUFBRTtJQUM1QixJQUFJLENBQUNILE1BQU0sQ0FBQ0ksS0FBSyxDQUFDLHNCQUFzQixDQUFDO0lBQ3pDLE1BQU1DLE1BQU0sR0FBR0YsSUFBSSxDQUFDRyxJQUFJLENBQUNDLFlBQVksQ0FBQyxDQUFDO0lBQ3ZDLE1BQU1DLDZCQUFtRCxHQUFHTCxJQUFJLENBQUNNLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDQyxZQUFZLENBQzdGLDBCQUEwQixFQUMxQjtNQUNFQyxPQUFPLEVBQUUsQ0FBQ0MscUJBQVMsRUFBRUMsOERBQTZCO0lBQ3BELENBQ0YsQ0FBQzs7SUFFRDtJQUNBWCxJQUFJLENBQUNHLElBQUksQ0FBQ1MsMkJBQTJCLENBQUMsc0JBQXNCLEVBQUUsQ0FBQ0MsT0FBTyxFQUFFQyxPQUFPLEtBQUs7TUFDbEYsT0FBTztRQUNMakIsTUFBTSxFQUFFLElBQUksQ0FBQ0EsTUFBTTtRQUNuQmtCLG1CQUFtQixFQUFFVjtNQUN2QixDQUFDO0lBQ0gsQ0FBQyxDQUFDO0lBRUYsTUFBTVcsWUFBOEIsR0FBRztNQUNyQ0MsSUFBSSxFQUFFLHFCQUFxQjtNQUMzQkMsTUFBTSxFQUFFLEtBQUs7TUFDYkMsYUFBYSxFQUFFLFFBQVE7TUFDdkJDLFFBQVEsRUFBRTtRQUNSQyxPQUFPLEVBQUUsS0FBSztRQUNkQyxVQUFVLEVBQUU7VUFDVkMsS0FBSyxFQUFFO1lBQ0xDLElBQUksRUFBRTtVQUNSLENBQUM7VUFDREMsV0FBVyxFQUFFO1lBQ1hELElBQUksRUFBRTtVQUNSO1FBQ0Y7TUFDRixDQUFDO01BQ0RFLFVBQVUsRUFBRTtRQUNWQyx1QkFBdUIsRUFBRSxJQUFJO1FBQzdCQyxXQUFXQSxDQUFBLEVBQUc7VUFDWixPQUFPO1lBQ0xDLElBQUksRUFBRyx3Q0FBdUM7WUFDOUNDLGtCQUFrQixFQUFFO1VBQ3RCLENBQUM7UUFDSCxDQUFDO1FBQ0RDLFFBQVFBLENBQUMzRCxHQUFHLEVBQUU7VUFDWixPQUFRLDJCQUEwQkEsR0FBRyxDQUFDNEQsRUFBRyxHQUFFO1FBQzdDO01BQ0YsQ0FBQztNQUNEQyxVQUFVLEVBQUU7UUFDVixPQUFPLEVBQUdDLEdBQUcsS0FBTTtVQUFFLEdBQUdBLEdBQUc7VUFBRVQsV0FBVyxFQUFFO1FBQUcsQ0FBQyxDQUFDO1FBQy9DLE9BQU8sRUFBR1MsR0FBRyxLQUFNO1VBQUUsR0FBR0EsR0FBRztVQUFFVCxXQUFXLEVBQUU7UUFBd0IsQ0FBQyxDQUFDO1FBQ3BFLE9BQU8sRUFBR1MsR0FBRyxLQUFNO1VBQUUsR0FBR0EsR0FBRztVQUFFQyxXQUFXLEVBQUVDLFFBQVEsQ0FBQ0YsR0FBRyxDQUFDQyxXQUFXLElBQUksR0FBRyxFQUFFLEVBQUU7UUFBRSxDQUFDO01BQ2xGO0lBQ0YsQ0FBQztJQUVELE1BQU1FLHVCQUF5QyxHQUFHO01BQ2hEcEIsSUFBSSxFQUFFLHNCQUFzQjtNQUM1QkMsTUFBTSxFQUFFLEtBQUs7TUFDYkMsYUFBYSxFQUFFLFFBQVE7TUFDdkJDLFFBQVEsRUFBRTtRQUNSQyxPQUFPLEVBQUUsS0FBSztRQUNkQyxVQUFVLEVBQUU7VUFDVkwsSUFBSSxFQUFFO1lBQ0pPLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRGMsWUFBWSxFQUFFO1lBQ1pkLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRGUsVUFBVSxFQUFFO1lBQ1ZmLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRGdCLFlBQVksRUFBRTtZQUNaaEIsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEaUIsTUFBTSxFQUFFO1lBQ05qQixJQUFJLEVBQUU7VUFDUjtRQUNGO01BQ0Y7SUFDRixDQUFDO0lBRUR4QixJQUFJLENBQUMwQyxZQUFZLENBQUNDLFlBQVksQ0FBQzNCLFlBQVksQ0FBQztJQUM1Q2hCLElBQUksQ0FBQzBDLFlBQVksQ0FBQ0MsWUFBWSxDQUFDTix1QkFBdUIsQ0FBQzs7SUFFdkQ7SUFDQSxJQUFBTyxrQkFBVyxFQUFDO01BQUUxQyxNQUFNO01BQUUyQyxNQUFNLEVBQUV4QztJQUE4QixDQUFDLENBQUM7SUFFOURMLElBQUksQ0FBQzBDLFlBQVksQ0FBQ0MsWUFBWSxDQUFDRyxvREFBd0IsQ0FBQztJQUN4RDlDLElBQUksQ0FBQzBDLFlBQVksQ0FBQ0MsWUFBWSxDQUFDSSw2Q0FBaUIsQ0FBQztJQUNqRC9DLElBQUksQ0FBQ2dELFlBQVksQ0FBQ0MsZ0JBQWdCLENBQUMsT0FBTztNQUN4Q0MsYUFBYSxFQUFFO1FBQ2JDLElBQUksRUFBRTtNQUNSO0lBQ0YsQ0FBQyxDQUFDLENBQUM7SUFFSCxPQUFPLENBQUMsQ0FBQztFQUNYO0VBRU9DLEtBQUtBLENBQUNwRCxJQUFlLEVBQUU7SUFDNUIsSUFBSSxDQUFDSCxNQUFNLENBQUNJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQztJQUMzQyxPQUFPLENBQUMsQ0FBQztFQUNYO0VBRU9vRCxJQUFJQSxDQUFBLEVBQUcsQ0FBQztBQUNqQjtBQUFDQyxPQUFBLENBQUE1RCxtQkFBQSxHQUFBQSxtQkFBQSJ9