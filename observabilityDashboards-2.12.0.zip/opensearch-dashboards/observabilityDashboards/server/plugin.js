"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ObservabilityPlugin = void 0;
var _operators = require("rxjs/operators");
var _opensearch_observability_plugin = require("./adaptors/opensearch_observability_plugin");
var _ppl_plugin = require("./adaptors/ppl_plugin");
var _index = require("./routes/index");
var _observability_saved_object = require("./saved_objects/observability_saved_object");
var _ppl_parser = require("./parsers/ppl_parser");
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); } /*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
class ObservabilityPlugin {
  constructor(initializerContext) {
    this.initializerContext = initializerContext;
    _defineProperty(this, "logger", void 0);
    this.logger = initializerContext.logger.get();
  }
  async setup(core, deps) {
    const {
      assistantDashboards
    } = deps;
    this.logger.debug('Observability: Setup');
    const router = core.http.createRouter();
    const config = await this.initializerContext.config.create().pipe((0, _operators.first)()).toPromise();
    const openSearchObservabilityClient = core.opensearch.legacy.createClient('opensearch_observability', {
      plugins: [_ppl_plugin.PPLPlugin, _opensearch_observability_plugin.OpenSearchObservabilityPlugin]
    });

    // @ts-ignore
    core.http.registerRouteHandlerContext('observability_plugin', (_context, _request) => {
      return {
        logger: this.logger,
        observabilityClient: openSearchObservabilityClient
      };
    });
    const obsPanelType = {
      name: 'observability-panel',
      hidden: false,
      namespaceType: 'single',
      mappings: {
        dynamic: false,
        properties: {
          title: {
            type: 'text'
          },
          description: {
            type: 'text'
          }
        }
      },
      management: {
        importableAndExportable: true,
        getInAppUrl() {
          return {
            path: `/app/management/observability/settings`,
            uiCapabilitiesPath: 'advancedSettings.show'
          };
        },
        getTitle(obj) {
          return `Observability Settings [${obj.id}]`;
        }
      },
      migrations: {
        '3.0.0': doc => ({
          ...doc,
          description: ''
        }),
        '3.0.1': doc => ({
          ...doc,
          description: 'Some Description Text'
        }),
        '3.0.2': doc => ({
          ...doc,
          dateCreated: parseInt(doc.dateCreated || '0', 10)
        })
      }
    };
    const integrationInstanceType = {
      name: 'integration-instance',
      hidden: false,
      namespaceType: 'single',
      mappings: {
        dynamic: false,
        properties: {
          name: {
            type: 'text'
          },
          templateName: {
            type: 'text'
          },
          dataSource: {
            type: 'text'
          },
          creationDate: {
            type: 'date'
          },
          assets: {
            type: 'nested'
          }
        }
      }
    };
    core.savedObjects.registerType(obsPanelType);
    core.savedObjects.registerType(integrationInstanceType);

    // Register server side APIs
    (0, _index.setupRoutes)({
      router,
      client: openSearchObservabilityClient,
      config
    });
    core.savedObjects.registerType(_observability_saved_object.visualizationSavedObject);
    core.savedObjects.registerType(_observability_saved_object.searchSavedObject);
    core.capabilities.registerProvider(() => ({
      observability: {
        show: true
      }
    }));
    assistantDashboards === null || assistantDashboards === void 0 || assistantDashboards.registerMessageParser(_ppl_parser.PPLParsers);
    return {};
  }
  start(_core) {
    this.logger.debug('Observability: Started');
    return {};
  }
  stop() {}
}
exports.ObservabilityPlugin = ObservabilityPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfb3BlcmF0b3JzIiwicmVxdWlyZSIsIl9vcGVuc2VhcmNoX29ic2VydmFiaWxpdHlfcGx1Z2luIiwiX3BwbF9wbHVnaW4iLCJfaW5kZXgiLCJfb2JzZXJ2YWJpbGl0eV9zYXZlZF9vYmplY3QiLCJfcHBsX3BhcnNlciIsIl9kZWZpbmVQcm9wZXJ0eSIsIm9iaiIsImtleSIsInZhbHVlIiwiX3RvUHJvcGVydHlLZXkiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJ3cml0YWJsZSIsImFyZyIsIl90b1ByaW1pdGl2ZSIsIlN0cmluZyIsImlucHV0IiwiaGludCIsInByaW0iLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsInVuZGVmaW5lZCIsInJlcyIsImNhbGwiLCJUeXBlRXJyb3IiLCJOdW1iZXIiLCJPYnNlcnZhYmlsaXR5UGx1Z2luIiwiY29uc3RydWN0b3IiLCJpbml0aWFsaXplckNvbnRleHQiLCJsb2dnZXIiLCJnZXQiLCJzZXR1cCIsImNvcmUiLCJkZXBzIiwiYXNzaXN0YW50RGFzaGJvYXJkcyIsImRlYnVnIiwicm91dGVyIiwiaHR0cCIsImNyZWF0ZVJvdXRlciIsImNvbmZpZyIsImNyZWF0ZSIsInBpcGUiLCJmaXJzdCIsInRvUHJvbWlzZSIsIm9wZW5TZWFyY2hPYnNlcnZhYmlsaXR5Q2xpZW50Iiwib3BlbnNlYXJjaCIsImxlZ2FjeSIsImNyZWF0ZUNsaWVudCIsInBsdWdpbnMiLCJQUExQbHVnaW4iLCJPcGVuU2VhcmNoT2JzZXJ2YWJpbGl0eVBsdWdpbiIsInJlZ2lzdGVyUm91dGVIYW5kbGVyQ29udGV4dCIsIl9jb250ZXh0IiwiX3JlcXVlc3QiLCJvYnNlcnZhYmlsaXR5Q2xpZW50Iiwib2JzUGFuZWxUeXBlIiwibmFtZSIsImhpZGRlbiIsIm5hbWVzcGFjZVR5cGUiLCJtYXBwaW5ncyIsImR5bmFtaWMiLCJwcm9wZXJ0aWVzIiwidGl0bGUiLCJ0eXBlIiwiZGVzY3JpcHRpb24iLCJtYW5hZ2VtZW50IiwiaW1wb3J0YWJsZUFuZEV4cG9ydGFibGUiLCJnZXRJbkFwcFVybCIsInBhdGgiLCJ1aUNhcGFiaWxpdGllc1BhdGgiLCJnZXRUaXRsZSIsImlkIiwibWlncmF0aW9ucyIsImRvYyIsImRhdGVDcmVhdGVkIiwicGFyc2VJbnQiLCJpbnRlZ3JhdGlvbkluc3RhbmNlVHlwZSIsInRlbXBsYXRlTmFtZSIsImRhdGFTb3VyY2UiLCJjcmVhdGlvbkRhdGUiLCJhc3NldHMiLCJzYXZlZE9iamVjdHMiLCJyZWdpc3RlclR5cGUiLCJzZXR1cFJvdXRlcyIsImNsaWVudCIsInZpc3VhbGl6YXRpb25TYXZlZE9iamVjdCIsInNlYXJjaFNhdmVkT2JqZWN0IiwiY2FwYWJpbGl0aWVzIiwicmVnaXN0ZXJQcm92aWRlciIsIm9ic2VydmFiaWxpdHkiLCJzaG93IiwicmVnaXN0ZXJNZXNzYWdlUGFyc2VyIiwiUFBMUGFyc2VycyIsInN0YXJ0IiwiX2NvcmUiLCJzdG9wIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbInBsdWdpbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7IGZpcnN0IH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgT2JzZXJ2YWJpbGl0eUNvbmZpZyB9IGZyb20gJy4nO1xuaW1wb3J0IHtcbiAgQ29yZVNldHVwLFxuICBDb3JlU3RhcnQsXG4gIElMZWdhY3lDbHVzdGVyQ2xpZW50LFxuICBMb2dnZXIsXG4gIFBsdWdpbixcbiAgUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0LFxuICBTYXZlZE9iamVjdHNUeXBlLFxufSBmcm9tICcuLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgT3BlblNlYXJjaE9ic2VydmFiaWxpdHlQbHVnaW4gfSBmcm9tICcuL2FkYXB0b3JzL29wZW5zZWFyY2hfb2JzZXJ2YWJpbGl0eV9wbHVnaW4nO1xuaW1wb3J0IHsgUFBMUGx1Z2luIH0gZnJvbSAnLi9hZGFwdG9ycy9wcGxfcGx1Z2luJztcbmltcG9ydCB7IHNldHVwUm91dGVzIH0gZnJvbSAnLi9yb3V0ZXMvaW5kZXgnO1xuaW1wb3J0IHtcbiAgc2VhcmNoU2F2ZWRPYmplY3QsXG4gIHZpc3VhbGl6YXRpb25TYXZlZE9iamVjdCxcbn0gZnJvbSAnLi9zYXZlZF9vYmplY3RzL29ic2VydmFiaWxpdHlfc2F2ZWRfb2JqZWN0JztcbmltcG9ydCB7IE9ic2VydmFiaWxpdHlQbHVnaW5TZXR1cCwgT2JzZXJ2YWJpbGl0eVBsdWdpblN0YXJ0LCBBc3Npc3RhbnRQbHVnaW5TZXR1cCB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgUFBMUGFyc2VycyB9IGZyb20gJy4vcGFyc2Vycy9wcGxfcGFyc2VyJztcblxuZXhwb3J0IGNsYXNzIE9ic2VydmFiaWxpdHlQbHVnaW5cbiAgaW1wbGVtZW50cyBQbHVnaW48T2JzZXJ2YWJpbGl0eVBsdWdpblNldHVwLCBPYnNlcnZhYmlsaXR5UGx1Z2luU3RhcnQ+IHtcbiAgcHJpdmF0ZSByZWFkb25seSBsb2dnZXI6IExvZ2dlcjtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IGluaXRpYWxpemVyQ29udGV4dDogUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0KSB7XG4gICAgdGhpcy5sb2dnZXIgPSBpbml0aWFsaXplckNvbnRleHQubG9nZ2VyLmdldCgpO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIHNldHVwKGNvcmU6IENvcmVTZXR1cCwgZGVwczogeyBhc3Npc3RhbnREYXNoYm9hcmRzPzogQXNzaXN0YW50UGx1Z2luU2V0dXAgfSkge1xuICAgIGNvbnN0IHsgYXNzaXN0YW50RGFzaGJvYXJkcyB9ID0gZGVwcztcbiAgICB0aGlzLmxvZ2dlci5kZWJ1ZygnT2JzZXJ2YWJpbGl0eTogU2V0dXAnKTtcbiAgICBjb25zdCByb3V0ZXIgPSBjb3JlLmh0dHAuY3JlYXRlUm91dGVyKCk7XG4gICAgY29uc3QgY29uZmlnID0gYXdhaXQgdGhpcy5pbml0aWFsaXplckNvbnRleHQuY29uZmlnXG4gICAgICAuY3JlYXRlPE9ic2VydmFiaWxpdHlDb25maWc+KClcbiAgICAgIC5waXBlKGZpcnN0KCkpXG4gICAgICAudG9Qcm9taXNlKCk7XG4gICAgY29uc3Qgb3BlblNlYXJjaE9ic2VydmFiaWxpdHlDbGllbnQ6IElMZWdhY3lDbHVzdGVyQ2xpZW50ID0gY29yZS5vcGVuc2VhcmNoLmxlZ2FjeS5jcmVhdGVDbGllbnQoXG4gICAgICAnb3BlbnNlYXJjaF9vYnNlcnZhYmlsaXR5JyxcbiAgICAgIHtcbiAgICAgICAgcGx1Z2luczogW1BQTFBsdWdpbiwgT3BlblNlYXJjaE9ic2VydmFiaWxpdHlQbHVnaW5dLFxuICAgICAgfVxuICAgICk7XG5cbiAgICAvLyBAdHMtaWdub3JlXG4gICAgY29yZS5odHRwLnJlZ2lzdGVyUm91dGVIYW5kbGVyQ29udGV4dCgnb2JzZXJ2YWJpbGl0eV9wbHVnaW4nLCAoX2NvbnRleHQsIF9yZXF1ZXN0KSA9PiB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsb2dnZXI6IHRoaXMubG9nZ2VyLFxuICAgICAgICBvYnNlcnZhYmlsaXR5Q2xpZW50OiBvcGVuU2VhcmNoT2JzZXJ2YWJpbGl0eUNsaWVudCxcbiAgICAgIH07XG4gICAgfSk7XG5cbiAgICBjb25zdCBvYnNQYW5lbFR5cGU6IFNhdmVkT2JqZWN0c1R5cGUgPSB7XG4gICAgICBuYW1lOiAnb2JzZXJ2YWJpbGl0eS1wYW5lbCcsXG4gICAgICBoaWRkZW46IGZhbHNlLFxuICAgICAgbmFtZXNwYWNlVHlwZTogJ3NpbmdsZScsXG4gICAgICBtYXBwaW5nczoge1xuICAgICAgICBkeW5hbWljOiBmYWxzZSxcbiAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgIHRpdGxlOiB7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBkZXNjcmlwdGlvbjoge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgbWFuYWdlbWVudDoge1xuICAgICAgICBpbXBvcnRhYmxlQW5kRXhwb3J0YWJsZTogdHJ1ZSxcbiAgICAgICAgZ2V0SW5BcHBVcmwoKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBhdGg6IGAvYXBwL21hbmFnZW1lbnQvb2JzZXJ2YWJpbGl0eS9zZXR0aW5nc2AsXG4gICAgICAgICAgICB1aUNhcGFiaWxpdGllc1BhdGg6ICdhZHZhbmNlZFNldHRpbmdzLnNob3cnLFxuICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgICAgIGdldFRpdGxlKG9iaikge1xuICAgICAgICAgIHJldHVybiBgT2JzZXJ2YWJpbGl0eSBTZXR0aW5ncyBbJHtvYmouaWR9XWA7XG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgbWlncmF0aW9uczoge1xuICAgICAgICAnMy4wLjAnOiAoZG9jKSA9PiAoeyAuLi5kb2MsIGRlc2NyaXB0aW9uOiAnJyB9KSxcbiAgICAgICAgJzMuMC4xJzogKGRvYykgPT4gKHsgLi4uZG9jLCBkZXNjcmlwdGlvbjogJ1NvbWUgRGVzY3JpcHRpb24gVGV4dCcgfSksXG4gICAgICAgICczLjAuMic6IChkb2MpID0+ICh7IC4uLmRvYywgZGF0ZUNyZWF0ZWQ6IHBhcnNlSW50KGRvYy5kYXRlQ3JlYXRlZCB8fCAnMCcsIDEwKSB9KSxcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIGNvbnN0IGludGVncmF0aW9uSW5zdGFuY2VUeXBlOiBTYXZlZE9iamVjdHNUeXBlID0ge1xuICAgICAgbmFtZTogJ2ludGVncmF0aW9uLWluc3RhbmNlJyxcbiAgICAgIGhpZGRlbjogZmFsc2UsXG4gICAgICBuYW1lc3BhY2VUeXBlOiAnc2luZ2xlJyxcbiAgICAgIG1hcHBpbmdzOiB7XG4gICAgICAgIGR5bmFtaWM6IGZhbHNlLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgbmFtZToge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgdGVtcGxhdGVOYW1lOiB7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBkYXRhU291cmNlOiB7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBjcmVhdGlvbkRhdGU6IHtcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGFzc2V0czoge1xuICAgICAgICAgICAgdHlwZTogJ25lc3RlZCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIGNvcmUuc2F2ZWRPYmplY3RzLnJlZ2lzdGVyVHlwZShvYnNQYW5lbFR5cGUpO1xuICAgIGNvcmUuc2F2ZWRPYmplY3RzLnJlZ2lzdGVyVHlwZShpbnRlZ3JhdGlvbkluc3RhbmNlVHlwZSk7XG5cbiAgICAvLyBSZWdpc3RlciBzZXJ2ZXIgc2lkZSBBUElzXG4gICAgc2V0dXBSb3V0ZXMoeyByb3V0ZXIsIGNsaWVudDogb3BlblNlYXJjaE9ic2VydmFiaWxpdHlDbGllbnQsIGNvbmZpZyB9KTtcblxuICAgIGNvcmUuc2F2ZWRPYmplY3RzLnJlZ2lzdGVyVHlwZSh2aXN1YWxpemF0aW9uU2F2ZWRPYmplY3QpO1xuICAgIGNvcmUuc2F2ZWRPYmplY3RzLnJlZ2lzdGVyVHlwZShzZWFyY2hTYXZlZE9iamVjdCk7XG4gICAgY29yZS5jYXBhYmlsaXRpZXMucmVnaXN0ZXJQcm92aWRlcigoKSA9PiAoe1xuICAgICAgb2JzZXJ2YWJpbGl0eToge1xuICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgfSxcbiAgICB9KSk7XG5cbiAgICBhc3Npc3RhbnREYXNoYm9hcmRzPy5yZWdpc3Rlck1lc3NhZ2VQYXJzZXIoUFBMUGFyc2Vycyk7XG5cbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgc3RhcnQoX2NvcmU6IENvcmVTdGFydCkge1xuICAgIHRoaXMubG9nZ2VyLmRlYnVnKCdPYnNlcnZhYmlsaXR5OiBTdGFydGVkJyk7XG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgcHVibGljIHN0b3AoKSB7fVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxVQUFBLEdBQUFDLE9BQUE7QUFXQSxJQUFBQyxnQ0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsTUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksMkJBQUEsR0FBQUosT0FBQTtBQUtBLElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFrRCxTQUFBTSxnQkFBQUMsR0FBQSxFQUFBQyxHQUFBLEVBQUFDLEtBQUEsSUFBQUQsR0FBQSxHQUFBRSxjQUFBLENBQUFGLEdBQUEsT0FBQUEsR0FBQSxJQUFBRCxHQUFBLElBQUFJLE1BQUEsQ0FBQUMsY0FBQSxDQUFBTCxHQUFBLEVBQUFDLEdBQUEsSUFBQUMsS0FBQSxFQUFBQSxLQUFBLEVBQUFJLFVBQUEsUUFBQUMsWUFBQSxRQUFBQyxRQUFBLG9CQUFBUixHQUFBLENBQUFDLEdBQUEsSUFBQUMsS0FBQSxXQUFBRixHQUFBO0FBQUEsU0FBQUcsZUFBQU0sR0FBQSxRQUFBUixHQUFBLEdBQUFTLFlBQUEsQ0FBQUQsR0FBQSwyQkFBQVIsR0FBQSxnQkFBQUEsR0FBQSxHQUFBVSxNQUFBLENBQUFWLEdBQUE7QUFBQSxTQUFBUyxhQUFBRSxLQUFBLEVBQUFDLElBQUEsZUFBQUQsS0FBQSxpQkFBQUEsS0FBQSxrQkFBQUEsS0FBQSxNQUFBRSxJQUFBLEdBQUFGLEtBQUEsQ0FBQUcsTUFBQSxDQUFBQyxXQUFBLE9BQUFGLElBQUEsS0FBQUcsU0FBQSxRQUFBQyxHQUFBLEdBQUFKLElBQUEsQ0FBQUssSUFBQSxDQUFBUCxLQUFBLEVBQUFDLElBQUEsMkJBQUFLLEdBQUEsc0JBQUFBLEdBQUEsWUFBQUUsU0FBQSw0REFBQVAsSUFBQSxnQkFBQUYsTUFBQSxHQUFBVSxNQUFBLEVBQUFULEtBQUEsS0F4QmxEO0FBQ0E7QUFDQTtBQUNBO0FBdUJPLE1BQU1VLG1CQUFtQixDQUN3QztFQUd0RUMsV0FBV0EsQ0FBa0JDLGtCQUE0QyxFQUFFO0lBQUEsS0FBOUNBLGtCQUE0QyxHQUE1Q0Esa0JBQTRDO0lBQUF6QixlQUFBO0lBQ3ZFLElBQUksQ0FBQzBCLE1BQU0sR0FBR0Qsa0JBQWtCLENBQUNDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDLENBQUM7RUFDL0M7RUFFQSxNQUFhQyxLQUFLQSxDQUFDQyxJQUFlLEVBQUVDLElBQW9ELEVBQUU7SUFDeEYsTUFBTTtNQUFFQztJQUFvQixDQUFDLEdBQUdELElBQUk7SUFDcEMsSUFBSSxDQUFDSixNQUFNLENBQUNNLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQztJQUN6QyxNQUFNQyxNQUFNLEdBQUdKLElBQUksQ0FBQ0ssSUFBSSxDQUFDQyxZQUFZLENBQUMsQ0FBQztJQUN2QyxNQUFNQyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUNYLGtCQUFrQixDQUFDVyxNQUFNLENBQ2hEQyxNQUFNLENBQXNCLENBQUMsQ0FDN0JDLElBQUksQ0FBQyxJQUFBQyxnQkFBSyxFQUFDLENBQUMsQ0FBQyxDQUNiQyxTQUFTLENBQUMsQ0FBQztJQUNkLE1BQU1DLDZCQUFtRCxHQUFHWixJQUFJLENBQUNhLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDQyxZQUFZLENBQzdGLDBCQUEwQixFQUMxQjtNQUNFQyxPQUFPLEVBQUUsQ0FBQ0MscUJBQVMsRUFBRUMsOERBQTZCO0lBQ3BELENBQ0YsQ0FBQzs7SUFFRDtJQUNBbEIsSUFBSSxDQUFDSyxJQUFJLENBQUNjLDJCQUEyQixDQUFDLHNCQUFzQixFQUFFLENBQUNDLFFBQVEsRUFBRUMsUUFBUSxLQUFLO01BQ3BGLE9BQU87UUFDTHhCLE1BQU0sRUFBRSxJQUFJLENBQUNBLE1BQU07UUFDbkJ5QixtQkFBbUIsRUFBRVY7TUFDdkIsQ0FBQztJQUNILENBQUMsQ0FBQztJQUVGLE1BQU1XLFlBQThCLEdBQUc7TUFDckNDLElBQUksRUFBRSxxQkFBcUI7TUFDM0JDLE1BQU0sRUFBRSxLQUFLO01BQ2JDLGFBQWEsRUFBRSxRQUFRO01BQ3ZCQyxRQUFRLEVBQUU7UUFDUkMsT0FBTyxFQUFFLEtBQUs7UUFDZEMsVUFBVSxFQUFFO1VBQ1ZDLEtBQUssRUFBRTtZQUNMQyxJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RDLFdBQVcsRUFBRTtZQUNYRCxJQUFJLEVBQUU7VUFDUjtRQUNGO01BQ0YsQ0FBQztNQUNERSxVQUFVLEVBQUU7UUFDVkMsdUJBQXVCLEVBQUUsSUFBSTtRQUM3QkMsV0FBV0EsQ0FBQSxFQUFHO1VBQ1osT0FBTztZQUNMQyxJQUFJLEVBQUcsd0NBQXVDO1lBQzlDQyxrQkFBa0IsRUFBRTtVQUN0QixDQUFDO1FBQ0gsQ0FBQztRQUNEQyxRQUFRQSxDQUFDbEUsR0FBRyxFQUFFO1VBQ1osT0FBUSwyQkFBMEJBLEdBQUcsQ0FBQ21FLEVBQUcsR0FBRTtRQUM3QztNQUNGLENBQUM7TUFDREMsVUFBVSxFQUFFO1FBQ1YsT0FBTyxFQUFHQyxHQUFHLEtBQU07VUFBRSxHQUFHQSxHQUFHO1VBQUVULFdBQVcsRUFBRTtRQUFHLENBQUMsQ0FBQztRQUMvQyxPQUFPLEVBQUdTLEdBQUcsS0FBTTtVQUFFLEdBQUdBLEdBQUc7VUFBRVQsV0FBVyxFQUFFO1FBQXdCLENBQUMsQ0FBQztRQUNwRSxPQUFPLEVBQUdTLEdBQUcsS0FBTTtVQUFFLEdBQUdBLEdBQUc7VUFBRUMsV0FBVyxFQUFFQyxRQUFRLENBQUNGLEdBQUcsQ0FBQ0MsV0FBVyxJQUFJLEdBQUcsRUFBRSxFQUFFO1FBQUUsQ0FBQztNQUNsRjtJQUNGLENBQUM7SUFFRCxNQUFNRSx1QkFBeUMsR0FBRztNQUNoRHBCLElBQUksRUFBRSxzQkFBc0I7TUFDNUJDLE1BQU0sRUFBRSxLQUFLO01BQ2JDLGFBQWEsRUFBRSxRQUFRO01BQ3ZCQyxRQUFRLEVBQUU7UUFDUkMsT0FBTyxFQUFFLEtBQUs7UUFDZEMsVUFBVSxFQUFFO1VBQ1ZMLElBQUksRUFBRTtZQUNKTyxJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RjLFlBQVksRUFBRTtZQUNaZCxJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RlLFVBQVUsRUFBRTtZQUNWZixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RnQixZQUFZLEVBQUU7WUFDWmhCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRGlCLE1BQU0sRUFBRTtZQUNOakIsSUFBSSxFQUFFO1VBQ1I7UUFDRjtNQUNGO0lBQ0YsQ0FBQztJQUVEL0IsSUFBSSxDQUFDaUQsWUFBWSxDQUFDQyxZQUFZLENBQUMzQixZQUFZLENBQUM7SUFDNUN2QixJQUFJLENBQUNpRCxZQUFZLENBQUNDLFlBQVksQ0FBQ04sdUJBQXVCLENBQUM7O0lBRXZEO0lBQ0EsSUFBQU8sa0JBQVcsRUFBQztNQUFFL0MsTUFBTTtNQUFFZ0QsTUFBTSxFQUFFeEMsNkJBQTZCO01BQUVMO0lBQU8sQ0FBQyxDQUFDO0lBRXRFUCxJQUFJLENBQUNpRCxZQUFZLENBQUNDLFlBQVksQ0FBQ0csb0RBQXdCLENBQUM7SUFDeERyRCxJQUFJLENBQUNpRCxZQUFZLENBQUNDLFlBQVksQ0FBQ0ksNkNBQWlCLENBQUM7SUFDakR0RCxJQUFJLENBQUN1RCxZQUFZLENBQUNDLGdCQUFnQixDQUFDLE9BQU87TUFDeENDLGFBQWEsRUFBRTtRQUNiQyxJQUFJLEVBQUU7TUFDUjtJQUNGLENBQUMsQ0FBQyxDQUFDO0lBRUh4RCxtQkFBbUIsYUFBbkJBLG1CQUFtQixlQUFuQkEsbUJBQW1CLENBQUV5RCxxQkFBcUIsQ0FBQ0Msc0JBQVUsQ0FBQztJQUV0RCxPQUFPLENBQUMsQ0FBQztFQUNYO0VBRU9DLEtBQUtBLENBQUNDLEtBQWdCLEVBQUU7SUFDN0IsSUFBSSxDQUFDakUsTUFBTSxDQUFDTSxLQUFLLENBQUMsd0JBQXdCLENBQUM7SUFDM0MsT0FBTyxDQUFDLENBQUM7RUFDWDtFQUVPNEQsSUFBSUEsQ0FBQSxFQUFHLENBQUM7QUFDakI7QUFBQ0MsT0FBQSxDQUFBdEUsbUJBQUEsR0FBQUEsbUJBQUEifQ==