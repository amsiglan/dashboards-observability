"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ObservabilityPlugin = void 0;
var _opensearch_observability_plugin = require("./adaptors/opensearch_observability_plugin");
var _ppl_plugin = require("./adaptors/ppl_plugin");
var _index = require("./routes/index");
var _observability_saved_object = require("./saved_objects/observability_saved_object");
var _ppl_parser = require("./parsers/ppl_parser");
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); } /*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
class ObservabilityPlugin {
  constructor(initializerContext) {
    this.initializerContext = initializerContext;
    _defineProperty(this, "logger", void 0);
    this.logger = initializerContext.logger.get();
  }
  async setup(core, deps) {
    const {
      assistantDashboards
    } = deps;
    this.logger.debug('Observability: Setup');
    const router = core.http.createRouter();
    const openSearchObservabilityClient = core.opensearch.legacy.createClient('opensearch_observability', {
      plugins: [_ppl_plugin.PPLPlugin, _opensearch_observability_plugin.OpenSearchObservabilityPlugin]
    });

    // @ts-ignore
    core.http.registerRouteHandlerContext('observability_plugin', (_context, _request) => {
      return {
        logger: this.logger,
        observabilityClient: openSearchObservabilityClient
      };
    });
    const obsPanelType = {
      name: 'observability-panel',
      hidden: false,
      namespaceType: 'single',
      mappings: {
        dynamic: false,
        properties: {
          title: {
            type: 'text'
          },
          description: {
            type: 'text'
          }
        }
      },
      management: {
        importableAndExportable: true,
        getInAppUrl() {
          return {
            path: `/app/management/observability/settings`,
            uiCapabilitiesPath: 'advancedSettings.show'
          };
        },
        getTitle(obj) {
          return `Observability Settings [${obj.id}]`;
        }
      },
      migrations: {
        '3.0.0': doc => ({
          ...doc,
          description: ''
        }),
        '3.0.1': doc => ({
          ...doc,
          description: 'Some Description Text'
        }),
        '3.0.2': doc => ({
          ...doc,
          dateCreated: parseInt(doc.dateCreated || '0', 10)
        })
      }
    };
    const integrationInstanceType = {
      name: 'integration-instance',
      hidden: false,
      namespaceType: 'single',
      management: {
        importableAndExportable: true,
        getInAppUrl(obj) {
          return {
            path: `/app/integrations#/installed/${obj.id}`,
            uiCapabilitiesPath: 'advancedSettings.show'
          };
        },
        getTitle(obj) {
          return obj.attributes.name;
        }
      },
      mappings: {
        dynamic: false,
        properties: {
          name: {
            type: 'text'
          },
          templateName: {
            type: 'text'
          },
          dataSource: {
            type: 'text'
          },
          creationDate: {
            type: 'date'
          },
          assets: {
            type: 'nested'
          }
        }
      }
    };
    const integrationTemplateType = {
      name: 'integration-template',
      hidden: false,
      namespaceType: 'single',
      management: {
        importableAndExportable: true,
        getInAppUrl(obj) {
          return {
            path: `/app/integrations#/available/${obj.attributes.name}`,
            uiCapabilitiesPath: 'advancedSettings.show'
          };
        },
        getTitle(obj) {
          var _obj$attributes$displ;
          return (_obj$attributes$displ = obj.attributes.displayName) !== null && _obj$attributes$displ !== void 0 ? _obj$attributes$displ : obj.attributes.name;
        }
      },
      mappings: {
        dynamic: false,
        properties: {
          name: {
            type: 'text'
          },
          version: {
            type: 'text'
          },
          displayName: {
            type: 'text'
          },
          license: {
            type: 'text'
          },
          type: {
            type: 'text'
          },
          labels: {
            type: 'text'
          },
          author: {
            type: 'text'
          },
          description: {
            type: 'text'
          },
          sourceUrl: {
            type: 'text'
          },
          statics: {
            type: 'nested'
          },
          components: {
            type: 'nested'
          },
          assets: {
            type: 'nested'
          },
          sampleData: {
            type: 'nested'
          }
        }
      }
    };
    core.savedObjects.registerType(obsPanelType);
    core.savedObjects.registerType(integrationInstanceType);
    core.savedObjects.registerType(integrationTemplateType);

    // Register server side APIs
    (0, _index.setupRoutes)({
      router,
      client: openSearchObservabilityClient
    });
    core.savedObjects.registerType(_observability_saved_object.visualizationSavedObject);
    core.savedObjects.registerType(_observability_saved_object.searchSavedObject);
    core.capabilities.registerProvider(() => ({
      observability: {
        show: true
      }
    }));
    assistantDashboards === null || assistantDashboards === void 0 || assistantDashboards.registerMessageParser(_ppl_parser.PPLParsers);
    return {};
  }
  start(_core) {
    this.logger.debug('Observability: Started');
    return {};
  }
  stop() {}
}
exports.ObservabilityPlugin = ObservabilityPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfb3BlbnNlYXJjaF9vYnNlcnZhYmlsaXR5X3BsdWdpbiIsInJlcXVpcmUiLCJfcHBsX3BsdWdpbiIsIl9pbmRleCIsIl9vYnNlcnZhYmlsaXR5X3NhdmVkX29iamVjdCIsIl9wcGxfcGFyc2VyIiwiX2RlZmluZVByb3BlcnR5Iiwib2JqIiwia2V5IiwidmFsdWUiLCJfdG9Qcm9wZXJ0eUtleSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSIsIndyaXRhYmxlIiwiYXJnIiwiX3RvUHJpbWl0aXZlIiwiU3RyaW5nIiwiaW5wdXQiLCJoaW50IiwicHJpbSIsIlN5bWJvbCIsInRvUHJpbWl0aXZlIiwidW5kZWZpbmVkIiwicmVzIiwiY2FsbCIsIlR5cGVFcnJvciIsIk51bWJlciIsIk9ic2VydmFiaWxpdHlQbHVnaW4iLCJjb25zdHJ1Y3RvciIsImluaXRpYWxpemVyQ29udGV4dCIsImxvZ2dlciIsImdldCIsInNldHVwIiwiY29yZSIsImRlcHMiLCJhc3Npc3RhbnREYXNoYm9hcmRzIiwiZGVidWciLCJyb3V0ZXIiLCJodHRwIiwiY3JlYXRlUm91dGVyIiwib3BlblNlYXJjaE9ic2VydmFiaWxpdHlDbGllbnQiLCJvcGVuc2VhcmNoIiwibGVnYWN5IiwiY3JlYXRlQ2xpZW50IiwicGx1Z2lucyIsIlBQTFBsdWdpbiIsIk9wZW5TZWFyY2hPYnNlcnZhYmlsaXR5UGx1Z2luIiwicmVnaXN0ZXJSb3V0ZUhhbmRsZXJDb250ZXh0IiwiX2NvbnRleHQiLCJfcmVxdWVzdCIsIm9ic2VydmFiaWxpdHlDbGllbnQiLCJvYnNQYW5lbFR5cGUiLCJuYW1lIiwiaGlkZGVuIiwibmFtZXNwYWNlVHlwZSIsIm1hcHBpbmdzIiwiZHluYW1pYyIsInByb3BlcnRpZXMiLCJ0aXRsZSIsInR5cGUiLCJkZXNjcmlwdGlvbiIsIm1hbmFnZW1lbnQiLCJpbXBvcnRhYmxlQW5kRXhwb3J0YWJsZSIsImdldEluQXBwVXJsIiwicGF0aCIsInVpQ2FwYWJpbGl0aWVzUGF0aCIsImdldFRpdGxlIiwiaWQiLCJtaWdyYXRpb25zIiwiZG9jIiwiZGF0ZUNyZWF0ZWQiLCJwYXJzZUludCIsImludGVncmF0aW9uSW5zdGFuY2VUeXBlIiwiYXR0cmlidXRlcyIsInRlbXBsYXRlTmFtZSIsImRhdGFTb3VyY2UiLCJjcmVhdGlvbkRhdGUiLCJhc3NldHMiLCJpbnRlZ3JhdGlvblRlbXBsYXRlVHlwZSIsIl9vYmokYXR0cmlidXRlcyRkaXNwbCIsImRpc3BsYXlOYW1lIiwidmVyc2lvbiIsImxpY2Vuc2UiLCJsYWJlbHMiLCJhdXRob3IiLCJzb3VyY2VVcmwiLCJzdGF0aWNzIiwiY29tcG9uZW50cyIsInNhbXBsZURhdGEiLCJzYXZlZE9iamVjdHMiLCJyZWdpc3RlclR5cGUiLCJzZXR1cFJvdXRlcyIsImNsaWVudCIsInZpc3VhbGl6YXRpb25TYXZlZE9iamVjdCIsInNlYXJjaFNhdmVkT2JqZWN0IiwiY2FwYWJpbGl0aWVzIiwicmVnaXN0ZXJQcm92aWRlciIsIm9ic2VydmFiaWxpdHkiLCJzaG93IiwicmVnaXN0ZXJNZXNzYWdlUGFyc2VyIiwiUFBMUGFyc2VycyIsInN0YXJ0IiwiX2NvcmUiLCJzdG9wIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbInBsdWdpbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7XG4gIENvcmVTZXR1cCxcbiAgQ29yZVN0YXJ0LFxuICBJTGVnYWN5Q2x1c3RlckNsaWVudCxcbiAgTG9nZ2VyLFxuICBQbHVnaW4sXG4gIFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCxcbiAgU2F2ZWRPYmplY3QsXG4gIFNhdmVkT2JqZWN0c1R5cGUsXG59IGZyb20gJy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBPcGVuU2VhcmNoT2JzZXJ2YWJpbGl0eVBsdWdpbiB9IGZyb20gJy4vYWRhcHRvcnMvb3BlbnNlYXJjaF9vYnNlcnZhYmlsaXR5X3BsdWdpbic7XG5pbXBvcnQgeyBQUExQbHVnaW4gfSBmcm9tICcuL2FkYXB0b3JzL3BwbF9wbHVnaW4nO1xuaW1wb3J0IHsgc2V0dXBSb3V0ZXMgfSBmcm9tICcuL3JvdXRlcy9pbmRleCc7XG5pbXBvcnQge1xuICBzZWFyY2hTYXZlZE9iamVjdCxcbiAgdmlzdWFsaXphdGlvblNhdmVkT2JqZWN0LFxufSBmcm9tICcuL3NhdmVkX29iamVjdHMvb2JzZXJ2YWJpbGl0eV9zYXZlZF9vYmplY3QnO1xuaW1wb3J0IHsgT2JzZXJ2YWJpbGl0eVBsdWdpblNldHVwLCBPYnNlcnZhYmlsaXR5UGx1Z2luU3RhcnQsIEFzc2lzdGFudFBsdWdpblNldHVwIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBQUExQYXJzZXJzIH0gZnJvbSAnLi9wYXJzZXJzL3BwbF9wYXJzZXInO1xuXG5leHBvcnQgY2xhc3MgT2JzZXJ2YWJpbGl0eVBsdWdpblxuICBpbXBsZW1lbnRzIFBsdWdpbjxPYnNlcnZhYmlsaXR5UGx1Z2luU2V0dXAsIE9ic2VydmFiaWxpdHlQbHVnaW5TdGFydD4ge1xuICBwcml2YXRlIHJlYWRvbmx5IGxvZ2dlcjogTG9nZ2VyO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgICB0aGlzLmxvZ2dlciA9IGluaXRpYWxpemVyQ29udGV4dC5sb2dnZXIuZ2V0KCk7XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgc2V0dXAoY29yZTogQ29yZVNldHVwLCBkZXBzOiB7IGFzc2lzdGFudERhc2hib2FyZHM/OiBBc3Npc3RhbnRQbHVnaW5TZXR1cCB9KSB7XG4gICAgY29uc3QgeyBhc3Npc3RhbnREYXNoYm9hcmRzIH0gPSBkZXBzO1xuICAgIHRoaXMubG9nZ2VyLmRlYnVnKCdPYnNlcnZhYmlsaXR5OiBTZXR1cCcpO1xuICAgIGNvbnN0IHJvdXRlciA9IGNvcmUuaHR0cC5jcmVhdGVSb3V0ZXIoKTtcbiAgICBjb25zdCBvcGVuU2VhcmNoT2JzZXJ2YWJpbGl0eUNsaWVudDogSUxlZ2FjeUNsdXN0ZXJDbGllbnQgPSBjb3JlLm9wZW5zZWFyY2gubGVnYWN5LmNyZWF0ZUNsaWVudChcbiAgICAgICdvcGVuc2VhcmNoX29ic2VydmFiaWxpdHknLFxuICAgICAge1xuICAgICAgICBwbHVnaW5zOiBbUFBMUGx1Z2luLCBPcGVuU2VhcmNoT2JzZXJ2YWJpbGl0eVBsdWdpbl0sXG4gICAgICB9XG4gICAgKTtcblxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBjb3JlLmh0dHAucmVnaXN0ZXJSb3V0ZUhhbmRsZXJDb250ZXh0KCdvYnNlcnZhYmlsaXR5X3BsdWdpbicsIChfY29udGV4dCwgX3JlcXVlc3QpID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxvZ2dlcjogdGhpcy5sb2dnZXIsXG4gICAgICAgIG9ic2VydmFiaWxpdHlDbGllbnQ6IG9wZW5TZWFyY2hPYnNlcnZhYmlsaXR5Q2xpZW50LFxuICAgICAgfTtcbiAgICB9KTtcblxuICAgIGNvbnN0IG9ic1BhbmVsVHlwZTogU2F2ZWRPYmplY3RzVHlwZSA9IHtcbiAgICAgIG5hbWU6ICdvYnNlcnZhYmlsaXR5LXBhbmVsJyxcbiAgICAgIGhpZGRlbjogZmFsc2UsXG4gICAgICBuYW1lc3BhY2VUeXBlOiAnc2luZ2xlJyxcbiAgICAgIG1hcHBpbmdzOiB7XG4gICAgICAgIGR5bmFtaWM6IGZhbHNlLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiB7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBtYW5hZ2VtZW50OiB7XG4gICAgICAgIGltcG9ydGFibGVBbmRFeHBvcnRhYmxlOiB0cnVlLFxuICAgICAgICBnZXRJbkFwcFVybCgpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcGF0aDogYC9hcHAvbWFuYWdlbWVudC9vYnNlcnZhYmlsaXR5L3NldHRpbmdzYCxcbiAgICAgICAgICAgIHVpQ2FwYWJpbGl0aWVzUGF0aDogJ2FkdmFuY2VkU2V0dGluZ3Muc2hvdycsXG4gICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0VGl0bGUob2JqKSB7XG4gICAgICAgICAgcmV0dXJuIGBPYnNlcnZhYmlsaXR5IFNldHRpbmdzIFske29iai5pZH1dYDtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBtaWdyYXRpb25zOiB7XG4gICAgICAgICczLjAuMCc6IChkb2MpID0+ICh7IC4uLmRvYywgZGVzY3JpcHRpb246ICcnIH0pLFxuICAgICAgICAnMy4wLjEnOiAoZG9jKSA9PiAoeyAuLi5kb2MsIGRlc2NyaXB0aW9uOiAnU29tZSBEZXNjcmlwdGlvbiBUZXh0JyB9KSxcbiAgICAgICAgJzMuMC4yJzogKGRvYykgPT4gKHtcbiAgICAgICAgICAuLi5kb2MsXG4gICAgICAgICAgZGF0ZUNyZWF0ZWQ6IHBhcnNlSW50KChkb2MgYXMgeyBkYXRlQ3JlYXRlZD86IHN0cmluZyB9KS5kYXRlQ3JlYXRlZCB8fCAnMCcsIDEwKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH07XG5cbiAgICBjb25zdCBpbnRlZ3JhdGlvbkluc3RhbmNlVHlwZTogU2F2ZWRPYmplY3RzVHlwZSA9IHtcbiAgICAgIG5hbWU6ICdpbnRlZ3JhdGlvbi1pbnN0YW5jZScsXG4gICAgICBoaWRkZW46IGZhbHNlLFxuICAgICAgbmFtZXNwYWNlVHlwZTogJ3NpbmdsZScsXG4gICAgICBtYW5hZ2VtZW50OiB7XG4gICAgICAgIGltcG9ydGFibGVBbmRFeHBvcnRhYmxlOiB0cnVlLFxuICAgICAgICBnZXRJbkFwcFVybChvYmo6IFNhdmVkT2JqZWN0PEludGVncmF0aW9uSW5zdGFuY2U+KSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBhdGg6IGAvYXBwL2ludGVncmF0aW9ucyMvaW5zdGFsbGVkLyR7b2JqLmlkfWAsXG4gICAgICAgICAgICB1aUNhcGFiaWxpdGllc1BhdGg6ICdhZHZhbmNlZFNldHRpbmdzLnNob3cnLFxuICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgICAgIGdldFRpdGxlKG9iajogU2F2ZWRPYmplY3Q8SW50ZWdyYXRpb25JbnN0YW5jZT4pIHtcbiAgICAgICAgICByZXR1cm4gb2JqLmF0dHJpYnV0ZXMubmFtZTtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBtYXBwaW5nczoge1xuICAgICAgICBkeW5hbWljOiBmYWxzZSxcbiAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgIG5hbWU6IHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRlbXBsYXRlTmFtZToge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgZGF0YVNvdXJjZToge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgY3JlYXRpb25EYXRlOiB7XG4gICAgICAgICAgICB0eXBlOiAnZGF0ZScsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBhc3NldHM6IHtcbiAgICAgICAgICAgIHR5cGU6ICduZXN0ZWQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH07XG5cbiAgICBjb25zdCBpbnRlZ3JhdGlvblRlbXBsYXRlVHlwZTogU2F2ZWRPYmplY3RzVHlwZSA9IHtcbiAgICAgIG5hbWU6ICdpbnRlZ3JhdGlvbi10ZW1wbGF0ZScsXG4gICAgICBoaWRkZW46IGZhbHNlLFxuICAgICAgbmFtZXNwYWNlVHlwZTogJ3NpbmdsZScsXG4gICAgICBtYW5hZ2VtZW50OiB7XG4gICAgICAgIGltcG9ydGFibGVBbmRFeHBvcnRhYmxlOiB0cnVlLFxuICAgICAgICBnZXRJbkFwcFVybChvYmo6IFNhdmVkT2JqZWN0PFNlcmlhbGl6ZWRJbnRlZ3JhdGlvbj4pIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcGF0aDogYC9hcHAvaW50ZWdyYXRpb25zIy9hdmFpbGFibGUvJHtvYmouYXR0cmlidXRlcy5uYW1lfWAsXG4gICAgICAgICAgICB1aUNhcGFiaWxpdGllc1BhdGg6ICdhZHZhbmNlZFNldHRpbmdzLnNob3cnLFxuICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgICAgIGdldFRpdGxlKG9iajogU2F2ZWRPYmplY3Q8U2VyaWFsaXplZEludGVncmF0aW9uPikge1xuICAgICAgICAgIHJldHVybiBvYmouYXR0cmlidXRlcy5kaXNwbGF5TmFtZSA/PyBvYmouYXR0cmlidXRlcy5uYW1lO1xuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIG1hcHBpbmdzOiB7XG4gICAgICAgIGR5bmFtaWM6IGZhbHNlLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgbmFtZToge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgdmVyc2lvbjoge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgZGlzcGxheU5hbWU6IHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGxpY2Vuc2U6IHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHR5cGU6IHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYXV0aG9yOiB7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBkZXNjcmlwdGlvbjoge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgc291cmNlVXJsOiB7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBzdGF0aWNzOiB7XG4gICAgICAgICAgICB0eXBlOiAnbmVzdGVkJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNvbXBvbmVudHM6IHtcbiAgICAgICAgICAgIHR5cGU6ICduZXN0ZWQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYXNzZXRzOiB7XG4gICAgICAgICAgICB0eXBlOiAnbmVzdGVkJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHNhbXBsZURhdGE6IHtcbiAgICAgICAgICAgIHR5cGU6ICduZXN0ZWQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH07XG5cbiAgICBjb3JlLnNhdmVkT2JqZWN0cy5yZWdpc3RlclR5cGUob2JzUGFuZWxUeXBlKTtcbiAgICBjb3JlLnNhdmVkT2JqZWN0cy5yZWdpc3RlclR5cGUoaW50ZWdyYXRpb25JbnN0YW5jZVR5cGUpO1xuICAgIGNvcmUuc2F2ZWRPYmplY3RzLnJlZ2lzdGVyVHlwZShpbnRlZ3JhdGlvblRlbXBsYXRlVHlwZSk7XG5cbiAgICAvLyBSZWdpc3RlciBzZXJ2ZXIgc2lkZSBBUElzXG4gICAgc2V0dXBSb3V0ZXMoeyByb3V0ZXIsIGNsaWVudDogb3BlblNlYXJjaE9ic2VydmFiaWxpdHlDbGllbnQgfSk7XG5cbiAgICBjb3JlLnNhdmVkT2JqZWN0cy5yZWdpc3RlclR5cGUodmlzdWFsaXphdGlvblNhdmVkT2JqZWN0KTtcbiAgICBjb3JlLnNhdmVkT2JqZWN0cy5yZWdpc3RlclR5cGUoc2VhcmNoU2F2ZWRPYmplY3QpO1xuICAgIGNvcmUuY2FwYWJpbGl0aWVzLnJlZ2lzdGVyUHJvdmlkZXIoKCkgPT4gKHtcbiAgICAgIG9ic2VydmFiaWxpdHk6IHtcbiAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgIH0sXG4gICAgfSkpO1xuXG4gICAgYXNzaXN0YW50RGFzaGJvYXJkcz8ucmVnaXN0ZXJNZXNzYWdlUGFyc2VyKFBQTFBhcnNlcnMpO1xuXG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgcHVibGljIHN0YXJ0KF9jb3JlOiBDb3JlU3RhcnQpIHtcbiAgICB0aGlzLmxvZ2dlci5kZWJ1ZygnT2JzZXJ2YWJpbGl0eTogU3RhcnRlZCcpO1xuICAgIHJldHVybiB7fTtcbiAgfVxuXG4gIHB1YmxpYyBzdG9wKCkge31cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBZUEsSUFBQUEsZ0NBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE1BQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLDJCQUFBLEdBQUFILE9BQUE7QUFLQSxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBa0QsU0FBQUssZ0JBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxLQUFBLElBQUFELEdBQUEsR0FBQUUsY0FBQSxDQUFBRixHQUFBLE9BQUFBLEdBQUEsSUFBQUQsR0FBQSxJQUFBSSxNQUFBLENBQUFDLGNBQUEsQ0FBQUwsR0FBQSxFQUFBQyxHQUFBLElBQUFDLEtBQUEsRUFBQUEsS0FBQSxFQUFBSSxVQUFBLFFBQUFDLFlBQUEsUUFBQUMsUUFBQSxvQkFBQVIsR0FBQSxDQUFBQyxHQUFBLElBQUFDLEtBQUEsV0FBQUYsR0FBQTtBQUFBLFNBQUFHLGVBQUFNLEdBQUEsUUFBQVIsR0FBQSxHQUFBUyxZQUFBLENBQUFELEdBQUEsMkJBQUFSLEdBQUEsZ0JBQUFBLEdBQUEsR0FBQVUsTUFBQSxDQUFBVixHQUFBO0FBQUEsU0FBQVMsYUFBQUUsS0FBQSxFQUFBQyxJQUFBLGVBQUFELEtBQUEsaUJBQUFBLEtBQUEsa0JBQUFBLEtBQUEsTUFBQUUsSUFBQSxHQUFBRixLQUFBLENBQUFHLE1BQUEsQ0FBQUMsV0FBQSxPQUFBRixJQUFBLEtBQUFHLFNBQUEsUUFBQUMsR0FBQSxHQUFBSixJQUFBLENBQUFLLElBQUEsQ0FBQVAsS0FBQSxFQUFBQyxJQUFBLDJCQUFBSyxHQUFBLHNCQUFBQSxHQUFBLFlBQUFFLFNBQUEsNERBQUFQLElBQUEsZ0JBQUFGLE1BQUEsR0FBQVUsTUFBQSxFQUFBVCxLQUFBLEtBdkJsRDtBQUNBO0FBQ0E7QUFDQTtBQXNCTyxNQUFNVSxtQkFBbUIsQ0FDd0M7RUFHdEVDLFdBQVdBLENBQWtCQyxrQkFBNEMsRUFBRTtJQUFBLEtBQTlDQSxrQkFBNEMsR0FBNUNBLGtCQUE0QztJQUFBekIsZUFBQTtJQUN2RSxJQUFJLENBQUMwQixNQUFNLEdBQUdELGtCQUFrQixDQUFDQyxNQUFNLENBQUNDLEdBQUcsQ0FBQyxDQUFDO0VBQy9DO0VBRUEsTUFBYUMsS0FBS0EsQ0FBQ0MsSUFBZSxFQUFFQyxJQUFvRCxFQUFFO0lBQ3hGLE1BQU07TUFBRUM7SUFBb0IsQ0FBQyxHQUFHRCxJQUFJO0lBQ3BDLElBQUksQ0FBQ0osTUFBTSxDQUFDTSxLQUFLLENBQUMsc0JBQXNCLENBQUM7SUFDekMsTUFBTUMsTUFBTSxHQUFHSixJQUFJLENBQUNLLElBQUksQ0FBQ0MsWUFBWSxDQUFDLENBQUM7SUFDdkMsTUFBTUMsNkJBQW1ELEdBQUdQLElBQUksQ0FBQ1EsVUFBVSxDQUFDQyxNQUFNLENBQUNDLFlBQVksQ0FDN0YsMEJBQTBCLEVBQzFCO01BQ0VDLE9BQU8sRUFBRSxDQUFDQyxxQkFBUyxFQUFFQyw4REFBNkI7SUFDcEQsQ0FDRixDQUFDOztJQUVEO0lBQ0FiLElBQUksQ0FBQ0ssSUFBSSxDQUFDUywyQkFBMkIsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDQyxRQUFRLEVBQUVDLFFBQVEsS0FBSztNQUNwRixPQUFPO1FBQ0xuQixNQUFNLEVBQUUsSUFBSSxDQUFDQSxNQUFNO1FBQ25Cb0IsbUJBQW1CLEVBQUVWO01BQ3ZCLENBQUM7SUFDSCxDQUFDLENBQUM7SUFFRixNQUFNVyxZQUE4QixHQUFHO01BQ3JDQyxJQUFJLEVBQUUscUJBQXFCO01BQzNCQyxNQUFNLEVBQUUsS0FBSztNQUNiQyxhQUFhLEVBQUUsUUFBUTtNQUN2QkMsUUFBUSxFQUFFO1FBQ1JDLE9BQU8sRUFBRSxLQUFLO1FBQ2RDLFVBQVUsRUFBRTtVQUNWQyxLQUFLLEVBQUU7WUFDTEMsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEQyxXQUFXLEVBQUU7WUFDWEQsSUFBSSxFQUFFO1VBQ1I7UUFDRjtNQUNGLENBQUM7TUFDREUsVUFBVSxFQUFFO1FBQ1ZDLHVCQUF1QixFQUFFLElBQUk7UUFDN0JDLFdBQVdBLENBQUEsRUFBRztVQUNaLE9BQU87WUFDTEMsSUFBSSxFQUFHLHdDQUF1QztZQUM5Q0Msa0JBQWtCLEVBQUU7VUFDdEIsQ0FBQztRQUNILENBQUM7UUFDREMsUUFBUUEsQ0FBQzdELEdBQUcsRUFBRTtVQUNaLE9BQVEsMkJBQTBCQSxHQUFHLENBQUM4RCxFQUFHLEdBQUU7UUFDN0M7TUFDRixDQUFDO01BQ0RDLFVBQVUsRUFBRTtRQUNWLE9BQU8sRUFBR0MsR0FBRyxLQUFNO1VBQUUsR0FBR0EsR0FBRztVQUFFVCxXQUFXLEVBQUU7UUFBRyxDQUFDLENBQUM7UUFDL0MsT0FBTyxFQUFHUyxHQUFHLEtBQU07VUFBRSxHQUFHQSxHQUFHO1VBQUVULFdBQVcsRUFBRTtRQUF3QixDQUFDLENBQUM7UUFDcEUsT0FBTyxFQUFHUyxHQUFHLEtBQU07VUFDakIsR0FBR0EsR0FBRztVQUNOQyxXQUFXLEVBQUVDLFFBQVEsQ0FBRUYsR0FBRyxDQUE4QkMsV0FBVyxJQUFJLEdBQUcsRUFBRSxFQUFFO1FBQ2hGLENBQUM7TUFDSDtJQUNGLENBQUM7SUFFRCxNQUFNRSx1QkFBeUMsR0FBRztNQUNoRHBCLElBQUksRUFBRSxzQkFBc0I7TUFDNUJDLE1BQU0sRUFBRSxLQUFLO01BQ2JDLGFBQWEsRUFBRSxRQUFRO01BQ3ZCTyxVQUFVLEVBQUU7UUFDVkMsdUJBQXVCLEVBQUUsSUFBSTtRQUM3QkMsV0FBV0EsQ0FBQzFELEdBQXFDLEVBQUU7VUFDakQsT0FBTztZQUNMMkQsSUFBSSxFQUFHLGdDQUErQjNELEdBQUcsQ0FBQzhELEVBQUcsRUFBQztZQUM5Q0Ysa0JBQWtCLEVBQUU7VUFDdEIsQ0FBQztRQUNILENBQUM7UUFDREMsUUFBUUEsQ0FBQzdELEdBQXFDLEVBQUU7VUFDOUMsT0FBT0EsR0FBRyxDQUFDb0UsVUFBVSxDQUFDckIsSUFBSTtRQUM1QjtNQUNGLENBQUM7TUFDREcsUUFBUSxFQUFFO1FBQ1JDLE9BQU8sRUFBRSxLQUFLO1FBQ2RDLFVBQVUsRUFBRTtVQUNWTCxJQUFJLEVBQUU7WUFDSk8sSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEZSxZQUFZLEVBQUU7WUFDWmYsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEZ0IsVUFBVSxFQUFFO1lBQ1ZoQixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RpQixZQUFZLEVBQUU7WUFDWmpCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRGtCLE1BQU0sRUFBRTtZQUNObEIsSUFBSSxFQUFFO1VBQ1I7UUFDRjtNQUNGO0lBQ0YsQ0FBQztJQUVELE1BQU1tQix1QkFBeUMsR0FBRztNQUNoRDFCLElBQUksRUFBRSxzQkFBc0I7TUFDNUJDLE1BQU0sRUFBRSxLQUFLO01BQ2JDLGFBQWEsRUFBRSxRQUFRO01BQ3ZCTyxVQUFVLEVBQUU7UUFDVkMsdUJBQXVCLEVBQUUsSUFBSTtRQUM3QkMsV0FBV0EsQ0FBQzFELEdBQXVDLEVBQUU7VUFDbkQsT0FBTztZQUNMMkQsSUFBSSxFQUFHLGdDQUErQjNELEdBQUcsQ0FBQ29FLFVBQVUsQ0FBQ3JCLElBQUssRUFBQztZQUMzRGEsa0JBQWtCLEVBQUU7VUFDdEIsQ0FBQztRQUNILENBQUM7UUFDREMsUUFBUUEsQ0FBQzdELEdBQXVDLEVBQUU7VUFBQSxJQUFBMEUscUJBQUE7VUFDaEQsUUFBQUEscUJBQUEsR0FBTzFFLEdBQUcsQ0FBQ29FLFVBQVUsQ0FBQ08sV0FBVyxjQUFBRCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJMUUsR0FBRyxDQUFDb0UsVUFBVSxDQUFDckIsSUFBSTtRQUMxRDtNQUNGLENBQUM7TUFDREcsUUFBUSxFQUFFO1FBQ1JDLE9BQU8sRUFBRSxLQUFLO1FBQ2RDLFVBQVUsRUFBRTtVQUNWTCxJQUFJLEVBQUU7WUFDSk8sSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEc0IsT0FBTyxFQUFFO1lBQ1B0QixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RxQixXQUFXLEVBQUU7WUFDWHJCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRHVCLE9BQU8sRUFBRTtZQUNQdkIsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEQSxJQUFJLEVBQUU7WUFDSkEsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEd0IsTUFBTSxFQUFFO1lBQ054QixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0R5QixNQUFNLEVBQUU7WUFDTnpCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDREMsV0FBVyxFQUFFO1lBQ1hELElBQUksRUFBRTtVQUNSLENBQUM7VUFDRDBCLFNBQVMsRUFBRTtZQUNUMUIsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEMkIsT0FBTyxFQUFFO1lBQ1AzQixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0Q0QixVQUFVLEVBQUU7WUFDVjVCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRGtCLE1BQU0sRUFBRTtZQUNObEIsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNENkIsVUFBVSxFQUFFO1lBQ1Y3QixJQUFJLEVBQUU7VUFDUjtRQUNGO01BQ0Y7SUFDRixDQUFDO0lBRUQxQixJQUFJLENBQUN3RCxZQUFZLENBQUNDLFlBQVksQ0FBQ3ZDLFlBQVksQ0FBQztJQUM1Q2xCLElBQUksQ0FBQ3dELFlBQVksQ0FBQ0MsWUFBWSxDQUFDbEIsdUJBQXVCLENBQUM7SUFDdkR2QyxJQUFJLENBQUN3RCxZQUFZLENBQUNDLFlBQVksQ0FBQ1osdUJBQXVCLENBQUM7O0lBRXZEO0lBQ0EsSUFBQWEsa0JBQVcsRUFBQztNQUFFdEQsTUFBTTtNQUFFdUQsTUFBTSxFQUFFcEQ7SUFBOEIsQ0FBQyxDQUFDO0lBRTlEUCxJQUFJLENBQUN3RCxZQUFZLENBQUNDLFlBQVksQ0FBQ0csb0RBQXdCLENBQUM7SUFDeEQ1RCxJQUFJLENBQUN3RCxZQUFZLENBQUNDLFlBQVksQ0FBQ0ksNkNBQWlCLENBQUM7SUFDakQ3RCxJQUFJLENBQUM4RCxZQUFZLENBQUNDLGdCQUFnQixDQUFDLE9BQU87TUFDeENDLGFBQWEsRUFBRTtRQUNiQyxJQUFJLEVBQUU7TUFDUjtJQUNGLENBQUMsQ0FBQyxDQUFDO0lBRUgvRCxtQkFBbUIsYUFBbkJBLG1CQUFtQixlQUFuQkEsbUJBQW1CLENBQUVnRSxxQkFBcUIsQ0FBQ0Msc0JBQVUsQ0FBQztJQUV0RCxPQUFPLENBQUMsQ0FBQztFQUNYO0VBRU9DLEtBQUtBLENBQUNDLEtBQWdCLEVBQUU7SUFDN0IsSUFBSSxDQUFDeEUsTUFBTSxDQUFDTSxLQUFLLENBQUMsd0JBQXdCLENBQUM7SUFDM0MsT0FBTyxDQUFDLENBQUM7RUFDWDtFQUVPbUUsSUFBSUEsQ0FBQSxFQUFHLENBQUM7QUFDakI7QUFBQ0MsT0FBQSxDQUFBN0UsbUJBQUEsR0FBQUEsbUJBQUEifQ==