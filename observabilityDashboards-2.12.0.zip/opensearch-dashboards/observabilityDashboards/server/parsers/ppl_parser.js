"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PPLParsers = void 0;
/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

const extractPPLQueries = content => {
  return Array.from(content.matchAll(/(^|[\n\r]|:)\s*(source\s*=\s*.+)/gi)).map(match => match[2]);
};
const PPLParsers = exports.PPLParsers = {
  id: 'ppl_visualization_message',
  async parserProvider(interaction) {
    var _interaction$addition;
    const ppls = ((_interaction$addition = interaction.additional_info) === null || _interaction$addition === void 0 || (_interaction$addition = _interaction$addition["PPLTool.output"]) === null || _interaction$addition === void 0 ? void 0 : _interaction$addition.flatMap(item => {
      let ppl = "";
      try {
        const outputResp = JSON.parse(item);
        ppl = outputResp.ppl;
      } catch (e) {
        ppl = item;
      }
      return extractPPLQueries(ppl);
    })) || [];
    if (!ppls.length) return [];
    const statsPPLs = ppls.filter(ppl => /\|\s*stats\s+[^|]+\sby\s/i.test(ppl));
    if (!statsPPLs.length) {
      return [];
    }
    return statsPPLs.map(query => {
      const finalQuery = query.replace(/`/g, '') // workaround for https://github.com/opensearch-project/dashboards-observability/issues/509, https://github.com/opensearch-project/dashboards-observability/issues/557
      .replace(/\bSPAN\(/g, 'span('); // workaround for https://github.com/opensearch-project/dashboards-observability/issues/759
      return {
        type: 'output',
        content: finalQuery,
        contentType: 'ppl_visualization',
        suggestedActions: [{
          message: 'View details',
          actionType: 'view_ppl_visualization',
          metadata: {
            query: finalQuery,
            question: interaction.input
          }
        }]
      };
    });
  }
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHRyYWN0UFBMUXVlcmllcyIsImNvbnRlbnQiLCJBcnJheSIsImZyb20iLCJtYXRjaEFsbCIsIm1hcCIsIm1hdGNoIiwiUFBMUGFyc2VycyIsImV4cG9ydHMiLCJpZCIsInBhcnNlclByb3ZpZGVyIiwiaW50ZXJhY3Rpb24iLCJfaW50ZXJhY3Rpb24kYWRkaXRpb24iLCJwcGxzIiwiYWRkaXRpb25hbF9pbmZvIiwiZmxhdE1hcCIsIml0ZW0iLCJwcGwiLCJvdXRwdXRSZXNwIiwiSlNPTiIsInBhcnNlIiwiZSIsImxlbmd0aCIsInN0YXRzUFBMcyIsImZpbHRlciIsInRlc3QiLCJxdWVyeSIsImZpbmFsUXVlcnkiLCJyZXBsYWNlIiwidHlwZSIsImNvbnRlbnRUeXBlIiwic3VnZ2VzdGVkQWN0aW9ucyIsIm1lc3NhZ2UiLCJhY3Rpb25UeXBlIiwibWV0YWRhdGEiLCJxdWVzdGlvbiIsImlucHV0Il0sInNvdXJjZXMiOlsicHBsX3BhcnNlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7IE1lc3NhZ2VQYXJzZXIgfSBmcm9tICcuLi90eXBlcyc7XG5cbmNvbnN0IGV4dHJhY3RQUExRdWVyaWVzID0gKGNvbnRlbnQ6IHN0cmluZykgPT4ge1xuICAgIHJldHVybiBBcnJheS5mcm9tKGNvbnRlbnQubWF0Y2hBbGwoLyhefFtcXG5cXHJdfDopXFxzKihzb3VyY2VcXHMqPVxccyouKykvZ2kpKS5tYXAoXG4gICAgICAgIChtYXRjaCkgPT4gbWF0Y2hbMl1cbiAgICApO1xufTtcblxuZXhwb3J0IGNvbnN0IFBQTFBhcnNlcnM6IE1lc3NhZ2VQYXJzZXIgPSB7XG4gICAgaWQ6ICdwcGxfdmlzdWFsaXphdGlvbl9tZXNzYWdlJyxcbiAgICBhc3luYyBwYXJzZXJQcm92aWRlcihpbnRlcmFjdGlvbikge1xuICAgICAgICBjb25zdCBwcGxzOiBzdHJpbmdbXSA9IChpbnRlcmFjdGlvbi5hZGRpdGlvbmFsX2luZm8/LltcIlBQTFRvb2wub3V0cHV0XCJdIGFzIHN0cmluZ1tdIHwgbnVsbCk/LmZsYXRNYXAoKGl0ZW06IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgbGV0IHBwbDogc3RyaW5nID0gXCJcIlxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBvdXRwdXRSZXNwID0gSlNPTi5wYXJzZShpdGVtKTtcbiAgICAgICAgICAgICAgICBwcGwgPSBvdXRwdXRSZXNwLnBwbDtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBwcGwgPSBpdGVtO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gZXh0cmFjdFBQTFF1ZXJpZXMocHBsKTtcbiAgICAgICAgfSkgfHwgW107XG5cbiAgICAgICAgaWYgKCFwcGxzLmxlbmd0aCkgcmV0dXJuIFtdO1xuXG4gICAgICAgIGNvbnN0IHN0YXRzUFBMcyA9IHBwbHMuZmlsdGVyKChwcGwpID0+IC9cXHxcXHMqc3RhdHNcXHMrW158XStcXHNieVxccy9pLnRlc3QocHBsKSk7XG4gICAgICAgIGlmICghc3RhdHNQUExzLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHN0YXRzUFBMcy5tYXAoKHF1ZXJ5KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmaW5hbFF1ZXJ5ID0gcXVlcnlcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgvYC9nLCAnJykgIC8vIHdvcmthcm91bmQgZm9yIGh0dHBzOi8vZ2l0aHViLmNvbS9vcGVuc2VhcmNoLXByb2plY3QvZGFzaGJvYXJkcy1vYnNlcnZhYmlsaXR5L2lzc3Vlcy81MDksIGh0dHBzOi8vZ2l0aHViLmNvbS9vcGVuc2VhcmNoLXByb2plY3QvZGFzaGJvYXJkcy1vYnNlcnZhYmlsaXR5L2lzc3Vlcy81NTdcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxiU1BBTlxcKC9nLCAnc3BhbignKTsgIC8vIHdvcmthcm91bmQgZm9yIGh0dHBzOi8vZ2l0aHViLmNvbS9vcGVuc2VhcmNoLXByb2plY3QvZGFzaGJvYXJkcy1vYnNlcnZhYmlsaXR5L2lzc3Vlcy83NTlcbiAgICAgICAgICAgIHJldHVybiAoe1xuICAgICAgICAgICAgICAgIHR5cGU6ICdvdXRwdXQnLFxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGZpbmFsUXVlcnksXG4gICAgICAgICAgICAgICAgY29udGVudFR5cGU6ICdwcGxfdmlzdWFsaXphdGlvbicsXG4gICAgICAgICAgICAgICAgc3VnZ2VzdGVkQWN0aW9uczogW1xuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnVmlldyBkZXRhaWxzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvblR5cGU6ICd2aWV3X3BwbF92aXN1YWxpemF0aW9uJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1ldGFkYXRhOiB7IHF1ZXJ5OiBmaW5hbFF1ZXJ5LCBxdWVzdGlvbjogaW50ZXJhY3Rpb24uaW5wdXQgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0sXG59O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQSxNQUFNQSxpQkFBaUIsR0FBSUMsT0FBZSxJQUFLO0VBQzNDLE9BQU9DLEtBQUssQ0FBQ0MsSUFBSSxDQUFDRixPQUFPLENBQUNHLFFBQVEsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FDeEVDLEtBQUssSUFBS0EsS0FBSyxDQUFDLENBQUMsQ0FDdEIsQ0FBQztBQUNMLENBQUM7QUFFTSxNQUFNQyxVQUF5QixHQUFBQyxPQUFBLENBQUFELFVBQUEsR0FBRztFQUNyQ0UsRUFBRSxFQUFFLDJCQUEyQjtFQUMvQixNQUFNQyxjQUFjQSxDQUFDQyxXQUFXLEVBQUU7SUFBQSxJQUFBQyxxQkFBQTtJQUM5QixNQUFNQyxJQUFjLEdBQUcsRUFBQUQscUJBQUEsR0FBQ0QsV0FBVyxDQUFDRyxlQUFlLGNBQUFGLHFCQUFBLGdCQUFBQSxxQkFBQSxHQUEzQkEscUJBQUEsQ0FBOEIsZ0JBQWdCLENBQUMsY0FBQUEscUJBQUEsdUJBQWhEQSxxQkFBQSxDQUFzRUcsT0FBTyxDQUFFQyxJQUFZLElBQUs7TUFDbkgsSUFBSUMsR0FBVyxHQUFHLEVBQUU7TUFDcEIsSUFBSTtRQUNBLE1BQU1DLFVBQVUsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUNKLElBQUksQ0FBQztRQUNuQ0MsR0FBRyxHQUFHQyxVQUFVLENBQUNELEdBQUc7TUFDeEIsQ0FBQyxDQUFDLE9BQU9JLENBQUMsRUFBRTtRQUNSSixHQUFHLEdBQUdELElBQUk7TUFDZDtNQUVBLE9BQU9oQixpQkFBaUIsQ0FBQ2lCLEdBQUcsQ0FBQztJQUNqQyxDQUFDLENBQUMsS0FBSSxFQUFFO0lBRVIsSUFBSSxDQUFDSixJQUFJLENBQUNTLE1BQU0sRUFBRSxPQUFPLEVBQUU7SUFFM0IsTUFBTUMsU0FBUyxHQUFHVixJQUFJLENBQUNXLE1BQU0sQ0FBRVAsR0FBRyxJQUFLLDJCQUEyQixDQUFDUSxJQUFJLENBQUNSLEdBQUcsQ0FBQyxDQUFDO0lBQzdFLElBQUksQ0FBQ00sU0FBUyxDQUFDRCxNQUFNLEVBQUU7TUFDbkIsT0FBTyxFQUFFO0lBQ2I7SUFFQSxPQUFPQyxTQUFTLENBQUNsQixHQUFHLENBQUVxQixLQUFLLElBQUs7TUFDNUIsTUFBTUMsVUFBVSxHQUFHRCxLQUFLLENBQ25CRSxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFFO01BQUEsQ0FDbkJBLE9BQU8sQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBRTtNQUNyQyxPQUFRO1FBQ0pDLElBQUksRUFBRSxRQUFRO1FBQ2Q1QixPQUFPLEVBQUUwQixVQUFVO1FBQ25CRyxXQUFXLEVBQUUsbUJBQW1CO1FBQ2hDQyxnQkFBZ0IsRUFBRSxDQUNkO1VBQ0lDLE9BQU8sRUFBRSxjQUFjO1VBQ3ZCQyxVQUFVLEVBQUUsd0JBQXdCO1VBQ3BDQyxRQUFRLEVBQUU7WUFBRVIsS0FBSyxFQUFFQyxVQUFVO1lBQUVRLFFBQVEsRUFBRXhCLFdBQVcsQ0FBQ3lCO1VBQU07UUFDL0QsQ0FBQztNQUVULENBQUM7SUFDTCxDQUFDLENBQUM7RUFDTjtBQUNKLENBQUMifQ==