"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.JsonCatalogDataAdaptor = void 0;
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * A CatalogDataAdaptor that reads from a provided list of JSON objects.
 * Used to read Integration information when the user uploads their own catalog.
 */
class JsonCatalogDataAdaptor {
  /**
   * Creates a new FileSystemCatalogDataAdaptor instance.
   *
   * @param directory The base directory from which to read files. This is not sanitized.
   */
  constructor(integrationsList) {
    _defineProperty(this, "isConfigLocalized", true);
    _defineProperty(this, "integrationsList", void 0);
    this.integrationsList = integrationsList;
  }
  async findIntegrationVersions(dirname) {
    const versions = [];
    for (const integration of this.integrationsList) {
      if (dirname && integration.name !== dirname) {
        continue;
      }
      versions.push(integration.version);
    }
    return {
      ok: true,
      value: versions
    };
  }
  async readFile(filename, type) {
    if (type !== undefined) {
      return {
        ok: false,
        error: new Error('JSON adaptor does not support subtypes (isConfigLocalized: true)')
      };
    }
    const name = filename.split('-')[0];
    const version = filename.match(/\d+(\.\d+)*/);
    for (const integ of this.integrationsList) {
      if (integ.name === name && integ.version === (version === null || version === void 0 ? void 0 : version[0])) {
        return {
          ok: true,
          value: integ
        };
      }
    }
    return {
      ok: false,
      error: new Error('Config file not found: ' + filename)
    };
  }
  async readFileRaw(_filename, _type) {
    return {
      ok: false,
      error: new Error('JSON adaptor does not support raw files (isConfigLocalized: true)')
    };
  }
  async findIntegrations(dirname = '.') {
    if (dirname !== '.') {
      return {
        ok: false,
        error: new Error('Finding integrations for custom dirs not supported for JSONreader')
      };
    }
    const result = new Set([]);
    for (const integration of this.integrationsList) {
      result.add(integration.name);
    }
    return {
      ok: true,
      value: [...result]
    };
  }
  async getDirectoryType(dirname) {
    // First, filter list by dirname if available
    const integrationsList = dirname ? this.integrationsList.filter(i => i.name === dirname) : this.integrationsList;
    if (integrationsList.length === 0) {
      return 'unknown';
    }
    // The list is an integration iff all of its names match
    for (let i = 0; i < integrationsList.length - 1; i++) {
      if (integrationsList[i].name !== integrationsList[i + 1].name) {
        return 'repository';
      }
    }
    return 'integration';
  }
  join(filename) {
    // In other adaptors, joining moves from directories to integrations.
    // Since for JSON catalogs we use a flat structure, we just filter.
    return new JsonCatalogDataAdaptor(this.integrationsList.filter(i => i.name === filename));
  }
}
exports.JsonCatalogDataAdaptor = JsonCatalogDataAdaptor;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJKc29uQ2F0YWxvZ0RhdGFBZGFwdG9yIiwiY29uc3RydWN0b3IiLCJpbnRlZ3JhdGlvbnNMaXN0IiwiX2RlZmluZVByb3BlcnR5IiwiZmluZEludGVncmF0aW9uVmVyc2lvbnMiLCJkaXJuYW1lIiwidmVyc2lvbnMiLCJpbnRlZ3JhdGlvbiIsIm5hbWUiLCJwdXNoIiwidmVyc2lvbiIsIm9rIiwidmFsdWUiLCJyZWFkRmlsZSIsImZpbGVuYW1lIiwidHlwZSIsInVuZGVmaW5lZCIsImVycm9yIiwiRXJyb3IiLCJzcGxpdCIsIm1hdGNoIiwiaW50ZWciLCJyZWFkRmlsZVJhdyIsIl9maWxlbmFtZSIsIl90eXBlIiwiZmluZEludGVncmF0aW9ucyIsInJlc3VsdCIsIlNldCIsImFkZCIsImdldERpcmVjdG9yeVR5cGUiLCJmaWx0ZXIiLCJpIiwibGVuZ3RoIiwiam9pbiIsImV4cG9ydHMiXSwic291cmNlcyI6WyJqc29uX2RhdGFfYWRhcHRvci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7IENhdGFsb2dEYXRhQWRhcHRvciwgSW50ZWdyYXRpb25QYXJ0IH0gZnJvbSAnLi9jYXRhbG9nX2RhdGFfYWRhcHRvcic7XG5cbi8qKlxuICogQSBDYXRhbG9nRGF0YUFkYXB0b3IgdGhhdCByZWFkcyBmcm9tIGEgcHJvdmlkZWQgbGlzdCBvZiBKU09OIG9iamVjdHMuXG4gKiBVc2VkIHRvIHJlYWQgSW50ZWdyYXRpb24gaW5mb3JtYXRpb24gd2hlbiB0aGUgdXNlciB1cGxvYWRzIHRoZWlyIG93biBjYXRhbG9nLlxuICovXG5leHBvcnQgY2xhc3MgSnNvbkNhdGFsb2dEYXRhQWRhcHRvciBpbXBsZW1lbnRzIENhdGFsb2dEYXRhQWRhcHRvciB7XG4gIGlzQ29uZmlnTG9jYWxpemVkID0gdHJ1ZTtcbiAgaW50ZWdyYXRpb25zTGlzdDogU2VyaWFsaXplZEludGVncmF0aW9uW107XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgRmlsZVN5c3RlbUNhdGFsb2dEYXRhQWRhcHRvciBpbnN0YW5jZS5cbiAgICpcbiAgICogQHBhcmFtIGRpcmVjdG9yeSBUaGUgYmFzZSBkaXJlY3RvcnkgZnJvbSB3aGljaCB0byByZWFkIGZpbGVzLiBUaGlzIGlzIG5vdCBzYW5pdGl6ZWQuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihpbnRlZ3JhdGlvbnNMaXN0OiBTZXJpYWxpemVkSW50ZWdyYXRpb25bXSkge1xuICAgIHRoaXMuaW50ZWdyYXRpb25zTGlzdCA9IGludGVncmF0aW9uc0xpc3Q7XG4gIH1cblxuICBhc3luYyBmaW5kSW50ZWdyYXRpb25WZXJzaW9ucyhkaXJuYW1lPzogc3RyaW5nIHwgdW5kZWZpbmVkKTogUHJvbWlzZTxSZXN1bHQ8c3RyaW5nW10sIEVycm9yPj4ge1xuICAgIGNvbnN0IHZlcnNpb25zOiBzdHJpbmdbXSA9IFtdO1xuICAgIGZvciAoY29uc3QgaW50ZWdyYXRpb24gb2YgdGhpcy5pbnRlZ3JhdGlvbnNMaXN0KSB7XG4gICAgICBpZiAoZGlybmFtZSAmJiBpbnRlZ3JhdGlvbi5uYW1lICE9PSBkaXJuYW1lKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgdmVyc2lvbnMucHVzaChpbnRlZ3JhdGlvbi52ZXJzaW9uKTtcbiAgICB9XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHZhbHVlOiB2ZXJzaW9ucyB9O1xuICB9XG5cbiAgYXN5bmMgcmVhZEZpbGUoZmlsZW5hbWU6IHN0cmluZywgdHlwZT86IEludGVncmF0aW9uUGFydCk6IFByb21pc2U8UmVzdWx0PG9iamVjdFtdIHwgb2JqZWN0Pj4ge1xuICAgIGlmICh0eXBlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IG5ldyBFcnJvcignSlNPTiBhZGFwdG9yIGRvZXMgbm90IHN1cHBvcnQgc3VidHlwZXMgKGlzQ29uZmlnTG9jYWxpemVkOiB0cnVlKScpLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBjb25zdCBuYW1lID0gZmlsZW5hbWUuc3BsaXQoJy0nKVswXTtcbiAgICBjb25zdCB2ZXJzaW9uID0gZmlsZW5hbWUubWF0Y2goL1xcZCsoXFwuXFxkKykqLyk7XG4gICAgZm9yIChjb25zdCBpbnRlZyBvZiB0aGlzLmludGVncmF0aW9uc0xpc3QpIHtcbiAgICAgIGlmIChpbnRlZy5uYW1lID09PSBuYW1lICYmIGludGVnLnZlcnNpb24gPT09IHZlcnNpb24/LlswXSkge1xuICAgICAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IGludGVnIH07XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6IG5ldyBFcnJvcignQ29uZmlnIGZpbGUgbm90IGZvdW5kOiAnICsgZmlsZW5hbWUpIH07XG4gIH1cblxuICBhc3luYyByZWFkRmlsZVJhdyhfZmlsZW5hbWU6IHN0cmluZywgX3R5cGU/OiBJbnRlZ3JhdGlvblBhcnQpOiBQcm9taXNlPFJlc3VsdDxCdWZmZXI+PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG9rOiBmYWxzZSxcbiAgICAgIGVycm9yOiBuZXcgRXJyb3IoJ0pTT04gYWRhcHRvciBkb2VzIG5vdCBzdXBwb3J0IHJhdyBmaWxlcyAoaXNDb25maWdMb2NhbGl6ZWQ6IHRydWUpJyksXG4gICAgfTtcbiAgfVxuXG4gIGFzeW5jIGZpbmRJbnRlZ3JhdGlvbnMoZGlybmFtZTogc3RyaW5nID0gJy4nKTogUHJvbWlzZTxSZXN1bHQ8c3RyaW5nW10+PiB7XG4gICAgaWYgKGRpcm5hbWUgIT09ICcuJykge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICBlcnJvcjogbmV3IEVycm9yKCdGaW5kaW5nIGludGVncmF0aW9ucyBmb3IgY3VzdG9tIGRpcnMgbm90IHN1cHBvcnRlZCBmb3IgSlNPTnJlYWRlcicpLFxuICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0OiBTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW10pO1xuICAgIGZvciAoY29uc3QgaW50ZWdyYXRpb24gb2YgdGhpcy5pbnRlZ3JhdGlvbnNMaXN0KSB7XG4gICAgICByZXN1bHQuYWRkKGludGVncmF0aW9uLm5hbWUpO1xuICAgIH1cbiAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IFsuLi5yZXN1bHRdIH07XG4gIH1cblxuICBhc3luYyBnZXREaXJlY3RvcnlUeXBlKGRpcm5hbWU/OiBzdHJpbmcpOiBQcm9taXNlPCdpbnRlZ3JhdGlvbicgfCAncmVwb3NpdG9yeScgfCAndW5rbm93bic+IHtcbiAgICAvLyBGaXJzdCwgZmlsdGVyIGxpc3QgYnkgZGlybmFtZSBpZiBhdmFpbGFibGVcbiAgICBjb25zdCBpbnRlZ3JhdGlvbnNMaXN0ID0gZGlybmFtZVxuICAgICAgPyB0aGlzLmludGVncmF0aW9uc0xpc3QuZmlsdGVyKChpKSA9PiBpLm5hbWUgPT09IGRpcm5hbWUpXG4gICAgICA6IHRoaXMuaW50ZWdyYXRpb25zTGlzdDtcbiAgICBpZiAoaW50ZWdyYXRpb25zTGlzdC5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiAndW5rbm93bic7XG4gICAgfVxuICAgIC8vIFRoZSBsaXN0IGlzIGFuIGludGVncmF0aW9uIGlmZiBhbGwgb2YgaXRzIG5hbWVzIG1hdGNoXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnRlZ3JhdGlvbnNMaXN0Lmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgaWYgKGludGVncmF0aW9uc0xpc3RbaV0ubmFtZSAhPT0gaW50ZWdyYXRpb25zTGlzdFtpICsgMV0ubmFtZSkge1xuICAgICAgICByZXR1cm4gJ3JlcG9zaXRvcnknO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gJ2ludGVncmF0aW9uJztcbiAgfVxuXG4gIGpvaW4oZmlsZW5hbWU6IHN0cmluZyk6IEpzb25DYXRhbG9nRGF0YUFkYXB0b3Ige1xuICAgIC8vIEluIG90aGVyIGFkYXB0b3JzLCBqb2luaW5nIG1vdmVzIGZyb20gZGlyZWN0b3JpZXMgdG8gaW50ZWdyYXRpb25zLlxuICAgIC8vIFNpbmNlIGZvciBKU09OIGNhdGFsb2dzIHdlIHVzZSBhIGZsYXQgc3RydWN0dXJlLCB3ZSBqdXN0IGZpbHRlci5cbiAgICByZXR1cm4gbmV3IEpzb25DYXRhbG9nRGF0YUFkYXB0b3IodGhpcy5pbnRlZ3JhdGlvbnNMaXN0LmZpbHRlcigoaSkgPT4gaS5uYW1lID09PSBmaWxlbmFtZSkpO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBOztBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTUEsc0JBQXNCLENBQStCO0VBSWhFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDRUMsV0FBV0EsQ0FBQ0MsZ0JBQXlDLEVBQUU7SUFBQUMsZUFBQSw0QkFSbkMsSUFBSTtJQUFBQSxlQUFBO0lBU3RCLElBQUksQ0FBQ0QsZ0JBQWdCLEdBQUdBLGdCQUFnQjtFQUMxQztFQUVBLE1BQU1FLHVCQUF1QkEsQ0FBQ0MsT0FBNEIsRUFBb0M7SUFDNUYsTUFBTUMsUUFBa0IsR0FBRyxFQUFFO0lBQzdCLEtBQUssTUFBTUMsV0FBVyxJQUFJLElBQUksQ0FBQ0wsZ0JBQWdCLEVBQUU7TUFDL0MsSUFBSUcsT0FBTyxJQUFJRSxXQUFXLENBQUNDLElBQUksS0FBS0gsT0FBTyxFQUFFO1FBQzNDO01BQ0Y7TUFDQUMsUUFBUSxDQUFDRyxJQUFJLENBQUNGLFdBQVcsQ0FBQ0csT0FBTyxDQUFDO0lBQ3BDO0lBQ0EsT0FBTztNQUFFQyxFQUFFLEVBQUUsSUFBSTtNQUFFQyxLQUFLLEVBQUVOO0lBQVMsQ0FBQztFQUN0QztFQUVBLE1BQU1PLFFBQVFBLENBQUNDLFFBQWdCLEVBQUVDLElBQXNCLEVBQXNDO0lBQzNGLElBQUlBLElBQUksS0FBS0MsU0FBUyxFQUFFO01BQ3RCLE9BQU87UUFDTEwsRUFBRSxFQUFFLEtBQUs7UUFDVE0sS0FBSyxFQUFFLElBQUlDLEtBQUssQ0FBQyxrRUFBa0U7TUFDckYsQ0FBQztJQUNIO0lBRUEsTUFBTVYsSUFBSSxHQUFHTSxRQUFRLENBQUNLLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbkMsTUFBTVQsT0FBTyxHQUFHSSxRQUFRLENBQUNNLEtBQUssQ0FBQyxhQUFhLENBQUM7SUFDN0MsS0FBSyxNQUFNQyxLQUFLLElBQUksSUFBSSxDQUFDbkIsZ0JBQWdCLEVBQUU7TUFDekMsSUFBSW1CLEtBQUssQ0FBQ2IsSUFBSSxLQUFLQSxJQUFJLElBQUlhLEtBQUssQ0FBQ1gsT0FBTyxNQUFLQSxPQUFPLGFBQVBBLE9BQU8sdUJBQVBBLE9BQU8sQ0FBRyxDQUFDLENBQUMsR0FBRTtRQUN6RCxPQUFPO1VBQUVDLEVBQUUsRUFBRSxJQUFJO1VBQUVDLEtBQUssRUFBRVM7UUFBTSxDQUFDO01BQ25DO0lBQ0Y7SUFDQSxPQUFPO01BQUVWLEVBQUUsRUFBRSxLQUFLO01BQUVNLEtBQUssRUFBRSxJQUFJQyxLQUFLLENBQUMseUJBQXlCLEdBQUdKLFFBQVE7SUFBRSxDQUFDO0VBQzlFO0VBRUEsTUFBTVEsV0FBV0EsQ0FBQ0MsU0FBaUIsRUFBRUMsS0FBdUIsRUFBMkI7SUFDckYsT0FBTztNQUNMYixFQUFFLEVBQUUsS0FBSztNQUNUTSxLQUFLLEVBQUUsSUFBSUMsS0FBSyxDQUFDLG1FQUFtRTtJQUN0RixDQUFDO0VBQ0g7RUFFQSxNQUFNTyxnQkFBZ0JBLENBQUNwQixPQUFlLEdBQUcsR0FBRyxFQUE2QjtJQUN2RSxJQUFJQSxPQUFPLEtBQUssR0FBRyxFQUFFO01BQ25CLE9BQU87UUFDTE0sRUFBRSxFQUFFLEtBQUs7UUFDVE0sS0FBSyxFQUFFLElBQUlDLEtBQUssQ0FBQyxtRUFBbUU7TUFDdEYsQ0FBQztJQUNIO0lBQ0EsTUFBTVEsTUFBbUIsR0FBRyxJQUFJQyxHQUFHLENBQUMsRUFBRSxDQUFDO0lBQ3ZDLEtBQUssTUFBTXBCLFdBQVcsSUFBSSxJQUFJLENBQUNMLGdCQUFnQixFQUFFO01BQy9Dd0IsTUFBTSxDQUFDRSxHQUFHLENBQUNyQixXQUFXLENBQUNDLElBQUksQ0FBQztJQUM5QjtJQUNBLE9BQU87TUFBRUcsRUFBRSxFQUFFLElBQUk7TUFBRUMsS0FBSyxFQUFFLENBQUMsR0FBR2MsTUFBTTtJQUFFLENBQUM7RUFDekM7RUFFQSxNQUFNRyxnQkFBZ0JBLENBQUN4QixPQUFnQixFQUFxRDtJQUMxRjtJQUNBLE1BQU1ILGdCQUFnQixHQUFHRyxPQUFPLEdBQzVCLElBQUksQ0FBQ0gsZ0JBQWdCLENBQUM0QixNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDdkIsSUFBSSxLQUFLSCxPQUFPLENBQUMsR0FDdkQsSUFBSSxDQUFDSCxnQkFBZ0I7SUFDekIsSUFBSUEsZ0JBQWdCLENBQUM4QixNQUFNLEtBQUssQ0FBQyxFQUFFO01BQ2pDLE9BQU8sU0FBUztJQUNsQjtJQUNBO0lBQ0EsS0FBSyxJQUFJRCxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUc3QixnQkFBZ0IsQ0FBQzhCLE1BQU0sR0FBRyxDQUFDLEVBQUVELENBQUMsRUFBRSxFQUFFO01BQ3BELElBQUk3QixnQkFBZ0IsQ0FBQzZCLENBQUMsQ0FBQyxDQUFDdkIsSUFBSSxLQUFLTixnQkFBZ0IsQ0FBQzZCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQ3ZCLElBQUksRUFBRTtRQUM3RCxPQUFPLFlBQVk7TUFDckI7SUFDRjtJQUNBLE9BQU8sYUFBYTtFQUN0QjtFQUVBeUIsSUFBSUEsQ0FBQ25CLFFBQWdCLEVBQTBCO0lBQzdDO0lBQ0E7SUFDQSxPQUFPLElBQUlkLHNCQUFzQixDQUFDLElBQUksQ0FBQ0UsZ0JBQWdCLENBQUM0QixNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDdkIsSUFBSSxLQUFLTSxRQUFRLENBQUMsQ0FBQztFQUM3RjtBQUNGO0FBQUNvQixPQUFBLENBQUFsQyxzQkFBQSxHQUFBQSxzQkFBQSJ9