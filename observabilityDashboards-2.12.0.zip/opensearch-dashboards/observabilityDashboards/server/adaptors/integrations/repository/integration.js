"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.IntegrationReader = void 0;
var _path = _interopRequireDefault(require("path"));
var _validators = require("../validators");
var _fs_data_adaptor = require("./fs_data_adaptor");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); } /*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * The Integration class represents the data for Integration Templates.
 * It is backed by the repository file system.
 * It includes accessor methods for integration configs, as well as helpers for nested components.
 */
class IntegrationReader {
  constructor(directory, reader) {
    _defineProperty(this, "reader", void 0);
    _defineProperty(this, "directory", void 0);
    _defineProperty(this, "name", void 0);
    this.directory = directory;
    this.name = _path.default.basename(directory);
    this.reader = reader !== null && reader !== void 0 ? reader : new _fs_data_adaptor.FileSystemCatalogDataAdaptor(directory);
  }

  /**
   * Like getConfig(), but thoroughly checks all nested integration dependencies for validity.
   *
   * @returns a Result indicating whether the integration is valid.
   */
  async deepCheck() {
    const configResult = await this.getConfig();
    if (!configResult.ok) {
      return configResult;
    }
    try {
      const schemas = await this.getSchemas();
      if (!schemas.ok || Object.keys(schemas.value.mappings).length === 0) {
        return {
          ok: false,
          error: new Error('The integration has no schemas available')
        };
      }
      const assets = await this.getAssets();
      if (!assets.ok || Object.keys(assets).length === 0) {
        return {
          ok: false,
          error: new Error('An integration must have at least one asset')
        };
      }
    } catch (err) {
      return {
        ok: false,
        error: err
      };
    }
    return configResult;
  }

  /**
   * Get the latest version of the integration available.
   * This method relies on the fact that integration configs have their versions in their name.
   * Any files that don't match the config naming convention will be ignored.
   *
   * @returns A string with the latest version, or null if no versions are available.
   */
  async getLatestVersion() {
    const versions = await this.reader.findIntegrationVersions();
    if (!versions.ok) {
      console.error(versions.error);
      return null;
    }
    return versions.value.length > 0 ? versions.value[0] : null;
  }

  /**
   * Get the configuration of the current integration.
   *
   * @param version The version of the config to retrieve.
   * @returns The config if a valid config matching the version is present, otherwise null.
   */
  async getConfig(version) {
    if ((await this.reader.getDirectoryType()) !== 'integration') {
      return {
        ok: false,
        error: new Error(`${this.directory} is not a valid integration`)
      };
    }
    const maybeVersion = version ? version : await this.getLatestVersion();
    if (maybeVersion === null) {
      return {
        ok: false,
        error: new Error(`No valid config matching version ${version} is available`)
      };
    }
    const configFile = `${this.name}-${maybeVersion}.json`;
    const config = await this.reader.readFile(configFile);
    if (!config.ok) {
      return config;
    }
    return (0, _validators.validateTemplate)(config.value);
  }

  /**
   * Retrieve assets associated with the integration.
   * This method greedily retrieves all assets.
   * If the version is invalid, an error is thrown.
   * If an asset is invalid, it will be skipped.
   *
   * @param version The version of the integration to retrieve assets for.
   * @returns An object containing the different types of assets.
   */
  async getAssets(version) {
    const configResult = await this.getConfig(version);
    if (!configResult.ok) {
      return configResult;
    }
    const config = configResult.value;
    const resultValue = {};
    if (config.assets.savedObjects) {
      const sobjPath = `${config.assets.savedObjects.name}-${config.assets.savedObjects.version}.ndjson`;
      const assets = await this.reader.readFile(sobjPath, 'assets');
      if (!assets.ok) {
        return assets;
      }
      resultValue.savedObjects = assets.value;
    }
    if (config.assets.queries) {
      resultValue.queries = [];
      const queries = await Promise.all(config.assets.queries.map(async item => {
        const queryPath = `${item.name}-${item.version}.${item.language}`;
        const query = await this.reader.readFileRaw(queryPath, 'assets');
        if (!query.ok) {
          return query;
        }
        return {
          ok: true,
          value: {
            language: item.language,
            query: query.value.toString('utf8')
          }
        };
      }));
      for (const query of queries) {
        if (!query.ok) {
          return query;
        }
        resultValue.queries.push(query.value);
      }
    }
    return {
      ok: true,
      value: resultValue
    };
  }

  /**
   * Retrieve sample data associated with the integration.
   * If the version is invalid, an error is thrown.
   * If the sample data is invalid, null will be returned
   *
   * @param version The version of the integration to retrieve assets for.
   * @returns An object containing a list of sample data with adjusted timestamps.
   */
  async getSampleData(version) {
    const configResult = await this.getConfig(version);
    if (!configResult.ok) {
      return configResult;
    }
    const config = configResult.value;
    const resultValue = {
      sampleData: null
    };
    if (config.sampleData) {
      const jsonContent = await this.reader.readFile(config.sampleData.path, 'data');
      if (!jsonContent.ok) {
        return jsonContent;
      }
      for (const value of jsonContent.value) {
        if (!('@timestamp' in value)) {
          continue;
        }
        // Randomly scatter timestamps across last 10 minutes
        // Assume for now that the ordering of events isn't important, can change to a sequence if needed
        // Also doesn't handle fields like `observedTimestamp` if present
        const newTime = new Date(Date.now() - Math.floor(Math.random() * 1000 * 60 * 10)).toISOString();
        Object.assign(value, {
          '@timestamp': newTime
        });
        if ('observedTimestamp' in value) {
          Object.assign(value, {
            observedTimestamp: newTime
          });
        }
      }
      resultValue.sampleData = jsonContent.value;
    }
    return {
      ok: true,
      value: resultValue
    };
  }

  /**
   * Retrieve schema data associated with the integration.
   * This method greedily retrieves all mappings and schemas.
   * It's assumed that a valid version will be provided.
   * If the version is invalid, an error is thrown.
   * If a schema is invalid, an error will be thrown.
   *
   * @param version The version of the integration to retrieve assets for.
   * @returns An object containing the different types of assets.
   */
  async getSchemas(version) {
    const configResult = await this.getConfig(version);
    if (!configResult.ok) {
      return configResult;
    }
    const config = configResult.value;
    const resultValue = {
      mappings: {}
    };
    for (const component of config.components) {
      const schemaFile = `${component.name}-${component.version}.mapping.json`;
      const schema = await this.reader.readFile(schemaFile, 'schemas');
      if (!schema.ok) {
        return schema;
      }
      resultValue.mappings[component.name] = schema.value;
    }
    return {
      ok: true,
      value: resultValue
    };
  }

  /**
   * Retrieves the data for a static file associated with the integration.
   *
   * @param staticPath The path of the static to retrieve.
   * @returns A buffer with the static's data if present, otherwise null.
   */
  async getStatic(staticPath) {
    return await this.reader.readFileRaw(staticPath, 'static');
  }
}
exports.IntegrationReader = IntegrationReader;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGF0aCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX3ZhbGlkYXRvcnMiLCJfZnNfZGF0YV9hZGFwdG9yIiwib2JqIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJfZGVmaW5lUHJvcGVydHkiLCJrZXkiLCJ2YWx1ZSIsIl90b1Byb3BlcnR5S2V5IiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJhcmciLCJfdG9QcmltaXRpdmUiLCJTdHJpbmciLCJpbnB1dCIsImhpbnQiLCJwcmltIiwiU3ltYm9sIiwidG9QcmltaXRpdmUiLCJ1bmRlZmluZWQiLCJyZXMiLCJjYWxsIiwiVHlwZUVycm9yIiwiTnVtYmVyIiwiSW50ZWdyYXRpb25SZWFkZXIiLCJjb25zdHJ1Y3RvciIsImRpcmVjdG9yeSIsInJlYWRlciIsIm5hbWUiLCJwYXRoIiwiYmFzZW5hbWUiLCJGaWxlU3lzdGVtQ2F0YWxvZ0RhdGFBZGFwdG9yIiwiZGVlcENoZWNrIiwiY29uZmlnUmVzdWx0IiwiZ2V0Q29uZmlnIiwib2siLCJzY2hlbWFzIiwiZ2V0U2NoZW1hcyIsImtleXMiLCJtYXBwaW5ncyIsImxlbmd0aCIsImVycm9yIiwiRXJyb3IiLCJhc3NldHMiLCJnZXRBc3NldHMiLCJlcnIiLCJnZXRMYXRlc3RWZXJzaW9uIiwidmVyc2lvbnMiLCJmaW5kSW50ZWdyYXRpb25WZXJzaW9ucyIsImNvbnNvbGUiLCJ2ZXJzaW9uIiwiZ2V0RGlyZWN0b3J5VHlwZSIsIm1heWJlVmVyc2lvbiIsImNvbmZpZ0ZpbGUiLCJjb25maWciLCJyZWFkRmlsZSIsInZhbGlkYXRlVGVtcGxhdGUiLCJyZXN1bHRWYWx1ZSIsInNhdmVkT2JqZWN0cyIsInNvYmpQYXRoIiwicXVlcmllcyIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJpdGVtIiwicXVlcnlQYXRoIiwibGFuZ3VhZ2UiLCJxdWVyeSIsInJlYWRGaWxlUmF3IiwidG9TdHJpbmciLCJwdXNoIiwiZ2V0U2FtcGxlRGF0YSIsInNhbXBsZURhdGEiLCJqc29uQ29udGVudCIsIm5ld1RpbWUiLCJEYXRlIiwibm93IiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwidG9JU09TdHJpbmciLCJhc3NpZ24iLCJvYnNlcnZlZFRpbWVzdGFtcCIsImNvbXBvbmVudCIsImNvbXBvbmVudHMiLCJzY2hlbWFGaWxlIiwic2NoZW1hIiwiZ2V0U3RhdGljIiwic3RhdGljUGF0aCIsImV4cG9ydHMiXSwic291cmNlcyI6WyJpbnRlZ3JhdGlvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgdmFsaWRhdGVUZW1wbGF0ZSB9IGZyb20gJy4uL3ZhbGlkYXRvcnMnO1xuaW1wb3J0IHsgRmlsZVN5c3RlbUNhdGFsb2dEYXRhQWRhcHRvciB9IGZyb20gJy4vZnNfZGF0YV9hZGFwdG9yJztcblxuLyoqXG4gKiBUaGUgSW50ZWdyYXRpb24gY2xhc3MgcmVwcmVzZW50cyB0aGUgZGF0YSBmb3IgSW50ZWdyYXRpb24gVGVtcGxhdGVzLlxuICogSXQgaXMgYmFja2VkIGJ5IHRoZSByZXBvc2l0b3J5IGZpbGUgc3lzdGVtLlxuICogSXQgaW5jbHVkZXMgYWNjZXNzb3IgbWV0aG9kcyBmb3IgaW50ZWdyYXRpb24gY29uZmlncywgYXMgd2VsbCBhcyBoZWxwZXJzIGZvciBuZXN0ZWQgY29tcG9uZW50cy5cbiAqL1xuZXhwb3J0IGNsYXNzIEludGVncmF0aW9uUmVhZGVyIHtcbiAgcmVhZGVyOiBDYXRhbG9nRGF0YUFkYXB0b3I7XG4gIGRpcmVjdG9yeTogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoZGlyZWN0b3J5OiBzdHJpbmcsIHJlYWRlcj86IENhdGFsb2dEYXRhQWRhcHRvcikge1xuICAgIHRoaXMuZGlyZWN0b3J5ID0gZGlyZWN0b3J5O1xuICAgIHRoaXMubmFtZSA9IHBhdGguYmFzZW5hbWUoZGlyZWN0b3J5KTtcbiAgICB0aGlzLnJlYWRlciA9IHJlYWRlciA/PyBuZXcgRmlsZVN5c3RlbUNhdGFsb2dEYXRhQWRhcHRvcihkaXJlY3RvcnkpO1xuICB9XG5cbiAgLyoqXG4gICAqIExpa2UgZ2V0Q29uZmlnKCksIGJ1dCB0aG9yb3VnaGx5IGNoZWNrcyBhbGwgbmVzdGVkIGludGVncmF0aW9uIGRlcGVuZGVuY2llcyBmb3IgdmFsaWRpdHkuXG4gICAqXG4gICAqIEByZXR1cm5zIGEgUmVzdWx0IGluZGljYXRpbmcgd2hldGhlciB0aGUgaW50ZWdyYXRpb24gaXMgdmFsaWQuXG4gICAqL1xuICBhc3luYyBkZWVwQ2hlY2soKTogUHJvbWlzZTxSZXN1bHQ8SW50ZWdyYXRpb25Db25maWc+PiB7XG4gICAgY29uc3QgY29uZmlnUmVzdWx0ID0gYXdhaXQgdGhpcy5nZXRDb25maWcoKTtcbiAgICBpZiAoIWNvbmZpZ1Jlc3VsdC5vaykge1xuICAgICAgcmV0dXJuIGNvbmZpZ1Jlc3VsdDtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgY29uc3Qgc2NoZW1hcyA9IGF3YWl0IHRoaXMuZ2V0U2NoZW1hcygpO1xuICAgICAgaWYgKCFzY2hlbWFzLm9rIHx8IE9iamVjdC5rZXlzKHNjaGVtYXMudmFsdWUubWFwcGluZ3MpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiBuZXcgRXJyb3IoJ1RoZSBpbnRlZ3JhdGlvbiBoYXMgbm8gc2NoZW1hcyBhdmFpbGFibGUnKSB9O1xuICAgICAgfVxuICAgICAgY29uc3QgYXNzZXRzID0gYXdhaXQgdGhpcy5nZXRBc3NldHMoKTtcbiAgICAgIGlmICghYXNzZXRzLm9rIHx8IE9iamVjdC5rZXlzKGFzc2V0cykubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6IG5ldyBFcnJvcignQW4gaW50ZWdyYXRpb24gbXVzdCBoYXZlIGF0IGxlYXN0IG9uZSBhc3NldCcpIH07XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6IGVyciB9O1xuICAgIH1cblxuICAgIHJldHVybiBjb25maWdSZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHRoZSBsYXRlc3QgdmVyc2lvbiBvZiB0aGUgaW50ZWdyYXRpb24gYXZhaWxhYmxlLlxuICAgKiBUaGlzIG1ldGhvZCByZWxpZXMgb24gdGhlIGZhY3QgdGhhdCBpbnRlZ3JhdGlvbiBjb25maWdzIGhhdmUgdGhlaXIgdmVyc2lvbnMgaW4gdGhlaXIgbmFtZS5cbiAgICogQW55IGZpbGVzIHRoYXQgZG9uJ3QgbWF0Y2ggdGhlIGNvbmZpZyBuYW1pbmcgY29udmVudGlvbiB3aWxsIGJlIGlnbm9yZWQuXG4gICAqXG4gICAqIEByZXR1cm5zIEEgc3RyaW5nIHdpdGggdGhlIGxhdGVzdCB2ZXJzaW9uLCBvciBudWxsIGlmIG5vIHZlcnNpb25zIGFyZSBhdmFpbGFibGUuXG4gICAqL1xuICBhc3luYyBnZXRMYXRlc3RWZXJzaW9uKCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IHZlcnNpb25zID0gYXdhaXQgdGhpcy5yZWFkZXIuZmluZEludGVncmF0aW9uVmVyc2lvbnMoKTtcbiAgICBpZiAoIXZlcnNpb25zLm9rKSB7XG4gICAgICBjb25zb2xlLmVycm9yKHZlcnNpb25zLmVycm9yKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gdmVyc2lvbnMudmFsdWUubGVuZ3RoID4gMCA/IHZlcnNpb25zLnZhbHVlWzBdIDogbnVsbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIGNvbmZpZ3VyYXRpb24gb2YgdGhlIGN1cnJlbnQgaW50ZWdyYXRpb24uXG4gICAqXG4gICAqIEBwYXJhbSB2ZXJzaW9uIFRoZSB2ZXJzaW9uIG9mIHRoZSBjb25maWcgdG8gcmV0cmlldmUuXG4gICAqIEByZXR1cm5zIFRoZSBjb25maWcgaWYgYSB2YWxpZCBjb25maWcgbWF0Y2hpbmcgdGhlIHZlcnNpb24gaXMgcHJlc2VudCwgb3RoZXJ3aXNlIG51bGwuXG4gICAqL1xuICBhc3luYyBnZXRDb25maWcodmVyc2lvbj86IHN0cmluZyk6IFByb21pc2U8UmVzdWx0PEludGVncmF0aW9uQ29uZmlnPj4ge1xuICAgIGlmICgoYXdhaXQgdGhpcy5yZWFkZXIuZ2V0RGlyZWN0b3J5VHlwZSgpKSAhPT0gJ2ludGVncmF0aW9uJykge1xuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogbmV3IEVycm9yKGAke3RoaXMuZGlyZWN0b3J5fSBpcyBub3QgYSB2YWxpZCBpbnRlZ3JhdGlvbmApIH07XG4gICAgfVxuXG4gICAgY29uc3QgbWF5YmVWZXJzaW9uOiBzdHJpbmcgfCBudWxsID0gdmVyc2lvbiA/IHZlcnNpb24gOiBhd2FpdCB0aGlzLmdldExhdGVzdFZlcnNpb24oKTtcblxuICAgIGlmIChtYXliZVZlcnNpb24gPT09IG51bGwpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IG5ldyBFcnJvcihgTm8gdmFsaWQgY29uZmlnIG1hdGNoaW5nIHZlcnNpb24gJHt2ZXJzaW9ufSBpcyBhdmFpbGFibGVgKSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc3QgY29uZmlnRmlsZSA9IGAke3RoaXMubmFtZX0tJHttYXliZVZlcnNpb259Lmpzb25gO1xuXG4gICAgY29uc3QgY29uZmlnID0gYXdhaXQgdGhpcy5yZWFkZXIucmVhZEZpbGUoY29uZmlnRmlsZSk7XG4gICAgaWYgKCFjb25maWcub2spIHtcbiAgICAgIHJldHVybiBjb25maWc7XG4gICAgfVxuICAgIHJldHVybiB2YWxpZGF0ZVRlbXBsYXRlKGNvbmZpZy52YWx1ZSk7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgYXNzZXRzIGFzc29jaWF0ZWQgd2l0aCB0aGUgaW50ZWdyYXRpb24uXG4gICAqIFRoaXMgbWV0aG9kIGdyZWVkaWx5IHJldHJpZXZlcyBhbGwgYXNzZXRzLlxuICAgKiBJZiB0aGUgdmVyc2lvbiBpcyBpbnZhbGlkLCBhbiBlcnJvciBpcyB0aHJvd24uXG4gICAqIElmIGFuIGFzc2V0IGlzIGludmFsaWQsIGl0IHdpbGwgYmUgc2tpcHBlZC5cbiAgICpcbiAgICogQHBhcmFtIHZlcnNpb24gVGhlIHZlcnNpb24gb2YgdGhlIGludGVncmF0aW9uIHRvIHJldHJpZXZlIGFzc2V0cyBmb3IuXG4gICAqIEByZXR1cm5zIEFuIG9iamVjdCBjb250YWluaW5nIHRoZSBkaWZmZXJlbnQgdHlwZXMgb2YgYXNzZXRzLlxuICAgKi9cbiAgYXN5bmMgZ2V0QXNzZXRzKFxuICAgIHZlcnNpb24/OiBzdHJpbmdcbiAgKTogUHJvbWlzZTxcbiAgICBSZXN1bHQ8e1xuICAgICAgc2F2ZWRPYmplY3RzPzogb2JqZWN0W107XG4gICAgICBxdWVyaWVzPzogQXJyYXk8e1xuICAgICAgICBxdWVyeTogc3RyaW5nO1xuICAgICAgICBsYW5ndWFnZTogc3RyaW5nO1xuICAgICAgfT47XG4gICAgfT5cbiAgPiB7XG4gICAgY29uc3QgY29uZmlnUmVzdWx0ID0gYXdhaXQgdGhpcy5nZXRDb25maWcodmVyc2lvbik7XG4gICAgaWYgKCFjb25maWdSZXN1bHQub2spIHtcbiAgICAgIHJldHVybiBjb25maWdSZXN1bHQ7XG4gICAgfVxuICAgIGNvbnN0IGNvbmZpZyA9IGNvbmZpZ1Jlc3VsdC52YWx1ZTtcblxuICAgIGNvbnN0IHJlc3VsdFZhbHVlOiB7XG4gICAgICBzYXZlZE9iamVjdHM/OiBvYmplY3RbXTtcbiAgICAgIHF1ZXJpZXM/OiBBcnJheTx7IHF1ZXJ5OiBzdHJpbmc7IGxhbmd1YWdlOiBzdHJpbmcgfT47XG4gICAgfSA9IHt9O1xuICAgIGlmIChjb25maWcuYXNzZXRzLnNhdmVkT2JqZWN0cykge1xuICAgICAgY29uc3Qgc29ialBhdGggPSBgJHtjb25maWcuYXNzZXRzLnNhdmVkT2JqZWN0cy5uYW1lfS0ke2NvbmZpZy5hc3NldHMuc2F2ZWRPYmplY3RzLnZlcnNpb259Lm5kanNvbmA7XG4gICAgICBjb25zdCBhc3NldHMgPSBhd2FpdCB0aGlzLnJlYWRlci5yZWFkRmlsZShzb2JqUGF0aCwgJ2Fzc2V0cycpO1xuICAgICAgaWYgKCFhc3NldHMub2spIHtcbiAgICAgICAgcmV0dXJuIGFzc2V0cztcbiAgICAgIH1cbiAgICAgIHJlc3VsdFZhbHVlLnNhdmVkT2JqZWN0cyA9IGFzc2V0cy52YWx1ZSBhcyBvYmplY3RbXTtcbiAgICB9XG4gICAgaWYgKGNvbmZpZy5hc3NldHMucXVlcmllcykge1xuICAgICAgcmVzdWx0VmFsdWUucXVlcmllcyA9IFtdO1xuICAgICAgY29uc3QgcXVlcmllcyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICBjb25maWcuYXNzZXRzLnF1ZXJpZXMubWFwKGFzeW5jIChpdGVtKSA9PiB7XG4gICAgICAgICAgY29uc3QgcXVlcnlQYXRoID0gYCR7aXRlbS5uYW1lfS0ke2l0ZW0udmVyc2lvbn0uJHtpdGVtLmxhbmd1YWdlfWA7XG4gICAgICAgICAgY29uc3QgcXVlcnkgPSBhd2FpdCB0aGlzLnJlYWRlci5yZWFkRmlsZVJhdyhxdWVyeVBhdGgsICdhc3NldHMnKTtcbiAgICAgICAgICBpZiAoIXF1ZXJ5Lm9rKSB7XG4gICAgICAgICAgICByZXR1cm4gcXVlcnk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBvazogdHJ1ZSBhcyBjb25zdCxcbiAgICAgICAgICAgIHZhbHVlOiB7XG4gICAgICAgICAgICAgIGxhbmd1YWdlOiBpdGVtLmxhbmd1YWdlLFxuICAgICAgICAgICAgICBxdWVyeTogcXVlcnkudmFsdWUudG9TdHJpbmcoJ3V0ZjgnKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfTtcbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgICBmb3IgKGNvbnN0IHF1ZXJ5IG9mIHF1ZXJpZXMpIHtcbiAgICAgICAgaWYgKCFxdWVyeS5vaykge1xuICAgICAgICAgIHJldHVybiBxdWVyeTtcbiAgICAgICAgfVxuICAgICAgICByZXN1bHRWYWx1ZS5xdWVyaWVzLnB1c2gocXVlcnkudmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IHJlc3VsdFZhbHVlIH07XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgc2FtcGxlIGRhdGEgYXNzb2NpYXRlZCB3aXRoIHRoZSBpbnRlZ3JhdGlvbi5cbiAgICogSWYgdGhlIHZlcnNpb24gaXMgaW52YWxpZCwgYW4gZXJyb3IgaXMgdGhyb3duLlxuICAgKiBJZiB0aGUgc2FtcGxlIGRhdGEgaXMgaW52YWxpZCwgbnVsbCB3aWxsIGJlIHJldHVybmVkXG4gICAqXG4gICAqIEBwYXJhbSB2ZXJzaW9uIFRoZSB2ZXJzaW9uIG9mIHRoZSBpbnRlZ3JhdGlvbiB0byByZXRyaWV2ZSBhc3NldHMgZm9yLlxuICAgKiBAcmV0dXJucyBBbiBvYmplY3QgY29udGFpbmluZyBhIGxpc3Qgb2Ygc2FtcGxlIGRhdGEgd2l0aCBhZGp1c3RlZCB0aW1lc3RhbXBzLlxuICAgKi9cbiAgYXN5bmMgZ2V0U2FtcGxlRGF0YShcbiAgICB2ZXJzaW9uPzogc3RyaW5nXG4gICk6IFByb21pc2U8XG4gICAgUmVzdWx0PHtcbiAgICAgIHNhbXBsZURhdGE6IG9iamVjdFtdIHwgbnVsbDtcbiAgICB9PlxuICA+IHtcbiAgICBjb25zdCBjb25maWdSZXN1bHQgPSBhd2FpdCB0aGlzLmdldENvbmZpZyh2ZXJzaW9uKTtcbiAgICBpZiAoIWNvbmZpZ1Jlc3VsdC5vaykge1xuICAgICAgcmV0dXJuIGNvbmZpZ1Jlc3VsdDtcbiAgICB9XG4gICAgY29uc3QgY29uZmlnID0gY29uZmlnUmVzdWx0LnZhbHVlO1xuXG4gICAgY29uc3QgcmVzdWx0VmFsdWU6IHsgc2FtcGxlRGF0YTogb2JqZWN0W10gfCBudWxsIH0gPSB7IHNhbXBsZURhdGE6IG51bGwgfTtcbiAgICBpZiAoY29uZmlnLnNhbXBsZURhdGEpIHtcbiAgICAgIGNvbnN0IGpzb25Db250ZW50ID0gYXdhaXQgdGhpcy5yZWFkZXIucmVhZEZpbGUoY29uZmlnLnNhbXBsZURhdGEucGF0aCwgJ2RhdGEnKTtcbiAgICAgIGlmICghanNvbkNvbnRlbnQub2spIHtcbiAgICAgICAgcmV0dXJuIGpzb25Db250ZW50O1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBqc29uQ29udGVudC52YWx1ZSBhcyBvYmplY3RbXSkge1xuICAgICAgICBpZiAoISgnQHRpbWVzdGFtcCcgaW4gdmFsdWUpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmFuZG9tbHkgc2NhdHRlciB0aW1lc3RhbXBzIGFjcm9zcyBsYXN0IDEwIG1pbnV0ZXNcbiAgICAgICAgLy8gQXNzdW1lIGZvciBub3cgdGhhdCB0aGUgb3JkZXJpbmcgb2YgZXZlbnRzIGlzbid0IGltcG9ydGFudCwgY2FuIGNoYW5nZSB0byBhIHNlcXVlbmNlIGlmIG5lZWRlZFxuICAgICAgICAvLyBBbHNvIGRvZXNuJ3QgaGFuZGxlIGZpZWxkcyBsaWtlIGBvYnNlcnZlZFRpbWVzdGFtcGAgaWYgcHJlc2VudFxuICAgICAgICBjb25zdCBuZXdUaW1lID0gbmV3IERhdGUoXG4gICAgICAgICAgRGF0ZS5ub3coKSAtIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDAgKiA2MCAqIDEwKVxuICAgICAgICApLnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIE9iamVjdC5hc3NpZ24odmFsdWUsIHsgJ0B0aW1lc3RhbXAnOiBuZXdUaW1lIH0pO1xuICAgICAgICBpZiAoJ29ic2VydmVkVGltZXN0YW1wJyBpbiB2YWx1ZSkge1xuICAgICAgICAgIE9iamVjdC5hc3NpZ24odmFsdWUsIHsgb2JzZXJ2ZWRUaW1lc3RhbXA6IG5ld1RpbWUgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3VsdFZhbHVlLnNhbXBsZURhdGEgPSBqc29uQ29udGVudC52YWx1ZSBhcyBvYmplY3RbXTtcbiAgICB9XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHZhbHVlOiByZXN1bHRWYWx1ZSB9O1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHNjaGVtYSBkYXRhIGFzc29jaWF0ZWQgd2l0aCB0aGUgaW50ZWdyYXRpb24uXG4gICAqIFRoaXMgbWV0aG9kIGdyZWVkaWx5IHJldHJpZXZlcyBhbGwgbWFwcGluZ3MgYW5kIHNjaGVtYXMuXG4gICAqIEl0J3MgYXNzdW1lZCB0aGF0IGEgdmFsaWQgdmVyc2lvbiB3aWxsIGJlIHByb3ZpZGVkLlxuICAgKiBJZiB0aGUgdmVyc2lvbiBpcyBpbnZhbGlkLCBhbiBlcnJvciBpcyB0aHJvd24uXG4gICAqIElmIGEgc2NoZW1hIGlzIGludmFsaWQsIGFuIGVycm9yIHdpbGwgYmUgdGhyb3duLlxuICAgKlxuICAgKiBAcGFyYW0gdmVyc2lvbiBUaGUgdmVyc2lvbiBvZiB0aGUgaW50ZWdyYXRpb24gdG8gcmV0cmlldmUgYXNzZXRzIGZvci5cbiAgICogQHJldHVybnMgQW4gb2JqZWN0IGNvbnRhaW5pbmcgdGhlIGRpZmZlcmVudCB0eXBlcyBvZiBhc3NldHMuXG4gICAqL1xuICBhc3luYyBnZXRTY2hlbWFzKFxuICAgIHZlcnNpb24/OiBzdHJpbmdcbiAgKTogUHJvbWlzZTxcbiAgICBSZXN1bHQ8e1xuICAgICAgbWFwcGluZ3M6IHsgW2tleTogc3RyaW5nXTogYW55IH07XG4gICAgfT5cbiAgPiB7XG4gICAgY29uc3QgY29uZmlnUmVzdWx0ID0gYXdhaXQgdGhpcy5nZXRDb25maWcodmVyc2lvbik7XG4gICAgaWYgKCFjb25maWdSZXN1bHQub2spIHtcbiAgICAgIHJldHVybiBjb25maWdSZXN1bHQ7XG4gICAgfVxuICAgIGNvbnN0IGNvbmZpZyA9IGNvbmZpZ1Jlc3VsdC52YWx1ZTtcblxuICAgIGNvbnN0IHJlc3VsdFZhbHVlOiB7IG1hcHBpbmdzOiB7IFtrZXk6IHN0cmluZ106IG9iamVjdCB9IH0gPSB7XG4gICAgICBtYXBwaW5nczoge30sXG4gICAgfTtcbiAgICBmb3IgKGNvbnN0IGNvbXBvbmVudCBvZiBjb25maWcuY29tcG9uZW50cykge1xuICAgICAgY29uc3Qgc2NoZW1hRmlsZSA9IGAke2NvbXBvbmVudC5uYW1lfS0ke2NvbXBvbmVudC52ZXJzaW9ufS5tYXBwaW5nLmpzb25gO1xuICAgICAgY29uc3Qgc2NoZW1hID0gYXdhaXQgdGhpcy5yZWFkZXIucmVhZEZpbGUoc2NoZW1hRmlsZSwgJ3NjaGVtYXMnKTtcbiAgICAgIGlmICghc2NoZW1hLm9rKSB7XG4gICAgICAgIHJldHVybiBzY2hlbWE7XG4gICAgICB9XG4gICAgICByZXN1bHRWYWx1ZS5tYXBwaW5nc1tjb21wb25lbnQubmFtZV0gPSBzY2hlbWEudmFsdWU7XG4gICAgfVxuICAgIHJldHVybiB7IG9rOiB0cnVlLCB2YWx1ZTogcmVzdWx0VmFsdWUgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgdGhlIGRhdGEgZm9yIGEgc3RhdGljIGZpbGUgYXNzb2NpYXRlZCB3aXRoIHRoZSBpbnRlZ3JhdGlvbi5cbiAgICpcbiAgICogQHBhcmFtIHN0YXRpY1BhdGggVGhlIHBhdGggb2YgdGhlIHN0YXRpYyB0byByZXRyaWV2ZS5cbiAgICogQHJldHVybnMgQSBidWZmZXIgd2l0aCB0aGUgc3RhdGljJ3MgZGF0YSBpZiBwcmVzZW50LCBvdGhlcndpc2UgbnVsbC5cbiAgICovXG4gIGFzeW5jIGdldFN0YXRpYyhzdGF0aWNQYXRoOiBzdHJpbmcpOiBQcm9taXNlPFJlc3VsdDxCdWZmZXI+PiB7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMucmVhZGVyLnJlYWRGaWxlUmF3KHN0YXRpY1BhdGgsICdzdGF0aWMnKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxLQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxnQkFBQSxHQUFBRixPQUFBO0FBQWlFLFNBQUFELHVCQUFBSSxHQUFBLFdBQUFBLEdBQUEsSUFBQUEsR0FBQSxDQUFBQyxVQUFBLEdBQUFELEdBQUEsS0FBQUUsT0FBQSxFQUFBRixHQUFBO0FBQUEsU0FBQUcsZ0JBQUFILEdBQUEsRUFBQUksR0FBQSxFQUFBQyxLQUFBLElBQUFELEdBQUEsR0FBQUUsY0FBQSxDQUFBRixHQUFBLE9BQUFBLEdBQUEsSUFBQUosR0FBQSxJQUFBTyxNQUFBLENBQUFDLGNBQUEsQ0FBQVIsR0FBQSxFQUFBSSxHQUFBLElBQUFDLEtBQUEsRUFBQUEsS0FBQSxFQUFBSSxVQUFBLFFBQUFDLFlBQUEsUUFBQUMsUUFBQSxvQkFBQVgsR0FBQSxDQUFBSSxHQUFBLElBQUFDLEtBQUEsV0FBQUwsR0FBQTtBQUFBLFNBQUFNLGVBQUFNLEdBQUEsUUFBQVIsR0FBQSxHQUFBUyxZQUFBLENBQUFELEdBQUEsMkJBQUFSLEdBQUEsZ0JBQUFBLEdBQUEsR0FBQVUsTUFBQSxDQUFBVixHQUFBO0FBQUEsU0FBQVMsYUFBQUUsS0FBQSxFQUFBQyxJQUFBLGVBQUFELEtBQUEsaUJBQUFBLEtBQUEsa0JBQUFBLEtBQUEsTUFBQUUsSUFBQSxHQUFBRixLQUFBLENBQUFHLE1BQUEsQ0FBQUMsV0FBQSxPQUFBRixJQUFBLEtBQUFHLFNBQUEsUUFBQUMsR0FBQSxHQUFBSixJQUFBLENBQUFLLElBQUEsQ0FBQVAsS0FBQSxFQUFBQyxJQUFBLDJCQUFBSyxHQUFBLHNCQUFBQSxHQUFBLFlBQUFFLFNBQUEsNERBQUFQLElBQUEsZ0JBQUFGLE1BQUEsR0FBQVUsTUFBQSxFQUFBVCxLQUFBLEtBUGpFO0FBQ0E7QUFDQTtBQUNBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1VLGlCQUFpQixDQUFDO0VBSzdCQyxXQUFXQSxDQUFDQyxTQUFpQixFQUFFQyxNQUEyQixFQUFFO0lBQUF6QixlQUFBO0lBQUFBLGVBQUE7SUFBQUEsZUFBQTtJQUMxRCxJQUFJLENBQUN3QixTQUFTLEdBQUdBLFNBQVM7SUFDMUIsSUFBSSxDQUFDRSxJQUFJLEdBQUdDLGFBQUksQ0FBQ0MsUUFBUSxDQUFDSixTQUFTLENBQUM7SUFDcEMsSUFBSSxDQUFDQyxNQUFNLEdBQUdBLE1BQU0sYUFBTkEsTUFBTSxjQUFOQSxNQUFNLEdBQUksSUFBSUksNkNBQTRCLENBQUNMLFNBQVMsQ0FBQztFQUNyRTs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTU0sU0FBU0EsQ0FBQSxFQUF1QztJQUNwRCxNQUFNQyxZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUNDLFNBQVMsQ0FBQyxDQUFDO0lBQzNDLElBQUksQ0FBQ0QsWUFBWSxDQUFDRSxFQUFFLEVBQUU7TUFDcEIsT0FBT0YsWUFBWTtJQUNyQjtJQUVBLElBQUk7TUFDRixNQUFNRyxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUNDLFVBQVUsQ0FBQyxDQUFDO01BQ3ZDLElBQUksQ0FBQ0QsT0FBTyxDQUFDRCxFQUFFLElBQUk3QixNQUFNLENBQUNnQyxJQUFJLENBQUNGLE9BQU8sQ0FBQ2hDLEtBQUssQ0FBQ21DLFFBQVEsQ0FBQyxDQUFDQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQ25FLE9BQU87VUFBRUwsRUFBRSxFQUFFLEtBQUs7VUFBRU0sS0FBSyxFQUFFLElBQUlDLEtBQUssQ0FBQywwQ0FBMEM7UUFBRSxDQUFDO01BQ3BGO01BQ0EsTUFBTUMsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDQyxTQUFTLENBQUMsQ0FBQztNQUNyQyxJQUFJLENBQUNELE1BQU0sQ0FBQ1IsRUFBRSxJQUFJN0IsTUFBTSxDQUFDZ0MsSUFBSSxDQUFDSyxNQUFNLENBQUMsQ0FBQ0gsTUFBTSxLQUFLLENBQUMsRUFBRTtRQUNsRCxPQUFPO1VBQUVMLEVBQUUsRUFBRSxLQUFLO1VBQUVNLEtBQUssRUFBRSxJQUFJQyxLQUFLLENBQUMsNkNBQTZDO1FBQUUsQ0FBQztNQUN2RjtJQUNGLENBQUMsQ0FBQyxPQUFPRyxHQUFRLEVBQUU7TUFDakIsT0FBTztRQUFFVixFQUFFLEVBQUUsS0FBSztRQUFFTSxLQUFLLEVBQUVJO01BQUksQ0FBQztJQUNsQztJQUVBLE9BQU9aLFlBQVk7RUFDckI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNYSxnQkFBZ0JBLENBQUEsRUFBMkI7SUFDL0MsTUFBTUMsUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDcEIsTUFBTSxDQUFDcUIsdUJBQXVCLENBQUMsQ0FBQztJQUM1RCxJQUFJLENBQUNELFFBQVEsQ0FBQ1osRUFBRSxFQUFFO01BQ2hCYyxPQUFPLENBQUNSLEtBQUssQ0FBQ00sUUFBUSxDQUFDTixLQUFLLENBQUM7TUFDN0IsT0FBTyxJQUFJO0lBQ2I7SUFDQSxPQUFPTSxRQUFRLENBQUMzQyxLQUFLLENBQUNvQyxNQUFNLEdBQUcsQ0FBQyxHQUFHTyxRQUFRLENBQUMzQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSTtFQUM3RDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNOEIsU0FBU0EsQ0FBQ2dCLE9BQWdCLEVBQXNDO0lBQ3BFLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQ3ZCLE1BQU0sQ0FBQ3dCLGdCQUFnQixDQUFDLENBQUMsTUFBTSxhQUFhLEVBQUU7TUFDNUQsT0FBTztRQUFFaEIsRUFBRSxFQUFFLEtBQUs7UUFBRU0sS0FBSyxFQUFFLElBQUlDLEtBQUssQ0FBRSxHQUFFLElBQUksQ0FBQ2hCLFNBQVUsNkJBQTRCO01BQUUsQ0FBQztJQUN4RjtJQUVBLE1BQU0wQixZQUEyQixHQUFHRixPQUFPLEdBQUdBLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQ0osZ0JBQWdCLENBQUMsQ0FBQztJQUVyRixJQUFJTSxZQUFZLEtBQUssSUFBSSxFQUFFO01BQ3pCLE9BQU87UUFDTGpCLEVBQUUsRUFBRSxLQUFLO1FBQ1RNLEtBQUssRUFBRSxJQUFJQyxLQUFLLENBQUUsb0NBQW1DUSxPQUFRLGVBQWM7TUFDN0UsQ0FBQztJQUNIO0lBRUEsTUFBTUcsVUFBVSxHQUFJLEdBQUUsSUFBSSxDQUFDekIsSUFBSyxJQUFHd0IsWUFBYSxPQUFNO0lBRXRELE1BQU1FLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQzNCLE1BQU0sQ0FBQzRCLFFBQVEsQ0FBQ0YsVUFBVSxDQUFDO0lBQ3JELElBQUksQ0FBQ0MsTUFBTSxDQUFDbkIsRUFBRSxFQUFFO01BQ2QsT0FBT21CLE1BQU07SUFDZjtJQUNBLE9BQU8sSUFBQUUsNEJBQWdCLEVBQUNGLE1BQU0sQ0FBQ2xELEtBQUssQ0FBQztFQUN2Qzs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNd0MsU0FBU0EsQ0FDYk0sT0FBZ0IsRUFTaEI7SUFDQSxNQUFNakIsWUFBWSxHQUFHLE1BQU0sSUFBSSxDQUFDQyxTQUFTLENBQUNnQixPQUFPLENBQUM7SUFDbEQsSUFBSSxDQUFDakIsWUFBWSxDQUFDRSxFQUFFLEVBQUU7TUFDcEIsT0FBT0YsWUFBWTtJQUNyQjtJQUNBLE1BQU1xQixNQUFNLEdBQUdyQixZQUFZLENBQUM3QixLQUFLO0lBRWpDLE1BQU1xRCxXQUdMLEdBQUcsQ0FBQyxDQUFDO0lBQ04sSUFBSUgsTUFBTSxDQUFDWCxNQUFNLENBQUNlLFlBQVksRUFBRTtNQUM5QixNQUFNQyxRQUFRLEdBQUksR0FBRUwsTUFBTSxDQUFDWCxNQUFNLENBQUNlLFlBQVksQ0FBQzlCLElBQUssSUFBRzBCLE1BQU0sQ0FBQ1gsTUFBTSxDQUFDZSxZQUFZLENBQUNSLE9BQVEsU0FBUTtNQUNsRyxNQUFNUCxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUNoQixNQUFNLENBQUM0QixRQUFRLENBQUNJLFFBQVEsRUFBRSxRQUFRLENBQUM7TUFDN0QsSUFBSSxDQUFDaEIsTUFBTSxDQUFDUixFQUFFLEVBQUU7UUFDZCxPQUFPUSxNQUFNO01BQ2Y7TUFDQWMsV0FBVyxDQUFDQyxZQUFZLEdBQUdmLE1BQU0sQ0FBQ3ZDLEtBQWlCO0lBQ3JEO0lBQ0EsSUFBSWtELE1BQU0sQ0FBQ1gsTUFBTSxDQUFDaUIsT0FBTyxFQUFFO01BQ3pCSCxXQUFXLENBQUNHLE9BQU8sR0FBRyxFQUFFO01BQ3hCLE1BQU1BLE9BQU8sR0FBRyxNQUFNQyxPQUFPLENBQUNDLEdBQUcsQ0FDL0JSLE1BQU0sQ0FBQ1gsTUFBTSxDQUFDaUIsT0FBTyxDQUFDRyxHQUFHLENBQUMsTUFBT0MsSUFBSSxJQUFLO1FBQ3hDLE1BQU1DLFNBQVMsR0FBSSxHQUFFRCxJQUFJLENBQUNwQyxJQUFLLElBQUdvQyxJQUFJLENBQUNkLE9BQVEsSUFBR2MsSUFBSSxDQUFDRSxRQUFTLEVBQUM7UUFDakUsTUFBTUMsS0FBSyxHQUFHLE1BQU0sSUFBSSxDQUFDeEMsTUFBTSxDQUFDeUMsV0FBVyxDQUFDSCxTQUFTLEVBQUUsUUFBUSxDQUFDO1FBQ2hFLElBQUksQ0FBQ0UsS0FBSyxDQUFDaEMsRUFBRSxFQUFFO1VBQ2IsT0FBT2dDLEtBQUs7UUFDZDtRQUNBLE9BQU87VUFDTGhDLEVBQUUsRUFBRSxJQUFhO1VBQ2pCL0IsS0FBSyxFQUFFO1lBQ0w4RCxRQUFRLEVBQUVGLElBQUksQ0FBQ0UsUUFBUTtZQUN2QkMsS0FBSyxFQUFFQSxLQUFLLENBQUMvRCxLQUFLLENBQUNpRSxRQUFRLENBQUMsTUFBTTtVQUNwQztRQUNGLENBQUM7TUFDSCxDQUFDLENBQ0gsQ0FBQztNQUNELEtBQUssTUFBTUYsS0FBSyxJQUFJUCxPQUFPLEVBQUU7UUFDM0IsSUFBSSxDQUFDTyxLQUFLLENBQUNoQyxFQUFFLEVBQUU7VUFDYixPQUFPZ0MsS0FBSztRQUNkO1FBQ0FWLFdBQVcsQ0FBQ0csT0FBTyxDQUFDVSxJQUFJLENBQUNILEtBQUssQ0FBQy9ELEtBQUssQ0FBQztNQUN2QztJQUNGO0lBQ0EsT0FBTztNQUFFK0IsRUFBRSxFQUFFLElBQUk7TUFBRS9CLEtBQUssRUFBRXFEO0lBQVksQ0FBQztFQUN6Qzs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTWMsYUFBYUEsQ0FDakJyQixPQUFnQixFQUtoQjtJQUNBLE1BQU1qQixZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUNDLFNBQVMsQ0FBQ2dCLE9BQU8sQ0FBQztJQUNsRCxJQUFJLENBQUNqQixZQUFZLENBQUNFLEVBQUUsRUFBRTtNQUNwQixPQUFPRixZQUFZO0lBQ3JCO0lBQ0EsTUFBTXFCLE1BQU0sR0FBR3JCLFlBQVksQ0FBQzdCLEtBQUs7SUFFakMsTUFBTXFELFdBQTRDLEdBQUc7TUFBRWUsVUFBVSxFQUFFO0lBQUssQ0FBQztJQUN6RSxJQUFJbEIsTUFBTSxDQUFDa0IsVUFBVSxFQUFFO01BQ3JCLE1BQU1DLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQzlDLE1BQU0sQ0FBQzRCLFFBQVEsQ0FBQ0QsTUFBTSxDQUFDa0IsVUFBVSxDQUFDM0MsSUFBSSxFQUFFLE1BQU0sQ0FBQztNQUM5RSxJQUFJLENBQUM0QyxXQUFXLENBQUN0QyxFQUFFLEVBQUU7UUFDbkIsT0FBT3NDLFdBQVc7TUFDcEI7TUFDQSxLQUFLLE1BQU1yRSxLQUFLLElBQUlxRSxXQUFXLENBQUNyRSxLQUFLLEVBQWM7UUFDakQsSUFBSSxFQUFFLFlBQVksSUFBSUEsS0FBSyxDQUFDLEVBQUU7VUFDNUI7UUFDRjtRQUNBO1FBQ0E7UUFDQTtRQUNBLE1BQU1zRSxPQUFPLEdBQUcsSUFBSUMsSUFBSSxDQUN0QkEsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxHQUFHQyxJQUFJLENBQUNDLEtBQUssQ0FBQ0QsSUFBSSxDQUFDRSxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUN4RCxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO1FBQ2YxRSxNQUFNLENBQUMyRSxNQUFNLENBQUM3RSxLQUFLLEVBQUU7VUFBRSxZQUFZLEVBQUVzRTtRQUFRLENBQUMsQ0FBQztRQUMvQyxJQUFJLG1CQUFtQixJQUFJdEUsS0FBSyxFQUFFO1VBQ2hDRSxNQUFNLENBQUMyRSxNQUFNLENBQUM3RSxLQUFLLEVBQUU7WUFBRThFLGlCQUFpQixFQUFFUjtVQUFRLENBQUMsQ0FBQztRQUN0RDtNQUNGO01BQ0FqQixXQUFXLENBQUNlLFVBQVUsR0FBR0MsV0FBVyxDQUFDckUsS0FBaUI7SUFDeEQ7SUFDQSxPQUFPO01BQUUrQixFQUFFLEVBQUUsSUFBSTtNQUFFL0IsS0FBSyxFQUFFcUQ7SUFBWSxDQUFDO0VBQ3pDOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTXBCLFVBQVVBLENBQ2RhLE9BQWdCLEVBS2hCO0lBQ0EsTUFBTWpCLFlBQVksR0FBRyxNQUFNLElBQUksQ0FBQ0MsU0FBUyxDQUFDZ0IsT0FBTyxDQUFDO0lBQ2xELElBQUksQ0FBQ2pCLFlBQVksQ0FBQ0UsRUFBRSxFQUFFO01BQ3BCLE9BQU9GLFlBQVk7SUFDckI7SUFDQSxNQUFNcUIsTUFBTSxHQUFHckIsWUFBWSxDQUFDN0IsS0FBSztJQUVqQyxNQUFNcUQsV0FBb0QsR0FBRztNQUMzRGxCLFFBQVEsRUFBRSxDQUFDO0lBQ2IsQ0FBQztJQUNELEtBQUssTUFBTTRDLFNBQVMsSUFBSTdCLE1BQU0sQ0FBQzhCLFVBQVUsRUFBRTtNQUN6QyxNQUFNQyxVQUFVLEdBQUksR0FBRUYsU0FBUyxDQUFDdkQsSUFBSyxJQUFHdUQsU0FBUyxDQUFDakMsT0FBUSxlQUFjO01BQ3hFLE1BQU1vQyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMzRCxNQUFNLENBQUM0QixRQUFRLENBQUM4QixVQUFVLEVBQUUsU0FBUyxDQUFDO01BQ2hFLElBQUksQ0FBQ0MsTUFBTSxDQUFDbkQsRUFBRSxFQUFFO1FBQ2QsT0FBT21ELE1BQU07TUFDZjtNQUNBN0IsV0FBVyxDQUFDbEIsUUFBUSxDQUFDNEMsU0FBUyxDQUFDdkQsSUFBSSxDQUFDLEdBQUcwRCxNQUFNLENBQUNsRixLQUFLO0lBQ3JEO0lBQ0EsT0FBTztNQUFFK0IsRUFBRSxFQUFFLElBQUk7TUFBRS9CLEtBQUssRUFBRXFEO0lBQVksQ0FBQztFQUN6Qzs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNOEIsU0FBU0EsQ0FBQ0MsVUFBa0IsRUFBMkI7SUFDM0QsT0FBTyxNQUFNLElBQUksQ0FBQzdELE1BQU0sQ0FBQ3lDLFdBQVcsQ0FBQ29CLFVBQVUsRUFBRSxRQUFRLENBQUM7RUFDNUQ7QUFDRjtBQUFDQyxPQUFBLENBQUFqRSxpQkFBQSxHQUFBQSxpQkFBQSJ9