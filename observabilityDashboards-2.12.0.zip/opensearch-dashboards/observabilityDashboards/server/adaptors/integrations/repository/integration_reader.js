"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.IntegrationReader = void 0;
var _path = _interopRequireDefault(require("path"));
var _semver = _interopRequireDefault(require("semver"));
var _validators = require("../validators");
var _fs_data_adaptor = require("./fs_data_adaptor");
var _utils = require("./utils");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); } /*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * The Integration class represents the data for Integration Templates.
 * It is backed by the repository file system.
 * It includes accessor methods for integration configs, as well as helpers for nested components.
 */
class IntegrationReader {
  constructor(directory, reader) {
    _defineProperty(this, "reader", void 0);
    _defineProperty(this, "directory", void 0);
    _defineProperty(this, "name", void 0);
    this.directory = directory;
    this.name = _path.default.basename(directory);
    this.reader = reader !== null && reader !== void 0 ? reader : new _fs_data_adaptor.FileSystemCatalogDataAdaptor(directory);
  }

  /**
   * Retrieve data from correct source regardless of if reader is config-localized or not.
   *
   * TODO refactor to assemble filename from `type` instead of requiring caller to format it.
   *
   * @param item An item which may have data in it.
   * @param fileParams Information about the file to read if the config is not localized.
   * @param format How to package the returned data.
   *               If 'json', return `object | object[]`. If 'binary', return `Buffer`.
   * @returns A result with the data, with a format based on the format field.
   */

  async fetchDataOrReadFile(item, fileParams, format) {
    if (this.reader.isConfigLocalized) {
      if (!item.data) {
        return {
          ok: false,
          error: new Error('The config for the provided reader is localized, but no data field is present. ' + JSON.stringify(item))
        };
      }
      try {
        if (format === 'json') {
          return {
            ok: true,
            value: JSON.parse(item.data)
          };
        } else {
          return {
            ok: true,
            value: Buffer.from(item.data, 'base64')
          };
        }
      } catch (error) {
        return {
          ok: false,
          error
        };
      }
    }
    if (format === 'json') {
      return this.reader.readFile(fileParams.filename, fileParams.type);
    } else {
      return this.reader.readFileRaw(fileParams.filename, fileParams.type);
    }
  }

  /**
   * Get the latest version of the integration available.
   * This method relies on the fact that integration configs have their versions in their name.
   * Any files that don't match the config naming convention will be ignored.
   *
   * @returns A string with the latest version, or null if no versions are available.
   */
  async getLatestVersion() {
    const versions = await this.reader.findIntegrationVersions();
    if (!versions.ok) {
      return null;
    }
    if (versions.value.length === 0) {
      return null;
    }
    // Sort descending
    versions.value.sort(_semver.default.rcompare);
    return versions.value[0];
  }

  // Get config without pruning or validation.
  async getRawConfig(version) {
    if ((await this.reader.getDirectoryType()) !== 'integration') {
      return {
        ok: false,
        error: new Error(`${this.directory} is not a valid integration directory`)
      };
    }
    const maybeVersion = version ? version : await this.getLatestVersion();
    if (maybeVersion === null) {
      return {
        ok: false,
        error: new Error(`No valid config matching version ${version} is available`)
      };
    }
    const configFile = `${this.name}-${maybeVersion}.json`;

    // Even config-localized readers must support config-read.
    const config = await this.reader.readFile(configFile);
    if (!config.ok) {
      return config;
    }
    return (0, _validators.validateTemplate)(config.value);
  }

  /**
   * Get the configuration of the current integration.
   *
   * @param version The version of the config to retrieve.
   * @returns The config if a valid config matching the version is present, otherwise null.
   */
  async getConfig(version) {
    const maybeConfig = await this.getRawConfig(version);
    if (!maybeConfig.ok) {
      return maybeConfig;
    }
    return (0, _validators.validateTemplate)((0, _utils.pruneConfig)(maybeConfig.value));
  }
  async getQueries(queriesList) {
    const queries = await Promise.all(queriesList.map(async item => {
      const query = await this.fetchDataOrReadFile(item, {
        filename: `${item.name}-${item.version}.${item.language}`,
        type: 'assets'
      }, 'binary');
      if (!query.ok) {
        return query;
      }
      return {
        ok: true,
        value: {
          language: item.language,
          query: query.value.toString('utf8')
        }
      };
    }));
    return (0, _utils.foldResults)(queries);
  }

  /**
   * Retrieve assets associated with the integration.
   * This method greedily retrieves all assets.
   * If the version is invalid, an error is thrown.
   * If an asset is invalid, it will be skipped.
   *
   * @param version The version of the integration to retrieve assets for.
   * @returns An object containing the different types of assets.
   */
  async getAssets(version) {
    const configResult = await this.getRawConfig(version);
    if (!configResult.ok) {
      return configResult;
    }
    const config = configResult.value;
    const resultValue = {};
    if (config.assets.savedObjects) {
      const assets = await this.fetchDataOrReadFile(config.assets.savedObjects, {
        filename: `${config.assets.savedObjects.name}-${config.assets.savedObjects.version}.ndjson`,
        type: 'assets'
      }, 'json');
      if (!assets.ok) {
        return assets;
      }
      resultValue.savedObjects = assets.value;
    }
    if (config.assets.queries) {
      const queries = await this.getQueries(config.assets.queries);
      if (!queries.ok) {
        return queries;
      }
      resultValue.queries = queries.value;
    }
    return {
      ok: true,
      value: resultValue
    };
  }

  /**
   * Retrieve sample data associated with the integration.
   * If the version is invalid, an error is thrown.
   * If the sample data is invalid, null will be returned
   *
   * @param version The version of the integration to retrieve assets for.
   * @returns An object containing a list of sample data with adjusted timestamps.
   */
  async getSampleData(version) {
    const configResult = await this.getRawConfig(version);
    if (!configResult.ok) {
      return configResult;
    }
    const config = configResult.value;
    const resultValue = {
      sampleData: null
    };
    if (config.sampleData) {
      const jsonContent = await this.fetchDataOrReadFile(config.sampleData, {
        filename: config.sampleData.path,
        type: 'data'
      }, 'json');
      if (!jsonContent.ok) {
        return jsonContent;
      }
      for (const value of jsonContent.value) {
        if (!('@timestamp' in value)) {
          continue;
        }
        // Randomly scatter timestamps across last 10 minutes
        // Assume for now that the ordering of events isn't important, can change to a sequence if needed
        // Also doesn't handle fields like `observedTimestamp` if present
        const newTime = new Date(Date.now() - Math.floor(Math.random() * 1000 * 60 * 10)).toISOString();
        Object.assign(value, {
          '@timestamp': newTime
        });
        if ('observedTimestamp' in value) {
          Object.assign(value, {
            observedTimestamp: newTime
          });
        }
      }
      resultValue.sampleData = jsonContent.value;
    }
    return {
      ok: true,
      value: resultValue
    };
  }

  /**
   * Retrieve schema data associated with the integration.
   * This method greedily retrieves all mappings and schemas.
   * It's assumed that a valid version will be provided.
   * If the version is invalid, an error is thrown.
   * If a schema is invalid, an error will be thrown.
   *
   * @param version The version of the integration to retrieve assets for.
   * @returns An object containing the different types of assets.
   */
  async getSchemas(version) {
    const configResult = await this.getRawConfig(version);
    if (!configResult.ok) {
      return configResult;
    }
    const config = configResult.value;
    const resultValue = {
      mappings: {}
    };
    for (const component of config.components) {
      const schemaFile = `${component.name}-${component.version}.mapping.json`;
      const schema = await this.fetchDataOrReadFile(component, {
        filename: schemaFile,
        type: 'schemas'
      }, 'json');
      if (!schema.ok) {
        return schema;
      }
      resultValue.mappings[component.name] = schema.value;
    }
    return {
      ok: true,
      value: resultValue
    };
  }

  /**
   * Retrieves the data for a static file associated with the integration.
   *
   * @param staticPath The path of the static to retrieve.
   * @returns A buffer with the static's data if present, otherwise null.
   */
  async getStatic(staticPath) {
    // Statics were originally designed to read straight from file system,
    // so we use direct access if possible.
    if (!this.reader.isConfigLocalized) {
      return await this.reader.readFileRaw(staticPath, 'static');
    }

    // Otherwise, we need to search for the right static, by checking each version.
    const versions = await this.reader.findIntegrationVersions();
    if (!versions.ok) {
      return versions;
    }
    for (const version of versions.value) {
      var _statics$logo, _statics$darkModeLogo;
      const config = await this.getRawConfig(version);
      if (!config.ok || !config.value.statics) {
        continue;
      }
      const statics = config.value.statics;
      if (((_statics$logo = statics.logo) === null || _statics$logo === void 0 ? void 0 : _statics$logo.path) === staticPath) {
        if (!('data' in statics.logo)) {
          return {
            ok: false,
            error: new Error('Localized config missing static data')
          };
        }
        return {
          ok: true,
          value: Buffer.from(statics.logo.data, 'base64')
        };
      }
      if ((statics === null || statics === void 0 || (_statics$darkModeLogo = statics.darkModeLogo) === null || _statics$darkModeLogo === void 0 ? void 0 : _statics$darkModeLogo.path) === staticPath) {
        if (!('data' in statics.darkModeLogo)) {
          return {
            ok: false,
            error: new Error('Localized config missing static data')
          };
        }
        return {
          ok: true,
          value: Buffer.from(statics.darkModeLogo.data, 'base64')
        };
      }
      for (const iterStatic of [...((_statics$gallery = statics === null || statics === void 0 ? void 0 : statics.gallery) !== null && _statics$gallery !== void 0 ? _statics$gallery : []), ...((_statics$darkModeGall = statics === null || statics === void 0 ? void 0 : statics.darkModeGallery) !== null && _statics$darkModeGall !== void 0 ? _statics$darkModeGall : [])]) {
        var _statics$gallery, _statics$darkModeGall;
        if (iterStatic.path === staticPath) {
          if (!('data' in iterStatic)) {
            return {
              ok: false,
              error: new Error('Localized config missing static data')
            };
          }
          return {
            ok: true,
            value: Buffer.from(iterStatic.data, 'base64')
          };
        }
      }
    }
    return {
      ok: false,
      error: new Error(`Static not found: ${staticPath}`, {
        code: 'ENOENT'
      })
    };
  }
  async serializeStaticAsset(asset) {
    const data = await this.getStatic(asset.path);
    if (!data.ok) {
      return data;
    }
    return {
      ok: true,
      value: {
        ...asset,
        data: data.value.toString('base64')
      }
    };
  }
  async serializeStatics(statics) {
    const serialized = {};
    if (statics.logo) {
      const serializeResult = await this.serializeStaticAsset(statics.logo);
      serialized.logo = serializeResult.value;
    }
    if (statics.darkModeLogo) {
      const serializeResult = await this.serializeStaticAsset(statics.darkModeLogo);
      serialized.darkModeLogo = serializeResult.value;
    }
    if (statics.gallery) {
      const results = await Promise.all(statics.gallery.map(asset => this.serializeStaticAsset(asset)));
      const foldedResult = (0, _utils.foldResults)(results);
      serialized.gallery = foldedResult.value;
    }
    if (statics.darkModeGallery) {
      const results = await Promise.all(statics.darkModeGallery.map(asset => this.serializeStaticAsset(asset)));
      const foldedResult = (0, _utils.foldResults)(results);
      serialized.darkModeGallery = foldedResult.value;
    }
    return {
      ok: true,
      value: serialized
    };
  }

  /**
   * Serialize the referenced integration as a flat JSON object.
   * Useful for normalizing the format for sending to other locations.
   * This method implements the serialization scheme expected by `JsonCatalogDataAdaptor`.
   *
   * @param version The version of the integration to serialize.
   * @returns A large object which includes all of the integration's data.
   */
  async serialize(version) {
    const configResult = await this.getRawConfig(version);
    if (!configResult.ok) {
      return configResult;
    }

    // Type cast safety: all serializable properties must have the 'data' field.
    // The remainder of the method is populating all such fields.
    const config = configResult.value;
    const componentResults = await Promise.all(config.components.map(component => this.fetchDataOrReadFile(component, {
      filename: `${component.name}-${component.version}.mapping.json`,
      type: 'schemas'
    }, 'json')));
    const componentsResult = (0, _utils.foldResults)(componentResults);
    if (!componentsResult.ok) {
      return componentsResult;
    }
    config.components = config.components.map((component, idx) => {
      return {
        ...component,
        data: JSON.stringify(componentsResult.value[idx])
      };
    });
    if (config.assets.savedObjects) {
      const soMetadata = config.assets.savedObjects;
      const soResult = await this.fetchDataOrReadFile(config.assets.savedObjects, {
        filename: `${soMetadata.name}-${soMetadata.version}.ndjson`,
        type: 'assets'
      }, 'json');
      if (!soResult.ok) {
        return soResult;
      }
      config.assets.savedObjects = {
        ...soMetadata,
        data: JSON.stringify(soResult.value)
      };
    }
    if (config.assets.queries) {
      const queryResults = await Promise.all(config.assets.queries.map(query => this.fetchDataOrReadFile(query, {
        filename: `${query.name}-${query.version}.${query.language}`,
        type: 'assets'
      }, 'binary')));
      const queriesResult = (0, _utils.foldResults)(queryResults);
      if (!queriesResult.ok) {
        return queriesResult;
      }
      config.assets.queries = config.assets.queries.map((query, idx) => {
        return {
          ...query,
          data: JSON.stringify(queriesResult.value[idx].toString('utf8'))
        };
      });
    }
    if (config.statics) {
      const staticsResult = await this.serializeStatics(config.statics);
      if (!staticsResult.ok) {
        return staticsResult;
      }
      config.statics = staticsResult.value;
    }
    if (config.sampleData) {
      const dataResult = await this.getSampleData(version);
      if (!dataResult.ok) {
        return dataResult;
      }
      config.sampleData = {
        ...config.sampleData,
        data: JSON.stringify(dataResult.value.sampleData)
      };
    }
    return {
      ok: true,
      value: config
    };
  }
}
exports.IntegrationReader = IntegrationReader;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGF0aCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX3NlbXZlciIsIl92YWxpZGF0b3JzIiwiX2ZzX2RhdGFfYWRhcHRvciIsIl91dGlscyIsIm9iaiIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiX2RlZmluZVByb3BlcnR5Iiwia2V5IiwidmFsdWUiLCJfdG9Qcm9wZXJ0eUtleSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSIsIndyaXRhYmxlIiwiYXJnIiwiX3RvUHJpbWl0aXZlIiwiU3RyaW5nIiwiaW5wdXQiLCJoaW50IiwicHJpbSIsIlN5bWJvbCIsInRvUHJpbWl0aXZlIiwidW5kZWZpbmVkIiwicmVzIiwiY2FsbCIsIlR5cGVFcnJvciIsIk51bWJlciIsIkludGVncmF0aW9uUmVhZGVyIiwiY29uc3RydWN0b3IiLCJkaXJlY3RvcnkiLCJyZWFkZXIiLCJuYW1lIiwicGF0aCIsImJhc2VuYW1lIiwiRmlsZVN5c3RlbUNhdGFsb2dEYXRhQWRhcHRvciIsImZldGNoRGF0YU9yUmVhZEZpbGUiLCJpdGVtIiwiZmlsZVBhcmFtcyIsImZvcm1hdCIsImlzQ29uZmlnTG9jYWxpemVkIiwiZGF0YSIsIm9rIiwiZXJyb3IiLCJFcnJvciIsIkpTT04iLCJzdHJpbmdpZnkiLCJwYXJzZSIsIkJ1ZmZlciIsImZyb20iLCJyZWFkRmlsZSIsImZpbGVuYW1lIiwidHlwZSIsInJlYWRGaWxlUmF3IiwiZ2V0TGF0ZXN0VmVyc2lvbiIsInZlcnNpb25zIiwiZmluZEludGVncmF0aW9uVmVyc2lvbnMiLCJsZW5ndGgiLCJzb3J0Iiwic2VtdmVyIiwicmNvbXBhcmUiLCJnZXRSYXdDb25maWciLCJ2ZXJzaW9uIiwiZ2V0RGlyZWN0b3J5VHlwZSIsIm1heWJlVmVyc2lvbiIsImNvbmZpZ0ZpbGUiLCJjb25maWciLCJ2YWxpZGF0ZVRlbXBsYXRlIiwiZ2V0Q29uZmlnIiwibWF5YmVDb25maWciLCJwcnVuZUNvbmZpZyIsImdldFF1ZXJpZXMiLCJxdWVyaWVzTGlzdCIsInF1ZXJpZXMiLCJQcm9taXNlIiwiYWxsIiwibWFwIiwicXVlcnkiLCJsYW5ndWFnZSIsInRvU3RyaW5nIiwiZm9sZFJlc3VsdHMiLCJnZXRBc3NldHMiLCJjb25maWdSZXN1bHQiLCJyZXN1bHRWYWx1ZSIsImFzc2V0cyIsInNhdmVkT2JqZWN0cyIsImdldFNhbXBsZURhdGEiLCJzYW1wbGVEYXRhIiwianNvbkNvbnRlbnQiLCJuZXdUaW1lIiwiRGF0ZSIsIm5vdyIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsInRvSVNPU3RyaW5nIiwiYXNzaWduIiwib2JzZXJ2ZWRUaW1lc3RhbXAiLCJnZXRTY2hlbWFzIiwibWFwcGluZ3MiLCJjb21wb25lbnQiLCJjb21wb25lbnRzIiwic2NoZW1hRmlsZSIsInNjaGVtYSIsImdldFN0YXRpYyIsInN0YXRpY1BhdGgiLCJfc3RhdGljcyRsb2dvIiwiX3N0YXRpY3MkZGFya01vZGVMb2dvIiwic3RhdGljcyIsImxvZ28iLCJkYXJrTW9kZUxvZ28iLCJpdGVyU3RhdGljIiwiX3N0YXRpY3MkZ2FsbGVyeSIsImdhbGxlcnkiLCJfc3RhdGljcyRkYXJrTW9kZUdhbGwiLCJkYXJrTW9kZUdhbGxlcnkiLCJjb2RlIiwic2VyaWFsaXplU3RhdGljQXNzZXQiLCJhc3NldCIsInNlcmlhbGl6ZVN0YXRpY3MiLCJzZXJpYWxpemVkIiwic2VyaWFsaXplUmVzdWx0IiwicmVzdWx0cyIsImZvbGRlZFJlc3VsdCIsInNlcmlhbGl6ZSIsImNvbXBvbmVudFJlc3VsdHMiLCJjb21wb25lbnRzUmVzdWx0IiwiaWR4Iiwic29NZXRhZGF0YSIsInNvUmVzdWx0IiwicXVlcnlSZXN1bHRzIiwicXVlcmllc1Jlc3VsdCIsInN0YXRpY3NSZXN1bHQiLCJkYXRhUmVzdWx0IiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbImludGVncmF0aW9uX3JlYWRlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHNlbXZlciBmcm9tICdzZW12ZXInO1xuaW1wb3J0IHsgdmFsaWRhdGVUZW1wbGF0ZSB9IGZyb20gJy4uL3ZhbGlkYXRvcnMnO1xuaW1wb3J0IHsgRmlsZVN5c3RlbUNhdGFsb2dEYXRhQWRhcHRvciB9IGZyb20gJy4vZnNfZGF0YV9hZGFwdG9yJztcbmltcG9ydCB7IENhdGFsb2dEYXRhQWRhcHRvciwgSW50ZWdyYXRpb25QYXJ0IH0gZnJvbSAnLi9jYXRhbG9nX2RhdGFfYWRhcHRvcic7XG5pbXBvcnQgeyBmb2xkUmVzdWx0cywgcHJ1bmVDb25maWcgfSBmcm9tICcuL3V0aWxzJztcblxuLyoqXG4gKiBUaGUgSW50ZWdyYXRpb24gY2xhc3MgcmVwcmVzZW50cyB0aGUgZGF0YSBmb3IgSW50ZWdyYXRpb24gVGVtcGxhdGVzLlxuICogSXQgaXMgYmFja2VkIGJ5IHRoZSByZXBvc2l0b3J5IGZpbGUgc3lzdGVtLlxuICogSXQgaW5jbHVkZXMgYWNjZXNzb3IgbWV0aG9kcyBmb3IgaW50ZWdyYXRpb24gY29uZmlncywgYXMgd2VsbCBhcyBoZWxwZXJzIGZvciBuZXN0ZWQgY29tcG9uZW50cy5cbiAqL1xuZXhwb3J0IGNsYXNzIEludGVncmF0aW9uUmVhZGVyIHtcbiAgcmVhZGVyOiBDYXRhbG9nRGF0YUFkYXB0b3I7XG4gIGRpcmVjdG9yeTogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoZGlyZWN0b3J5OiBzdHJpbmcsIHJlYWRlcj86IENhdGFsb2dEYXRhQWRhcHRvcikge1xuICAgIHRoaXMuZGlyZWN0b3J5ID0gZGlyZWN0b3J5O1xuICAgIHRoaXMubmFtZSA9IHBhdGguYmFzZW5hbWUoZGlyZWN0b3J5KTtcbiAgICB0aGlzLnJlYWRlciA9IHJlYWRlciA/PyBuZXcgRmlsZVN5c3RlbUNhdGFsb2dEYXRhQWRhcHRvcihkaXJlY3RvcnkpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIGRhdGEgZnJvbSBjb3JyZWN0IHNvdXJjZSByZWdhcmRsZXNzIG9mIGlmIHJlYWRlciBpcyBjb25maWctbG9jYWxpemVkIG9yIG5vdC5cbiAgICpcbiAgICogVE9ETyByZWZhY3RvciB0byBhc3NlbWJsZSBmaWxlbmFtZSBmcm9tIGB0eXBlYCBpbnN0ZWFkIG9mIHJlcXVpcmluZyBjYWxsZXIgdG8gZm9ybWF0IGl0LlxuICAgKlxuICAgKiBAcGFyYW0gaXRlbSBBbiBpdGVtIHdoaWNoIG1heSBoYXZlIGRhdGEgaW4gaXQuXG4gICAqIEBwYXJhbSBmaWxlUGFyYW1zIEluZm9ybWF0aW9uIGFib3V0IHRoZSBmaWxlIHRvIHJlYWQgaWYgdGhlIGNvbmZpZyBpcyBub3QgbG9jYWxpemVkLlxuICAgKiBAcGFyYW0gZm9ybWF0IEhvdyB0byBwYWNrYWdlIHRoZSByZXR1cm5lZCBkYXRhLlxuICAgKiAgICAgICAgICAgICAgIElmICdqc29uJywgcmV0dXJuIGBvYmplY3QgfCBvYmplY3RbXWAuIElmICdiaW5hcnknLCByZXR1cm4gYEJ1ZmZlcmAuXG4gICAqIEByZXR1cm5zIEEgcmVzdWx0IHdpdGggdGhlIGRhdGEsIHdpdGggYSBmb3JtYXQgYmFzZWQgb24gdGhlIGZvcm1hdCBmaWVsZC5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgZmV0Y2hEYXRhT3JSZWFkRmlsZShcbiAgICBpdGVtOiB7IGRhdGE/OiBzdHJpbmcgfSxcbiAgICBmaWxlUGFyYW1zOiB7IGZpbGVuYW1lOiBzdHJpbmc7IHR5cGU/OiBJbnRlZ3JhdGlvblBhcnQgfSxcbiAgICBmb3JtYXQ6ICdqc29uJ1xuICApOiBQcm9taXNlPFJlc3VsdDxvYmplY3QgfCBvYmplY3RbXT4+O1xuICBwcml2YXRlIGFzeW5jIGZldGNoRGF0YU9yUmVhZEZpbGUoXG4gICAgaXRlbTogeyBkYXRhPzogc3RyaW5nIH0sXG4gICAgZmlsZVBhcmFtczogeyBmaWxlbmFtZTogc3RyaW5nOyB0eXBlPzogSW50ZWdyYXRpb25QYXJ0IH0sXG4gICAgZm9ybWF0OiAnYmluYXJ5J1xuICApOiBQcm9taXNlPFJlc3VsdDxCdWZmZXI+PjtcbiAgcHJpdmF0ZSBhc3luYyBmZXRjaERhdGFPclJlYWRGaWxlKFxuICAgIGl0ZW06IHsgZGF0YT86IHN0cmluZyB9LFxuICAgIGZpbGVQYXJhbXM6IHsgZmlsZW5hbWU6IHN0cmluZzsgdHlwZT86IEludGVncmF0aW9uUGFydCB9LFxuICAgIGZvcm1hdDogJ2pzb24nIHwgJ2JpbmFyeSdcbiAgKTogUHJvbWlzZTxSZXN1bHQ8b2JqZWN0IHwgb2JqZWN0W10gfCBCdWZmZXI+PiB7XG4gICAgaWYgKHRoaXMucmVhZGVyLmlzQ29uZmlnTG9jYWxpemVkKSB7XG4gICAgICBpZiAoIWl0ZW0uZGF0YSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjogbmV3IEVycm9yKFxuICAgICAgICAgICAgJ1RoZSBjb25maWcgZm9yIHRoZSBwcm92aWRlZCByZWFkZXIgaXMgbG9jYWxpemVkLCBidXQgbm8gZGF0YSBmaWVsZCBpcyBwcmVzZW50LiAnICtcbiAgICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoaXRlbSlcbiAgICAgICAgICApLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2pzb24nKSB7XG4gICAgICAgICAgcmV0dXJuIHsgb2s6IHRydWUsIHZhbHVlOiBKU09OLnBhcnNlKGl0ZW0uZGF0YSkgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IEJ1ZmZlci5mcm9tKGl0ZW0uZGF0YSwgJ2Jhc2U2NCcpIH07XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3IgfTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoZm9ybWF0ID09PSAnanNvbicpIHtcbiAgICAgIHJldHVybiB0aGlzLnJlYWRlci5yZWFkRmlsZShmaWxlUGFyYW1zLmZpbGVuYW1lLCBmaWxlUGFyYW1zLnR5cGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdGhpcy5yZWFkZXIucmVhZEZpbGVSYXcoZmlsZVBhcmFtcy5maWxlbmFtZSwgZmlsZVBhcmFtcy50eXBlKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR2V0IHRoZSBsYXRlc3QgdmVyc2lvbiBvZiB0aGUgaW50ZWdyYXRpb24gYXZhaWxhYmxlLlxuICAgKiBUaGlzIG1ldGhvZCByZWxpZXMgb24gdGhlIGZhY3QgdGhhdCBpbnRlZ3JhdGlvbiBjb25maWdzIGhhdmUgdGhlaXIgdmVyc2lvbnMgaW4gdGhlaXIgbmFtZS5cbiAgICogQW55IGZpbGVzIHRoYXQgZG9uJ3QgbWF0Y2ggdGhlIGNvbmZpZyBuYW1pbmcgY29udmVudGlvbiB3aWxsIGJlIGlnbm9yZWQuXG4gICAqXG4gICAqIEByZXR1cm5zIEEgc3RyaW5nIHdpdGggdGhlIGxhdGVzdCB2ZXJzaW9uLCBvciBudWxsIGlmIG5vIHZlcnNpb25zIGFyZSBhdmFpbGFibGUuXG4gICAqL1xuICBhc3luYyBnZXRMYXRlc3RWZXJzaW9uKCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IHZlcnNpb25zID0gYXdhaXQgdGhpcy5yZWFkZXIuZmluZEludGVncmF0aW9uVmVyc2lvbnMoKTtcbiAgICBpZiAoIXZlcnNpb25zLm9rKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKHZlcnNpb25zLnZhbHVlLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIC8vIFNvcnQgZGVzY2VuZGluZ1xuICAgIHZlcnNpb25zLnZhbHVlLnNvcnQoc2VtdmVyLnJjb21wYXJlKTtcbiAgICByZXR1cm4gdmVyc2lvbnMudmFsdWVbMF07XG4gIH1cblxuICAvLyBHZXQgY29uZmlnIHdpdGhvdXQgcHJ1bmluZyBvciB2YWxpZGF0aW9uLlxuICBwcml2YXRlIGFzeW5jIGdldFJhd0NvbmZpZyhcbiAgICB2ZXJzaW9uPzogc3RyaW5nXG4gICk6IFByb21pc2U8UmVzdWx0PEludGVncmF0aW9uQ29uZmlnIHwgU2VyaWFsaXplZEludGVncmF0aW9uPj4ge1xuICAgIGlmICgoYXdhaXQgdGhpcy5yZWFkZXIuZ2V0RGlyZWN0b3J5VHlwZSgpKSAhPT0gJ2ludGVncmF0aW9uJykge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICBlcnJvcjogbmV3IEVycm9yKGAke3RoaXMuZGlyZWN0b3J5fSBpcyBub3QgYSB2YWxpZCBpbnRlZ3JhdGlvbiBkaXJlY3RvcnlgKSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc3QgbWF5YmVWZXJzaW9uOiBzdHJpbmcgfCBudWxsID0gdmVyc2lvbiA/IHZlcnNpb24gOiBhd2FpdCB0aGlzLmdldExhdGVzdFZlcnNpb24oKTtcblxuICAgIGlmIChtYXliZVZlcnNpb24gPT09IG51bGwpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IG5ldyBFcnJvcihgTm8gdmFsaWQgY29uZmlnIG1hdGNoaW5nIHZlcnNpb24gJHt2ZXJzaW9ufSBpcyBhdmFpbGFibGVgKSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc3QgY29uZmlnRmlsZSA9IGAke3RoaXMubmFtZX0tJHttYXliZVZlcnNpb259Lmpzb25gO1xuXG4gICAgLy8gRXZlbiBjb25maWctbG9jYWxpemVkIHJlYWRlcnMgbXVzdCBzdXBwb3J0IGNvbmZpZy1yZWFkLlxuICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IHRoaXMucmVhZGVyLnJlYWRGaWxlKGNvbmZpZ0ZpbGUpO1xuICAgIGlmICghY29uZmlnLm9rKSB7XG4gICAgICByZXR1cm4gY29uZmlnO1xuICAgIH1cbiAgICByZXR1cm4gdmFsaWRhdGVUZW1wbGF0ZShjb25maWcudmFsdWUpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCB0aGUgY29uZmlndXJhdGlvbiBvZiB0aGUgY3VycmVudCBpbnRlZ3JhdGlvbi5cbiAgICpcbiAgICogQHBhcmFtIHZlcnNpb24gVGhlIHZlcnNpb24gb2YgdGhlIGNvbmZpZyB0byByZXRyaWV2ZS5cbiAgICogQHJldHVybnMgVGhlIGNvbmZpZyBpZiBhIHZhbGlkIGNvbmZpZyBtYXRjaGluZyB0aGUgdmVyc2lvbiBpcyBwcmVzZW50LCBvdGhlcndpc2UgbnVsbC5cbiAgICovXG4gIGFzeW5jIGdldENvbmZpZyh2ZXJzaW9uPzogc3RyaW5nKTogUHJvbWlzZTxSZXN1bHQ8SW50ZWdyYXRpb25Db25maWc+PiB7XG4gICAgY29uc3QgbWF5YmVDb25maWcgPSBhd2FpdCB0aGlzLmdldFJhd0NvbmZpZyh2ZXJzaW9uKTtcbiAgICBpZiAoIW1heWJlQ29uZmlnLm9rKSB7XG4gICAgICByZXR1cm4gbWF5YmVDb25maWc7XG4gICAgfVxuICAgIHJldHVybiB2YWxpZGF0ZVRlbXBsYXRlKHBydW5lQ29uZmlnKG1heWJlQ29uZmlnLnZhbHVlKSk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGdldFF1ZXJpZXMoXG4gICAgcXVlcmllc0xpc3Q6IEFycmF5PHsgbmFtZTogc3RyaW5nOyB2ZXJzaW9uOiBzdHJpbmc7IGxhbmd1YWdlOiBzdHJpbmc7IGRhdGE/OiBzdHJpbmcgfT5cbiAgKTogUHJvbWlzZTxSZXN1bHQ8QXJyYXk8eyBsYW5ndWFnZTogc3RyaW5nOyBxdWVyeTogc3RyaW5nIH0+Pj4ge1xuICAgIGNvbnN0IHF1ZXJpZXMgPSBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgIHF1ZXJpZXNMaXN0Lm1hcChhc3luYyAoaXRlbSkgPT4ge1xuICAgICAgICBjb25zdCBxdWVyeSA9IGF3YWl0IHRoaXMuZmV0Y2hEYXRhT3JSZWFkRmlsZShcbiAgICAgICAgICBpdGVtLFxuICAgICAgICAgIHsgZmlsZW5hbWU6IGAke2l0ZW0ubmFtZX0tJHtpdGVtLnZlcnNpb259LiR7aXRlbS5sYW5ndWFnZX1gLCB0eXBlOiAnYXNzZXRzJyB9LFxuICAgICAgICAgICdiaW5hcnknXG4gICAgICAgICk7XG4gICAgICAgIGlmICghcXVlcnkub2spIHtcbiAgICAgICAgICByZXR1cm4gcXVlcnk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBvazogdHJ1ZSBhcyBjb25zdCxcbiAgICAgICAgICB2YWx1ZToge1xuICAgICAgICAgICAgbGFuZ3VhZ2U6IGl0ZW0ubGFuZ3VhZ2UsXG4gICAgICAgICAgICBxdWVyeTogcXVlcnkudmFsdWUudG9TdHJpbmcoJ3V0ZjgnKSxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgfSlcbiAgICApO1xuICAgIHJldHVybiBmb2xkUmVzdWx0cyhxdWVyaWVzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSBhc3NldHMgYXNzb2NpYXRlZCB3aXRoIHRoZSBpbnRlZ3JhdGlvbi5cbiAgICogVGhpcyBtZXRob2QgZ3JlZWRpbHkgcmV0cmlldmVzIGFsbCBhc3NldHMuXG4gICAqIElmIHRoZSB2ZXJzaW9uIGlzIGludmFsaWQsIGFuIGVycm9yIGlzIHRocm93bi5cbiAgICogSWYgYW4gYXNzZXQgaXMgaW52YWxpZCwgaXQgd2lsbCBiZSBza2lwcGVkLlxuICAgKlxuICAgKiBAcGFyYW0gdmVyc2lvbiBUaGUgdmVyc2lvbiBvZiB0aGUgaW50ZWdyYXRpb24gdG8gcmV0cmlldmUgYXNzZXRzIGZvci5cbiAgICogQHJldHVybnMgQW4gb2JqZWN0IGNvbnRhaW5pbmcgdGhlIGRpZmZlcmVudCB0eXBlcyBvZiBhc3NldHMuXG4gICAqL1xuICBhc3luYyBnZXRBc3NldHMoXG4gICAgdmVyc2lvbj86IHN0cmluZ1xuICApOiBQcm9taXNlPFxuICAgIFJlc3VsdDx7XG4gICAgICBzYXZlZE9iamVjdHM/OiBvYmplY3RbXTtcbiAgICAgIHF1ZXJpZXM/OiBBcnJheTx7XG4gICAgICAgIHF1ZXJ5OiBzdHJpbmc7XG4gICAgICAgIGxhbmd1YWdlOiBzdHJpbmc7XG4gICAgICB9PjtcbiAgICB9PlxuICA+IHtcbiAgICBjb25zdCBjb25maWdSZXN1bHQgPSBhd2FpdCB0aGlzLmdldFJhd0NvbmZpZyh2ZXJzaW9uKTtcbiAgICBpZiAoIWNvbmZpZ1Jlc3VsdC5vaykge1xuICAgICAgcmV0dXJuIGNvbmZpZ1Jlc3VsdDtcbiAgICB9XG4gICAgY29uc3QgY29uZmlnID0gY29uZmlnUmVzdWx0LnZhbHVlO1xuXG4gICAgY29uc3QgcmVzdWx0VmFsdWU6IHtcbiAgICAgIHNhdmVkT2JqZWN0cz86IG9iamVjdFtdO1xuICAgICAgcXVlcmllcz86IEFycmF5PHsgcXVlcnk6IHN0cmluZzsgbGFuZ3VhZ2U6IHN0cmluZyB9PjtcbiAgICB9ID0ge307XG4gICAgaWYgKGNvbmZpZy5hc3NldHMuc2F2ZWRPYmplY3RzKSB7XG4gICAgICBjb25zdCBhc3NldHMgPSBhd2FpdCB0aGlzLmZldGNoRGF0YU9yUmVhZEZpbGUoXG4gICAgICAgIGNvbmZpZy5hc3NldHMuc2F2ZWRPYmplY3RzIGFzIHsgZGF0YT86IHN0cmluZyB9LFxuICAgICAgICB7XG4gICAgICAgICAgZmlsZW5hbWU6IGAke2NvbmZpZy5hc3NldHMuc2F2ZWRPYmplY3RzLm5hbWV9LSR7Y29uZmlnLmFzc2V0cy5zYXZlZE9iamVjdHMudmVyc2lvbn0ubmRqc29uYCxcbiAgICAgICAgICB0eXBlOiAnYXNzZXRzJyxcbiAgICAgICAgfSxcbiAgICAgICAgJ2pzb24nXG4gICAgICApO1xuICAgICAgaWYgKCFhc3NldHMub2spIHtcbiAgICAgICAgcmV0dXJuIGFzc2V0cztcbiAgICAgIH1cbiAgICAgIHJlc3VsdFZhbHVlLnNhdmVkT2JqZWN0cyA9IGFzc2V0cy52YWx1ZSBhcyBvYmplY3RbXTtcbiAgICB9XG4gICAgaWYgKGNvbmZpZy5hc3NldHMucXVlcmllcykge1xuICAgICAgY29uc3QgcXVlcmllcyA9IGF3YWl0IHRoaXMuZ2V0UXVlcmllcyhjb25maWcuYXNzZXRzLnF1ZXJpZXMpO1xuICAgICAgaWYgKCFxdWVyaWVzLm9rKSB7XG4gICAgICAgIHJldHVybiBxdWVyaWVzO1xuICAgICAgfVxuICAgICAgcmVzdWx0VmFsdWUucXVlcmllcyA9IHF1ZXJpZXMudmFsdWU7XG4gICAgfVxuICAgIHJldHVybiB7IG9rOiB0cnVlLCB2YWx1ZTogcmVzdWx0VmFsdWUgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSBzYW1wbGUgZGF0YSBhc3NvY2lhdGVkIHdpdGggdGhlIGludGVncmF0aW9uLlxuICAgKiBJZiB0aGUgdmVyc2lvbiBpcyBpbnZhbGlkLCBhbiBlcnJvciBpcyB0aHJvd24uXG4gICAqIElmIHRoZSBzYW1wbGUgZGF0YSBpcyBpbnZhbGlkLCBudWxsIHdpbGwgYmUgcmV0dXJuZWRcbiAgICpcbiAgICogQHBhcmFtIHZlcnNpb24gVGhlIHZlcnNpb24gb2YgdGhlIGludGVncmF0aW9uIHRvIHJldHJpZXZlIGFzc2V0cyBmb3IuXG4gICAqIEByZXR1cm5zIEFuIG9iamVjdCBjb250YWluaW5nIGEgbGlzdCBvZiBzYW1wbGUgZGF0YSB3aXRoIGFkanVzdGVkIHRpbWVzdGFtcHMuXG4gICAqL1xuICBhc3luYyBnZXRTYW1wbGVEYXRhKFxuICAgIHZlcnNpb24/OiBzdHJpbmdcbiAgKTogUHJvbWlzZTxcbiAgICBSZXN1bHQ8e1xuICAgICAgc2FtcGxlRGF0YTogb2JqZWN0W10gfCBudWxsO1xuICAgIH0+XG4gID4ge1xuICAgIGNvbnN0IGNvbmZpZ1Jlc3VsdCA9IGF3YWl0IHRoaXMuZ2V0UmF3Q29uZmlnKHZlcnNpb24pO1xuICAgIGlmICghY29uZmlnUmVzdWx0Lm9rKSB7XG4gICAgICByZXR1cm4gY29uZmlnUmVzdWx0O1xuICAgIH1cbiAgICBjb25zdCBjb25maWcgPSBjb25maWdSZXN1bHQudmFsdWU7XG5cbiAgICBjb25zdCByZXN1bHRWYWx1ZTogeyBzYW1wbGVEYXRhOiBvYmplY3RbXSB8IG51bGwgfSA9IHsgc2FtcGxlRGF0YTogbnVsbCB9O1xuICAgIGlmIChjb25maWcuc2FtcGxlRGF0YSkge1xuICAgICAgY29uc3QganNvbkNvbnRlbnQ6IFJlc3VsdDxvYmplY3QgfCBvYmplY3RbXT4gPSBhd2FpdCB0aGlzLmZldGNoRGF0YU9yUmVhZEZpbGUoXG4gICAgICAgIGNvbmZpZy5zYW1wbGVEYXRhIGFzIHsgZGF0YT86IHN0cmluZyB9LFxuICAgICAgICB7IGZpbGVuYW1lOiBjb25maWcuc2FtcGxlRGF0YS5wYXRoLCB0eXBlOiAnZGF0YScgfSxcbiAgICAgICAgJ2pzb24nXG4gICAgICApO1xuICAgICAgaWYgKCFqc29uQ29udGVudC5vaykge1xuICAgICAgICByZXR1cm4ganNvbkNvbnRlbnQ7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGpzb25Db250ZW50LnZhbHVlIGFzIG9iamVjdFtdKSB7XG4gICAgICAgIGlmICghKCdAdGltZXN0YW1wJyBpbiB2YWx1ZSkpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBSYW5kb21seSBzY2F0dGVyIHRpbWVzdGFtcHMgYWNyb3NzIGxhc3QgMTAgbWludXRlc1xuICAgICAgICAvLyBBc3N1bWUgZm9yIG5vdyB0aGF0IHRoZSBvcmRlcmluZyBvZiBldmVudHMgaXNuJ3QgaW1wb3J0YW50LCBjYW4gY2hhbmdlIHRvIGEgc2VxdWVuY2UgaWYgbmVlZGVkXG4gICAgICAgIC8vIEFsc28gZG9lc24ndCBoYW5kbGUgZmllbGRzIGxpa2UgYG9ic2VydmVkVGltZXN0YW1wYCBpZiBwcmVzZW50XG4gICAgICAgIGNvbnN0IG5ld1RpbWUgPSBuZXcgRGF0ZShcbiAgICAgICAgICBEYXRlLm5vdygpIC0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTAwMCAqIDYwICogMTApXG4gICAgICAgICkudG9JU09TdHJpbmcoKTtcbiAgICAgICAgT2JqZWN0LmFzc2lnbih2YWx1ZSwgeyAnQHRpbWVzdGFtcCc6IG5ld1RpbWUgfSk7XG4gICAgICAgIGlmICgnb2JzZXJ2ZWRUaW1lc3RhbXAnIGluIHZhbHVlKSB7XG4gICAgICAgICAgT2JqZWN0LmFzc2lnbih2YWx1ZSwgeyBvYnNlcnZlZFRpbWVzdGFtcDogbmV3VGltZSB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzdWx0VmFsdWUuc2FtcGxlRGF0YSA9IGpzb25Db250ZW50LnZhbHVlIGFzIG9iamVjdFtdO1xuICAgIH1cbiAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IHJlc3VsdFZhbHVlIH07XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgc2NoZW1hIGRhdGEgYXNzb2NpYXRlZCB3aXRoIHRoZSBpbnRlZ3JhdGlvbi5cbiAgICogVGhpcyBtZXRob2QgZ3JlZWRpbHkgcmV0cmlldmVzIGFsbCBtYXBwaW5ncyBhbmQgc2NoZW1hcy5cbiAgICogSXQncyBhc3N1bWVkIHRoYXQgYSB2YWxpZCB2ZXJzaW9uIHdpbGwgYmUgcHJvdmlkZWQuXG4gICAqIElmIHRoZSB2ZXJzaW9uIGlzIGludmFsaWQsIGFuIGVycm9yIGlzIHRocm93bi5cbiAgICogSWYgYSBzY2hlbWEgaXMgaW52YWxpZCwgYW4gZXJyb3Igd2lsbCBiZSB0aHJvd24uXG4gICAqXG4gICAqIEBwYXJhbSB2ZXJzaW9uIFRoZSB2ZXJzaW9uIG9mIHRoZSBpbnRlZ3JhdGlvbiB0byByZXRyaWV2ZSBhc3NldHMgZm9yLlxuICAgKiBAcmV0dXJucyBBbiBvYmplY3QgY29udGFpbmluZyB0aGUgZGlmZmVyZW50IHR5cGVzIG9mIGFzc2V0cy5cbiAgICovXG4gIGFzeW5jIGdldFNjaGVtYXMoXG4gICAgdmVyc2lvbj86IHN0cmluZ1xuICApOiBQcm9taXNlPFxuICAgIFJlc3VsdDx7XG4gICAgICBtYXBwaW5nczogeyBba2V5OiBzdHJpbmddOiB1bmtub3duIH07XG4gICAgfT5cbiAgPiB7XG4gICAgY29uc3QgY29uZmlnUmVzdWx0ID0gYXdhaXQgdGhpcy5nZXRSYXdDb25maWcodmVyc2lvbik7XG4gICAgaWYgKCFjb25maWdSZXN1bHQub2spIHtcbiAgICAgIHJldHVybiBjb25maWdSZXN1bHQ7XG4gICAgfVxuICAgIGNvbnN0IGNvbmZpZyA9IGNvbmZpZ1Jlc3VsdC52YWx1ZTtcblxuICAgIGNvbnN0IHJlc3VsdFZhbHVlOiB7IG1hcHBpbmdzOiB7IFtrZXk6IHN0cmluZ106IG9iamVjdCB9IH0gPSB7XG4gICAgICBtYXBwaW5nczoge30sXG4gICAgfTtcbiAgICBmb3IgKGNvbnN0IGNvbXBvbmVudCBvZiBjb25maWcuY29tcG9uZW50cykge1xuICAgICAgY29uc3Qgc2NoZW1hRmlsZSA9IGAke2NvbXBvbmVudC5uYW1lfS0ke2NvbXBvbmVudC52ZXJzaW9ufS5tYXBwaW5nLmpzb25gO1xuICAgICAgY29uc3Qgc2NoZW1hID0gYXdhaXQgdGhpcy5mZXRjaERhdGFPclJlYWRGaWxlKFxuICAgICAgICBjb21wb25lbnQgYXMgeyBkYXRhPzogc3RyaW5nIH0sXG4gICAgICAgIHsgZmlsZW5hbWU6IHNjaGVtYUZpbGUsIHR5cGU6ICdzY2hlbWFzJyB9LFxuICAgICAgICAnanNvbidcbiAgICAgICk7XG4gICAgICBpZiAoIXNjaGVtYS5vaykge1xuICAgICAgICByZXR1cm4gc2NoZW1hO1xuICAgICAgfVxuICAgICAgcmVzdWx0VmFsdWUubWFwcGluZ3NbY29tcG9uZW50Lm5hbWVdID0gc2NoZW1hLnZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IHJlc3VsdFZhbHVlIH07XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmVzIHRoZSBkYXRhIGZvciBhIHN0YXRpYyBmaWxlIGFzc29jaWF0ZWQgd2l0aCB0aGUgaW50ZWdyYXRpb24uXG4gICAqXG4gICAqIEBwYXJhbSBzdGF0aWNQYXRoIFRoZSBwYXRoIG9mIHRoZSBzdGF0aWMgdG8gcmV0cmlldmUuXG4gICAqIEByZXR1cm5zIEEgYnVmZmVyIHdpdGggdGhlIHN0YXRpYydzIGRhdGEgaWYgcHJlc2VudCwgb3RoZXJ3aXNlIG51bGwuXG4gICAqL1xuICBhc3luYyBnZXRTdGF0aWMoc3RhdGljUGF0aDogc3RyaW5nKTogUHJvbWlzZTxSZXN1bHQ8QnVmZmVyPj4ge1xuICAgIC8vIFN0YXRpY3Mgd2VyZSBvcmlnaW5hbGx5IGRlc2lnbmVkIHRvIHJlYWQgc3RyYWlnaHQgZnJvbSBmaWxlIHN5c3RlbSxcbiAgICAvLyBzbyB3ZSB1c2UgZGlyZWN0IGFjY2VzcyBpZiBwb3NzaWJsZS5cbiAgICBpZiAoIXRoaXMucmVhZGVyLmlzQ29uZmlnTG9jYWxpemVkKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5yZWFkZXIucmVhZEZpbGVSYXcoc3RhdGljUGF0aCwgJ3N0YXRpYycpO1xuICAgIH1cblxuICAgIC8vIE90aGVyd2lzZSwgd2UgbmVlZCB0byBzZWFyY2ggZm9yIHRoZSByaWdodCBzdGF0aWMsIGJ5IGNoZWNraW5nIGVhY2ggdmVyc2lvbi5cbiAgICBjb25zdCB2ZXJzaW9ucyA9IGF3YWl0IHRoaXMucmVhZGVyLmZpbmRJbnRlZ3JhdGlvblZlcnNpb25zKCk7XG4gICAgaWYgKCF2ZXJzaW9ucy5vaykge1xuICAgICAgcmV0dXJuIHZlcnNpb25zO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IHZlcnNpb24gb2YgdmVyc2lvbnMudmFsdWUpIHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IHRoaXMuZ2V0UmF3Q29uZmlnKHZlcnNpb24pO1xuICAgICAgaWYgKCFjb25maWcub2sgfHwgIWNvbmZpZy52YWx1ZS5zdGF0aWNzKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgY29uc3Qgc3RhdGljcyA9IGNvbmZpZy52YWx1ZS5zdGF0aWNzO1xuICAgICAgaWYgKHN0YXRpY3MubG9nbz8ucGF0aCA9PT0gc3RhdGljUGF0aCkge1xuICAgICAgICBpZiAoISgnZGF0YScgaW4gc3RhdGljcy5sb2dvKSkge1xuICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6IG5ldyBFcnJvcignTG9jYWxpemVkIGNvbmZpZyBtaXNzaW5nIHN0YXRpYyBkYXRhJykgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IEJ1ZmZlci5mcm9tKChzdGF0aWNzLmxvZ28gYXMgeyBkYXRhOiBzdHJpbmcgfSkuZGF0YSwgJ2Jhc2U2NCcpIH07XG4gICAgICB9XG4gICAgICBpZiAoc3RhdGljcz8uZGFya01vZGVMb2dvPy5wYXRoID09PSBzdGF0aWNQYXRoKSB7XG4gICAgICAgIGlmICghKCdkYXRhJyBpbiBzdGF0aWNzLmRhcmtNb2RlTG9nbykpIHtcbiAgICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiBuZXcgRXJyb3IoJ0xvY2FsaXplZCBjb25maWcgbWlzc2luZyBzdGF0aWMgZGF0YScpIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICB2YWx1ZTogQnVmZmVyLmZyb20oKHN0YXRpY3MuZGFya01vZGVMb2dvIGFzIHsgZGF0YTogc3RyaW5nIH0pLmRhdGEsICdiYXNlNjQnKSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgaXRlclN0YXRpYyBvZiBbLi4uKHN0YXRpY3M/LmdhbGxlcnkgPz8gW10pLCAuLi4oc3RhdGljcz8uZGFya01vZGVHYWxsZXJ5ID8/IFtdKV0pIHtcbiAgICAgICAgaWYgKGl0ZXJTdGF0aWMucGF0aCA9PT0gc3RhdGljUGF0aCkge1xuICAgICAgICAgIGlmICghKCdkYXRhJyBpbiBpdGVyU3RhdGljKSkge1xuICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogbmV3IEVycm9yKCdMb2NhbGl6ZWQgY29uZmlnIG1pc3Npbmcgc3RhdGljIGRhdGEnKSB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IEJ1ZmZlci5mcm9tKChpdGVyU3RhdGljIGFzIHsgZGF0YTogc3RyaW5nIH0pLmRhdGEsICdiYXNlNjQnKSB9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG9rOiBmYWxzZSxcbiAgICAgIGVycm9yOiBuZXcgRXJyb3IoYFN0YXRpYyBub3QgZm91bmQ6ICR7c3RhdGljUGF0aH1gLCB7IGNvZGU6ICdFTk9FTlQnIH0gYXMgRXJyb3JPcHRpb25zKSxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBzZXJpYWxpemVTdGF0aWNBc3NldChhc3NldDogU3RhdGljQXNzZXQpOiBQcm9taXNlPFJlc3VsdDxTZXJpYWxpemVkU3RhdGljQXNzZXQ+PiB7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHRoaXMuZ2V0U3RhdGljKGFzc2V0LnBhdGgpO1xuICAgIGlmICghZGF0YS5vaykge1xuICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG9rOiB0cnVlLFxuICAgICAgdmFsdWU6IHtcbiAgICAgICAgLi4uYXNzZXQsXG4gICAgICAgIGRhdGE6IGRhdGEudmFsdWUudG9TdHJpbmcoJ2Jhc2U2NCcpLFxuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBzZXJpYWxpemVTdGF0aWNzKFxuICAgIHN0YXRpY3M6IEludGVncmF0aW9uU3RhdGljc1xuICApOiBQcm9taXNlPFJlc3VsdDxTZXJpYWxpemVkSW50ZWdyYXRpb25TdGF0aWNzPj4ge1xuICAgIGNvbnN0IHNlcmlhbGl6ZWQ6IFNlcmlhbGl6ZWRJbnRlZ3JhdGlvblN0YXRpY3MgPSB7fTtcblxuICAgIGlmIChzdGF0aWNzLmxvZ28pIHtcbiAgICAgIGNvbnN0IHNlcmlhbGl6ZVJlc3VsdCA9IGF3YWl0IHRoaXMuc2VyaWFsaXplU3RhdGljQXNzZXQoc3RhdGljcy5sb2dvKTtcbiAgICAgIHNlcmlhbGl6ZWQubG9nbyA9IHNlcmlhbGl6ZVJlc3VsdC52YWx1ZTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdGljcy5kYXJrTW9kZUxvZ28pIHtcbiAgICAgIGNvbnN0IHNlcmlhbGl6ZVJlc3VsdCA9IGF3YWl0IHRoaXMuc2VyaWFsaXplU3RhdGljQXNzZXQoc3RhdGljcy5kYXJrTW9kZUxvZ28pO1xuICAgICAgc2VyaWFsaXplZC5kYXJrTW9kZUxvZ28gPSBzZXJpYWxpemVSZXN1bHQudmFsdWU7XG4gICAgfVxuXG4gICAgaWYgKHN0YXRpY3MuZ2FsbGVyeSkge1xuICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICBzdGF0aWNzLmdhbGxlcnkubWFwKChhc3NldCkgPT4gdGhpcy5zZXJpYWxpemVTdGF0aWNBc3NldChhc3NldCkpXG4gICAgICApO1xuICAgICAgY29uc3QgZm9sZGVkUmVzdWx0ID0gZm9sZFJlc3VsdHMocmVzdWx0cyk7XG4gICAgICBzZXJpYWxpemVkLmdhbGxlcnkgPSBmb2xkZWRSZXN1bHQudmFsdWU7XG4gICAgfVxuXG4gICAgaWYgKHN0YXRpY3MuZGFya01vZGVHYWxsZXJ5KSB7XG4gICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgIHN0YXRpY3MuZGFya01vZGVHYWxsZXJ5Lm1hcCgoYXNzZXQpID0+IHRoaXMuc2VyaWFsaXplU3RhdGljQXNzZXQoYXNzZXQpKVxuICAgICAgKTtcbiAgICAgIGNvbnN0IGZvbGRlZFJlc3VsdCA9IGZvbGRSZXN1bHRzKHJlc3VsdHMpO1xuICAgICAgc2VyaWFsaXplZC5kYXJrTW9kZUdhbGxlcnkgPSBmb2xkZWRSZXN1bHQudmFsdWU7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG9rOiB0cnVlLFxuICAgICAgdmFsdWU6IHNlcmlhbGl6ZWQsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXJpYWxpemUgdGhlIHJlZmVyZW5jZWQgaW50ZWdyYXRpb24gYXMgYSBmbGF0IEpTT04gb2JqZWN0LlxuICAgKiBVc2VmdWwgZm9yIG5vcm1hbGl6aW5nIHRoZSBmb3JtYXQgZm9yIHNlbmRpbmcgdG8gb3RoZXIgbG9jYXRpb25zLlxuICAgKiBUaGlzIG1ldGhvZCBpbXBsZW1lbnRzIHRoZSBzZXJpYWxpemF0aW9uIHNjaGVtZSBleHBlY3RlZCBieSBgSnNvbkNhdGFsb2dEYXRhQWRhcHRvcmAuXG4gICAqXG4gICAqIEBwYXJhbSB2ZXJzaW9uIFRoZSB2ZXJzaW9uIG9mIHRoZSBpbnRlZ3JhdGlvbiB0byBzZXJpYWxpemUuXG4gICAqIEByZXR1cm5zIEEgbGFyZ2Ugb2JqZWN0IHdoaWNoIGluY2x1ZGVzIGFsbCBvZiB0aGUgaW50ZWdyYXRpb24ncyBkYXRhLlxuICAgKi9cbiAgYXN5bmMgc2VyaWFsaXplKHZlcnNpb24/OiBzdHJpbmcpOiBQcm9taXNlPFJlc3VsdDxTZXJpYWxpemVkSW50ZWdyYXRpb24+PiB7XG4gICAgY29uc3QgY29uZmlnUmVzdWx0ID0gYXdhaXQgdGhpcy5nZXRSYXdDb25maWcodmVyc2lvbik7XG4gICAgaWYgKCFjb25maWdSZXN1bHQub2spIHtcbiAgICAgIHJldHVybiBjb25maWdSZXN1bHQ7XG4gICAgfVxuXG4gICAgLy8gVHlwZSBjYXN0IHNhZmV0eTogYWxsIHNlcmlhbGl6YWJsZSBwcm9wZXJ0aWVzIG11c3QgaGF2ZSB0aGUgJ2RhdGEnIGZpZWxkLlxuICAgIC8vIFRoZSByZW1haW5kZXIgb2YgdGhlIG1ldGhvZCBpcyBwb3B1bGF0aW5nIGFsbCBzdWNoIGZpZWxkcy5cbiAgICBjb25zdCBjb25maWcgPSBjb25maWdSZXN1bHQudmFsdWUgYXMgU2VyaWFsaXplZEludGVncmF0aW9uO1xuXG4gICAgY29uc3QgY29tcG9uZW50UmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgY29uZmlnLmNvbXBvbmVudHMubWFwKChjb21wb25lbnQpID0+XG4gICAgICAgIHRoaXMuZmV0Y2hEYXRhT3JSZWFkRmlsZShcbiAgICAgICAgICBjb21wb25lbnQsXG4gICAgICAgICAgeyBmaWxlbmFtZTogYCR7Y29tcG9uZW50Lm5hbWV9LSR7Y29tcG9uZW50LnZlcnNpb259Lm1hcHBpbmcuanNvbmAsIHR5cGU6ICdzY2hlbWFzJyB9LFxuICAgICAgICAgICdqc29uJ1xuICAgICAgICApXG4gICAgICApXG4gICAgKTtcbiAgICBjb25zdCBjb21wb25lbnRzUmVzdWx0ID0gZm9sZFJlc3VsdHMoY29tcG9uZW50UmVzdWx0cyk7XG4gICAgaWYgKCFjb21wb25lbnRzUmVzdWx0Lm9rKSB7XG4gICAgICByZXR1cm4gY29tcG9uZW50c1Jlc3VsdDtcbiAgICB9XG4gICAgY29uZmlnLmNvbXBvbmVudHMgPSBjb25maWcuY29tcG9uZW50cy5tYXAoKGNvbXBvbmVudCwgaWR4KSA9PiB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5jb21wb25lbnQsXG4gICAgICAgIGRhdGE6IEpTT04uc3RyaW5naWZ5KGNvbXBvbmVudHNSZXN1bHQudmFsdWVbaWR4XSksXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgaWYgKGNvbmZpZy5hc3NldHMuc2F2ZWRPYmplY3RzKSB7XG4gICAgICBjb25zdCBzb01ldGFkYXRhID0gY29uZmlnLmFzc2V0cy5zYXZlZE9iamVjdHM7XG4gICAgICBjb25zdCBzb1Jlc3VsdCA9IGF3YWl0IHRoaXMuZmV0Y2hEYXRhT3JSZWFkRmlsZShcbiAgICAgICAgY29uZmlnLmFzc2V0cy5zYXZlZE9iamVjdHMsXG4gICAgICAgIHtcbiAgICAgICAgICBmaWxlbmFtZTogYCR7c29NZXRhZGF0YS5uYW1lfS0ke3NvTWV0YWRhdGEudmVyc2lvbn0ubmRqc29uYCxcbiAgICAgICAgICB0eXBlOiAnYXNzZXRzJyxcbiAgICAgICAgfSxcbiAgICAgICAgJ2pzb24nXG4gICAgICApO1xuICAgICAgaWYgKCFzb1Jlc3VsdC5vaykge1xuICAgICAgICByZXR1cm4gc29SZXN1bHQ7XG4gICAgICB9XG4gICAgICBjb25maWcuYXNzZXRzLnNhdmVkT2JqZWN0cyA9IHsgLi4uc29NZXRhZGF0YSwgZGF0YTogSlNPTi5zdHJpbmdpZnkoc29SZXN1bHQudmFsdWUpIH07XG4gICAgfVxuXG4gICAgaWYgKGNvbmZpZy5hc3NldHMucXVlcmllcykge1xuICAgICAgY29uc3QgcXVlcnlSZXN1bHRzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgIGNvbmZpZy5hc3NldHMucXVlcmllcy5tYXAoKHF1ZXJ5KSA9PlxuICAgICAgICAgIHRoaXMuZmV0Y2hEYXRhT3JSZWFkRmlsZShcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgeyBmaWxlbmFtZTogYCR7cXVlcnkubmFtZX0tJHtxdWVyeS52ZXJzaW9ufS4ke3F1ZXJ5Lmxhbmd1YWdlfWAsIHR5cGU6ICdhc3NldHMnIH0sXG4gICAgICAgICAgICAnYmluYXJ5J1xuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKTtcbiAgICAgIGNvbnN0IHF1ZXJpZXNSZXN1bHQgPSBmb2xkUmVzdWx0cyhxdWVyeVJlc3VsdHMpO1xuICAgICAgaWYgKCFxdWVyaWVzUmVzdWx0Lm9rKSB7XG4gICAgICAgIHJldHVybiBxdWVyaWVzUmVzdWx0O1xuICAgICAgfVxuICAgICAgY29uZmlnLmFzc2V0cy5xdWVyaWVzID0gY29uZmlnLmFzc2V0cy5xdWVyaWVzLm1hcCgocXVlcnksIGlkeCkgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLnF1ZXJ5LFxuICAgICAgICAgIGRhdGE6IEpTT04uc3RyaW5naWZ5KHF1ZXJpZXNSZXN1bHQudmFsdWVbaWR4XS50b1N0cmluZygndXRmOCcpKSxcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmIChjb25maWcuc3RhdGljcykge1xuICAgICAgY29uc3Qgc3RhdGljc1Jlc3VsdCA9IGF3YWl0IHRoaXMuc2VyaWFsaXplU3RhdGljcyhjb25maWcuc3RhdGljcyk7XG4gICAgICBpZiAoIXN0YXRpY3NSZXN1bHQub2spIHtcbiAgICAgICAgcmV0dXJuIHN0YXRpY3NSZXN1bHQ7XG4gICAgICB9XG4gICAgICBjb25maWcuc3RhdGljcyA9IHN0YXRpY3NSZXN1bHQudmFsdWU7XG4gICAgfVxuXG4gICAgaWYgKGNvbmZpZy5zYW1wbGVEYXRhKSB7XG4gICAgICBjb25zdCBkYXRhUmVzdWx0ID0gYXdhaXQgdGhpcy5nZXRTYW1wbGVEYXRhKHZlcnNpb24pO1xuICAgICAgaWYgKCFkYXRhUmVzdWx0Lm9rKSB7XG4gICAgICAgIHJldHVybiBkYXRhUmVzdWx0O1xuICAgICAgfVxuICAgICAgY29uZmlnLnNhbXBsZURhdGEgPSB7XG4gICAgICAgIC4uLmNvbmZpZy5zYW1wbGVEYXRhLFxuICAgICAgICBkYXRhOiBKU09OLnN0cmluZ2lmeShkYXRhUmVzdWx0LnZhbHVlLnNhbXBsZURhdGEpLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICByZXR1cm4geyBvazogdHJ1ZSwgdmFsdWU6IGNvbmZpZyB9O1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBLElBQUFBLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQUMsT0FBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUYsc0JBQUEsQ0FBQUMsT0FBQTtBQUNBLElBQUFFLFdBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLGdCQUFBLEdBQUFILE9BQUE7QUFFQSxJQUFBSSxNQUFBLEdBQUFKLE9BQUE7QUFBbUQsU0FBQUQsdUJBQUFNLEdBQUEsV0FBQUEsR0FBQSxJQUFBQSxHQUFBLENBQUFDLFVBQUEsR0FBQUQsR0FBQSxLQUFBRSxPQUFBLEVBQUFGLEdBQUE7QUFBQSxTQUFBRyxnQkFBQUgsR0FBQSxFQUFBSSxHQUFBLEVBQUFDLEtBQUEsSUFBQUQsR0FBQSxHQUFBRSxjQUFBLENBQUFGLEdBQUEsT0FBQUEsR0FBQSxJQUFBSixHQUFBLElBQUFPLE1BQUEsQ0FBQUMsY0FBQSxDQUFBUixHQUFBLEVBQUFJLEdBQUEsSUFBQUMsS0FBQSxFQUFBQSxLQUFBLEVBQUFJLFVBQUEsUUFBQUMsWUFBQSxRQUFBQyxRQUFBLG9CQUFBWCxHQUFBLENBQUFJLEdBQUEsSUFBQUMsS0FBQSxXQUFBTCxHQUFBO0FBQUEsU0FBQU0sZUFBQU0sR0FBQSxRQUFBUixHQUFBLEdBQUFTLFlBQUEsQ0FBQUQsR0FBQSwyQkFBQVIsR0FBQSxnQkFBQUEsR0FBQSxHQUFBVSxNQUFBLENBQUFWLEdBQUE7QUFBQSxTQUFBUyxhQUFBRSxLQUFBLEVBQUFDLElBQUEsZUFBQUQsS0FBQSxpQkFBQUEsS0FBQSxrQkFBQUEsS0FBQSxNQUFBRSxJQUFBLEdBQUFGLEtBQUEsQ0FBQUcsTUFBQSxDQUFBQyxXQUFBLE9BQUFGLElBQUEsS0FBQUcsU0FBQSxRQUFBQyxHQUFBLEdBQUFKLElBQUEsQ0FBQUssSUFBQSxDQUFBUCxLQUFBLEVBQUFDLElBQUEsMkJBQUFLLEdBQUEsc0JBQUFBLEdBQUEsWUFBQUUsU0FBQSw0REFBQVAsSUFBQSxnQkFBQUYsTUFBQSxHQUFBVSxNQUFBLEVBQUFULEtBQUEsS0FWbkQ7QUFDQTtBQUNBO0FBQ0E7QUFTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTVUsaUJBQWlCLENBQUM7RUFLN0JDLFdBQVdBLENBQUNDLFNBQWlCLEVBQUVDLE1BQTJCLEVBQUU7SUFBQXpCLGVBQUE7SUFBQUEsZUFBQTtJQUFBQSxlQUFBO0lBQzFELElBQUksQ0FBQ3dCLFNBQVMsR0FBR0EsU0FBUztJQUMxQixJQUFJLENBQUNFLElBQUksR0FBR0MsYUFBSSxDQUFDQyxRQUFRLENBQUNKLFNBQVMsQ0FBQztJQUNwQyxJQUFJLENBQUNDLE1BQU0sR0FBR0EsTUFBTSxhQUFOQSxNQUFNLGNBQU5BLE1BQU0sR0FBSSxJQUFJSSw2Q0FBNEIsQ0FBQ0wsU0FBUyxDQUFDO0VBQ3JFOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0VBV0UsTUFBY00sbUJBQW1CQSxDQUMvQkMsSUFBdUIsRUFDdkJDLFVBQXdELEVBQ3hEQyxNQUF5QixFQUNvQjtJQUM3QyxJQUFJLElBQUksQ0FBQ1IsTUFBTSxDQUFDUyxpQkFBaUIsRUFBRTtNQUNqQyxJQUFJLENBQUNILElBQUksQ0FBQ0ksSUFBSSxFQUFFO1FBQ2QsT0FBTztVQUNMQyxFQUFFLEVBQUUsS0FBSztVQUNUQyxLQUFLLEVBQUUsSUFBSUMsS0FBSyxDQUNkLGlGQUFpRixHQUMvRUMsSUFBSSxDQUFDQyxTQUFTLENBQUNULElBQUksQ0FDdkI7UUFDRixDQUFDO01BQ0g7TUFDQSxJQUFJO1FBQ0YsSUFBSUUsTUFBTSxLQUFLLE1BQU0sRUFBRTtVQUNyQixPQUFPO1lBQUVHLEVBQUUsRUFBRSxJQUFJO1lBQUVsQyxLQUFLLEVBQUVxQyxJQUFJLENBQUNFLEtBQUssQ0FBQ1YsSUFBSSxDQUFDSSxJQUFJO1VBQUUsQ0FBQztRQUNuRCxDQUFDLE1BQU07VUFDTCxPQUFPO1lBQUVDLEVBQUUsRUFBRSxJQUFJO1lBQUVsQyxLQUFLLEVBQUV3QyxNQUFNLENBQUNDLElBQUksQ0FBQ1osSUFBSSxDQUFDSSxJQUFJLEVBQUUsUUFBUTtVQUFFLENBQUM7UUFDOUQ7TUFDRixDQUFDLENBQUMsT0FBT0UsS0FBSyxFQUFFO1FBQ2QsT0FBTztVQUFFRCxFQUFFLEVBQUUsS0FBSztVQUFFQztRQUFNLENBQUM7TUFDN0I7SUFDRjtJQUVBLElBQUlKLE1BQU0sS0FBSyxNQUFNLEVBQUU7TUFDckIsT0FBTyxJQUFJLENBQUNSLE1BQU0sQ0FBQ21CLFFBQVEsQ0FBQ1osVUFBVSxDQUFDYSxRQUFRLEVBQUViLFVBQVUsQ0FBQ2MsSUFBSSxDQUFDO0lBQ25FLENBQUMsTUFBTTtNQUNMLE9BQU8sSUFBSSxDQUFDckIsTUFBTSxDQUFDc0IsV0FBVyxDQUFDZixVQUFVLENBQUNhLFFBQVEsRUFBRWIsVUFBVSxDQUFDYyxJQUFJLENBQUM7SUFDdEU7RUFDRjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1FLGdCQUFnQkEsQ0FBQSxFQUEyQjtJQUMvQyxNQUFNQyxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUN4QixNQUFNLENBQUN5Qix1QkFBdUIsQ0FBQyxDQUFDO0lBQzVELElBQUksQ0FBQ0QsUUFBUSxDQUFDYixFQUFFLEVBQUU7TUFDaEIsT0FBTyxJQUFJO0lBQ2I7SUFDQSxJQUFJYSxRQUFRLENBQUMvQyxLQUFLLENBQUNpRCxNQUFNLEtBQUssQ0FBQyxFQUFFO01BQy9CLE9BQU8sSUFBSTtJQUNiO0lBQ0E7SUFDQUYsUUFBUSxDQUFDL0MsS0FBSyxDQUFDa0QsSUFBSSxDQUFDQyxlQUFNLENBQUNDLFFBQVEsQ0FBQztJQUNwQyxPQUFPTCxRQUFRLENBQUMvQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0VBQzFCOztFQUVBO0VBQ0EsTUFBY3FELFlBQVlBLENBQ3hCQyxPQUFnQixFQUM0QztJQUM1RCxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMvQixNQUFNLENBQUNnQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sYUFBYSxFQUFFO01BQzVELE9BQU87UUFDTHJCLEVBQUUsRUFBRSxLQUFLO1FBQ1RDLEtBQUssRUFBRSxJQUFJQyxLQUFLLENBQUUsR0FBRSxJQUFJLENBQUNkLFNBQVUsdUNBQXNDO01BQzNFLENBQUM7SUFDSDtJQUVBLE1BQU1rQyxZQUEyQixHQUFHRixPQUFPLEdBQUdBLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQ1IsZ0JBQWdCLENBQUMsQ0FBQztJQUVyRixJQUFJVSxZQUFZLEtBQUssSUFBSSxFQUFFO01BQ3pCLE9BQU87UUFDTHRCLEVBQUUsRUFBRSxLQUFLO1FBQ1RDLEtBQUssRUFBRSxJQUFJQyxLQUFLLENBQUUsb0NBQW1Da0IsT0FBUSxlQUFjO01BQzdFLENBQUM7SUFDSDtJQUVBLE1BQU1HLFVBQVUsR0FBSSxHQUFFLElBQUksQ0FBQ2pDLElBQUssSUFBR2dDLFlBQWEsT0FBTTs7SUFFdEQ7SUFDQSxNQUFNRSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUNuQyxNQUFNLENBQUNtQixRQUFRLENBQUNlLFVBQVUsQ0FBQztJQUNyRCxJQUFJLENBQUNDLE1BQU0sQ0FBQ3hCLEVBQUUsRUFBRTtNQUNkLE9BQU93QixNQUFNO0lBQ2Y7SUFDQSxPQUFPLElBQUFDLDRCQUFnQixFQUFDRCxNQUFNLENBQUMxRCxLQUFLLENBQUM7RUFDdkM7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTTRELFNBQVNBLENBQUNOLE9BQWdCLEVBQXNDO0lBQ3BFLE1BQU1PLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQ1IsWUFBWSxDQUFDQyxPQUFPLENBQUM7SUFDcEQsSUFBSSxDQUFDTyxXQUFXLENBQUMzQixFQUFFLEVBQUU7TUFDbkIsT0FBTzJCLFdBQVc7SUFDcEI7SUFDQSxPQUFPLElBQUFGLDRCQUFnQixFQUFDLElBQUFHLGtCQUFXLEVBQUNELFdBQVcsQ0FBQzdELEtBQUssQ0FBQyxDQUFDO0VBQ3pEO0VBRUEsTUFBYytELFVBQVVBLENBQ3RCQyxXQUFzRixFQUN6QjtJQUM3RCxNQUFNQyxPQUFPLEdBQUcsTUFBTUMsT0FBTyxDQUFDQyxHQUFHLENBQy9CSCxXQUFXLENBQUNJLEdBQUcsQ0FBQyxNQUFPdkMsSUFBSSxJQUFLO01BQzlCLE1BQU13QyxLQUFLLEdBQUcsTUFBTSxJQUFJLENBQUN6QyxtQkFBbUIsQ0FDMUNDLElBQUksRUFDSjtRQUFFYyxRQUFRLEVBQUcsR0FBRWQsSUFBSSxDQUFDTCxJQUFLLElBQUdLLElBQUksQ0FBQ3lCLE9BQVEsSUFBR3pCLElBQUksQ0FBQ3lDLFFBQVMsRUFBQztRQUFFMUIsSUFBSSxFQUFFO01BQVMsQ0FBQyxFQUM3RSxRQUNGLENBQUM7TUFDRCxJQUFJLENBQUN5QixLQUFLLENBQUNuQyxFQUFFLEVBQUU7UUFDYixPQUFPbUMsS0FBSztNQUNkO01BQ0EsT0FBTztRQUNMbkMsRUFBRSxFQUFFLElBQWE7UUFDakJsQyxLQUFLLEVBQUU7VUFDTHNFLFFBQVEsRUFBRXpDLElBQUksQ0FBQ3lDLFFBQVE7VUFDdkJELEtBQUssRUFBRUEsS0FBSyxDQUFDckUsS0FBSyxDQUFDdUUsUUFBUSxDQUFDLE1BQU07UUFDcEM7TUFDRixDQUFDO0lBQ0gsQ0FBQyxDQUNILENBQUM7SUFDRCxPQUFPLElBQUFDLGtCQUFXLEVBQUNQLE9BQU8sQ0FBQztFQUM3Qjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNUSxTQUFTQSxDQUNibkIsT0FBZ0IsRUFTaEI7SUFDQSxNQUFNb0IsWUFBWSxHQUFHLE1BQU0sSUFBSSxDQUFDckIsWUFBWSxDQUFDQyxPQUFPLENBQUM7SUFDckQsSUFBSSxDQUFDb0IsWUFBWSxDQUFDeEMsRUFBRSxFQUFFO01BQ3BCLE9BQU93QyxZQUFZO0lBQ3JCO0lBQ0EsTUFBTWhCLE1BQU0sR0FBR2dCLFlBQVksQ0FBQzFFLEtBQUs7SUFFakMsTUFBTTJFLFdBR0wsR0FBRyxDQUFDLENBQUM7SUFDTixJQUFJakIsTUFBTSxDQUFDa0IsTUFBTSxDQUFDQyxZQUFZLEVBQUU7TUFDOUIsTUFBTUQsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDaEQsbUJBQW1CLENBQzNDOEIsTUFBTSxDQUFDa0IsTUFBTSxDQUFDQyxZQUFZLEVBQzFCO1FBQ0VsQyxRQUFRLEVBQUcsR0FBRWUsTUFBTSxDQUFDa0IsTUFBTSxDQUFDQyxZQUFZLENBQUNyRCxJQUFLLElBQUdrQyxNQUFNLENBQUNrQixNQUFNLENBQUNDLFlBQVksQ0FBQ3ZCLE9BQVEsU0FBUTtRQUMzRlYsSUFBSSxFQUFFO01BQ1IsQ0FBQyxFQUNELE1BQ0YsQ0FBQztNQUNELElBQUksQ0FBQ2dDLE1BQU0sQ0FBQzFDLEVBQUUsRUFBRTtRQUNkLE9BQU8wQyxNQUFNO01BQ2Y7TUFDQUQsV0FBVyxDQUFDRSxZQUFZLEdBQUdELE1BQU0sQ0FBQzVFLEtBQWlCO0lBQ3JEO0lBQ0EsSUFBSTBELE1BQU0sQ0FBQ2tCLE1BQU0sQ0FBQ1gsT0FBTyxFQUFFO01BQ3pCLE1BQU1BLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQ0YsVUFBVSxDQUFDTCxNQUFNLENBQUNrQixNQUFNLENBQUNYLE9BQU8sQ0FBQztNQUM1RCxJQUFJLENBQUNBLE9BQU8sQ0FBQy9CLEVBQUUsRUFBRTtRQUNmLE9BQU8rQixPQUFPO01BQ2hCO01BQ0FVLFdBQVcsQ0FBQ1YsT0FBTyxHQUFHQSxPQUFPLENBQUNqRSxLQUFLO0lBQ3JDO0lBQ0EsT0FBTztNQUFFa0MsRUFBRSxFQUFFLElBQUk7TUFBRWxDLEtBQUssRUFBRTJFO0lBQVksQ0FBQztFQUN6Qzs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTUcsYUFBYUEsQ0FDakJ4QixPQUFnQixFQUtoQjtJQUNBLE1BQU1vQixZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUNyQixZQUFZLENBQUNDLE9BQU8sQ0FBQztJQUNyRCxJQUFJLENBQUNvQixZQUFZLENBQUN4QyxFQUFFLEVBQUU7TUFDcEIsT0FBT3dDLFlBQVk7SUFDckI7SUFDQSxNQUFNaEIsTUFBTSxHQUFHZ0IsWUFBWSxDQUFDMUUsS0FBSztJQUVqQyxNQUFNMkUsV0FBNEMsR0FBRztNQUFFSSxVQUFVLEVBQUU7SUFBSyxDQUFDO0lBQ3pFLElBQUlyQixNQUFNLENBQUNxQixVQUFVLEVBQUU7TUFDckIsTUFBTUMsV0FBc0MsR0FBRyxNQUFNLElBQUksQ0FBQ3BELG1CQUFtQixDQUMzRThCLE1BQU0sQ0FBQ3FCLFVBQVUsRUFDakI7UUFBRXBDLFFBQVEsRUFBRWUsTUFBTSxDQUFDcUIsVUFBVSxDQUFDdEQsSUFBSTtRQUFFbUIsSUFBSSxFQUFFO01BQU8sQ0FBQyxFQUNsRCxNQUNGLENBQUM7TUFDRCxJQUFJLENBQUNvQyxXQUFXLENBQUM5QyxFQUFFLEVBQUU7UUFDbkIsT0FBTzhDLFdBQVc7TUFDcEI7TUFDQSxLQUFLLE1BQU1oRixLQUFLLElBQUlnRixXQUFXLENBQUNoRixLQUFLLEVBQWM7UUFDakQsSUFBSSxFQUFFLFlBQVksSUFBSUEsS0FBSyxDQUFDLEVBQUU7VUFDNUI7UUFDRjtRQUNBO1FBQ0E7UUFDQTtRQUNBLE1BQU1pRixPQUFPLEdBQUcsSUFBSUMsSUFBSSxDQUN0QkEsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxHQUFHQyxJQUFJLENBQUNDLEtBQUssQ0FBQ0QsSUFBSSxDQUFDRSxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUN4RCxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO1FBQ2ZyRixNQUFNLENBQUNzRixNQUFNLENBQUN4RixLQUFLLEVBQUU7VUFBRSxZQUFZLEVBQUVpRjtRQUFRLENBQUMsQ0FBQztRQUMvQyxJQUFJLG1CQUFtQixJQUFJakYsS0FBSyxFQUFFO1VBQ2hDRSxNQUFNLENBQUNzRixNQUFNLENBQUN4RixLQUFLLEVBQUU7WUFBRXlGLGlCQUFpQixFQUFFUjtVQUFRLENBQUMsQ0FBQztRQUN0RDtNQUNGO01BQ0FOLFdBQVcsQ0FBQ0ksVUFBVSxHQUFHQyxXQUFXLENBQUNoRixLQUFpQjtJQUN4RDtJQUNBLE9BQU87TUFBRWtDLEVBQUUsRUFBRSxJQUFJO01BQUVsQyxLQUFLLEVBQUUyRTtJQUFZLENBQUM7RUFDekM7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNZSxVQUFVQSxDQUNkcEMsT0FBZ0IsRUFLaEI7SUFDQSxNQUFNb0IsWUFBWSxHQUFHLE1BQU0sSUFBSSxDQUFDckIsWUFBWSxDQUFDQyxPQUFPLENBQUM7SUFDckQsSUFBSSxDQUFDb0IsWUFBWSxDQUFDeEMsRUFBRSxFQUFFO01BQ3BCLE9BQU93QyxZQUFZO0lBQ3JCO0lBQ0EsTUFBTWhCLE1BQU0sR0FBR2dCLFlBQVksQ0FBQzFFLEtBQUs7SUFFakMsTUFBTTJFLFdBQW9ELEdBQUc7TUFDM0RnQixRQUFRLEVBQUUsQ0FBQztJQUNiLENBQUM7SUFDRCxLQUFLLE1BQU1DLFNBQVMsSUFBSWxDLE1BQU0sQ0FBQ21DLFVBQVUsRUFBRTtNQUN6QyxNQUFNQyxVQUFVLEdBQUksR0FBRUYsU0FBUyxDQUFDcEUsSUFBSyxJQUFHb0UsU0FBUyxDQUFDdEMsT0FBUSxlQUFjO01BQ3hFLE1BQU15QyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUNuRSxtQkFBbUIsQ0FDM0NnRSxTQUFTLEVBQ1Q7UUFBRWpELFFBQVEsRUFBRW1ELFVBQVU7UUFBRWxELElBQUksRUFBRTtNQUFVLENBQUMsRUFDekMsTUFDRixDQUFDO01BQ0QsSUFBSSxDQUFDbUQsTUFBTSxDQUFDN0QsRUFBRSxFQUFFO1FBQ2QsT0FBTzZELE1BQU07TUFDZjtNQUNBcEIsV0FBVyxDQUFDZ0IsUUFBUSxDQUFDQyxTQUFTLENBQUNwRSxJQUFJLENBQUMsR0FBR3VFLE1BQU0sQ0FBQy9GLEtBQUs7SUFDckQ7SUFDQSxPQUFPO01BQUVrQyxFQUFFLEVBQUUsSUFBSTtNQUFFbEMsS0FBSyxFQUFFMkU7SUFBWSxDQUFDO0VBQ3pDOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1xQixTQUFTQSxDQUFDQyxVQUFrQixFQUEyQjtJQUMzRDtJQUNBO0lBQ0EsSUFBSSxDQUFDLElBQUksQ0FBQzFFLE1BQU0sQ0FBQ1MsaUJBQWlCLEVBQUU7TUFDbEMsT0FBTyxNQUFNLElBQUksQ0FBQ1QsTUFBTSxDQUFDc0IsV0FBVyxDQUFDb0QsVUFBVSxFQUFFLFFBQVEsQ0FBQztJQUM1RDs7SUFFQTtJQUNBLE1BQU1sRCxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUN4QixNQUFNLENBQUN5Qix1QkFBdUIsQ0FBQyxDQUFDO0lBQzVELElBQUksQ0FBQ0QsUUFBUSxDQUFDYixFQUFFLEVBQUU7TUFDaEIsT0FBT2EsUUFBUTtJQUNqQjtJQUNBLEtBQUssTUFBTU8sT0FBTyxJQUFJUCxRQUFRLENBQUMvQyxLQUFLLEVBQUU7TUFBQSxJQUFBa0csYUFBQSxFQUFBQyxxQkFBQTtNQUNwQyxNQUFNekMsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDTCxZQUFZLENBQUNDLE9BQU8sQ0FBQztNQUMvQyxJQUFJLENBQUNJLE1BQU0sQ0FBQ3hCLEVBQUUsSUFBSSxDQUFDd0IsTUFBTSxDQUFDMUQsS0FBSyxDQUFDb0csT0FBTyxFQUFFO1FBQ3ZDO01BQ0Y7TUFDQSxNQUFNQSxPQUFPLEdBQUcxQyxNQUFNLENBQUMxRCxLQUFLLENBQUNvRyxPQUFPO01BQ3BDLElBQUksRUFBQUYsYUFBQSxHQUFBRSxPQUFPLENBQUNDLElBQUksY0FBQUgsYUFBQSx1QkFBWkEsYUFBQSxDQUFjekUsSUFBSSxNQUFLd0UsVUFBVSxFQUFFO1FBQ3JDLElBQUksRUFBRSxNQUFNLElBQUlHLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLEVBQUU7VUFDN0IsT0FBTztZQUFFbkUsRUFBRSxFQUFFLEtBQUs7WUFBRUMsS0FBSyxFQUFFLElBQUlDLEtBQUssQ0FBQyxzQ0FBc0M7VUFBRSxDQUFDO1FBQ2hGO1FBQ0EsT0FBTztVQUFFRixFQUFFLEVBQUUsSUFBSTtVQUFFbEMsS0FBSyxFQUFFd0MsTUFBTSxDQUFDQyxJQUFJLENBQUUyRCxPQUFPLENBQUNDLElBQUksQ0FBc0JwRSxJQUFJLEVBQUUsUUFBUTtRQUFFLENBQUM7TUFDNUY7TUFDQSxJQUFJLENBQUFtRSxPQUFPLGFBQVBBLE9BQU8sZ0JBQUFELHFCQUFBLEdBQVBDLE9BQU8sQ0FBRUUsWUFBWSxjQUFBSCxxQkFBQSx1QkFBckJBLHFCQUFBLENBQXVCMUUsSUFBSSxNQUFLd0UsVUFBVSxFQUFFO1FBQzlDLElBQUksRUFBRSxNQUFNLElBQUlHLE9BQU8sQ0FBQ0UsWUFBWSxDQUFDLEVBQUU7VUFDckMsT0FBTztZQUFFcEUsRUFBRSxFQUFFLEtBQUs7WUFBRUMsS0FBSyxFQUFFLElBQUlDLEtBQUssQ0FBQyxzQ0FBc0M7VUFBRSxDQUFDO1FBQ2hGO1FBQ0EsT0FBTztVQUNMRixFQUFFLEVBQUUsSUFBSTtVQUNSbEMsS0FBSyxFQUFFd0MsTUFBTSxDQUFDQyxJQUFJLENBQUUyRCxPQUFPLENBQUNFLFlBQVksQ0FBc0JyRSxJQUFJLEVBQUUsUUFBUTtRQUM5RSxDQUFDO01BQ0g7TUFDQSxLQUFLLE1BQU1zRSxVQUFVLElBQUksQ0FBQyxLQUFBQyxnQkFBQSxHQUFJSixPQUFPLGFBQVBBLE9BQU8sdUJBQVBBLE9BQU8sQ0FBRUssT0FBTyxjQUFBRCxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEVBQUUsQ0FBQyxFQUFFLEtBQUFFLHFCQUFBLEdBQUlOLE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFTyxlQUFlLGNBQUFELHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxDQUFDLENBQUMsRUFBRTtRQUFBLElBQUFGLGdCQUFBLEVBQUFFLHFCQUFBO1FBQzNGLElBQUlILFVBQVUsQ0FBQzlFLElBQUksS0FBS3dFLFVBQVUsRUFBRTtVQUNsQyxJQUFJLEVBQUUsTUFBTSxJQUFJTSxVQUFVLENBQUMsRUFBRTtZQUMzQixPQUFPO2NBQUVyRSxFQUFFLEVBQUUsS0FBSztjQUFFQyxLQUFLLEVBQUUsSUFBSUMsS0FBSyxDQUFDLHNDQUFzQztZQUFFLENBQUM7VUFDaEY7VUFDQSxPQUFPO1lBQUVGLEVBQUUsRUFBRSxJQUFJO1lBQUVsQyxLQUFLLEVBQUV3QyxNQUFNLENBQUNDLElBQUksQ0FBRThELFVBQVUsQ0FBc0J0RSxJQUFJLEVBQUUsUUFBUTtVQUFFLENBQUM7UUFDMUY7TUFDRjtJQUNGO0lBRUEsT0FBTztNQUNMQyxFQUFFLEVBQUUsS0FBSztNQUNUQyxLQUFLLEVBQUUsSUFBSUMsS0FBSyxDQUFFLHFCQUFvQjZELFVBQVcsRUFBQyxFQUFFO1FBQUVXLElBQUksRUFBRTtNQUFTLENBQWlCO0lBQ3hGLENBQUM7RUFDSDtFQUVBLE1BQWNDLG9CQUFvQkEsQ0FBQ0MsS0FBa0IsRUFBMEM7SUFDN0YsTUFBTTdFLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQytELFNBQVMsQ0FBQ2MsS0FBSyxDQUFDckYsSUFBSSxDQUFDO0lBQzdDLElBQUksQ0FBQ1EsSUFBSSxDQUFDQyxFQUFFLEVBQUU7TUFDWixPQUFPRCxJQUFJO0lBQ2I7SUFFQSxPQUFPO01BQ0xDLEVBQUUsRUFBRSxJQUFJO01BQ1JsQyxLQUFLLEVBQUU7UUFDTCxHQUFHOEcsS0FBSztRQUNSN0UsSUFBSSxFQUFFQSxJQUFJLENBQUNqQyxLQUFLLENBQUN1RSxRQUFRLENBQUMsUUFBUTtNQUNwQztJQUNGLENBQUM7RUFDSDtFQUVBLE1BQWN3QyxnQkFBZ0JBLENBQzVCWCxPQUEyQixFQUNvQjtJQUMvQyxNQUFNWSxVQUF3QyxHQUFHLENBQUMsQ0FBQztJQUVuRCxJQUFJWixPQUFPLENBQUNDLElBQUksRUFBRTtNQUNoQixNQUFNWSxlQUFlLEdBQUcsTUFBTSxJQUFJLENBQUNKLG9CQUFvQixDQUFDVCxPQUFPLENBQUNDLElBQUksQ0FBQztNQUNyRVcsVUFBVSxDQUFDWCxJQUFJLEdBQUdZLGVBQWUsQ0FBQ2pILEtBQUs7SUFDekM7SUFFQSxJQUFJb0csT0FBTyxDQUFDRSxZQUFZLEVBQUU7TUFDeEIsTUFBTVcsZUFBZSxHQUFHLE1BQU0sSUFBSSxDQUFDSixvQkFBb0IsQ0FBQ1QsT0FBTyxDQUFDRSxZQUFZLENBQUM7TUFDN0VVLFVBQVUsQ0FBQ1YsWUFBWSxHQUFHVyxlQUFlLENBQUNqSCxLQUFLO0lBQ2pEO0lBRUEsSUFBSW9HLE9BQU8sQ0FBQ0ssT0FBTyxFQUFFO01BQ25CLE1BQU1TLE9BQU8sR0FBRyxNQUFNaEQsT0FBTyxDQUFDQyxHQUFHLENBQy9CaUMsT0FBTyxDQUFDSyxPQUFPLENBQUNyQyxHQUFHLENBQUUwQyxLQUFLLElBQUssSUFBSSxDQUFDRCxvQkFBb0IsQ0FBQ0MsS0FBSyxDQUFDLENBQ2pFLENBQUM7TUFDRCxNQUFNSyxZQUFZLEdBQUcsSUFBQTNDLGtCQUFXLEVBQUMwQyxPQUFPLENBQUM7TUFDekNGLFVBQVUsQ0FBQ1AsT0FBTyxHQUFHVSxZQUFZLENBQUNuSCxLQUFLO0lBQ3pDO0lBRUEsSUFBSW9HLE9BQU8sQ0FBQ08sZUFBZSxFQUFFO01BQzNCLE1BQU1PLE9BQU8sR0FBRyxNQUFNaEQsT0FBTyxDQUFDQyxHQUFHLENBQy9CaUMsT0FBTyxDQUFDTyxlQUFlLENBQUN2QyxHQUFHLENBQUUwQyxLQUFLLElBQUssSUFBSSxDQUFDRCxvQkFBb0IsQ0FBQ0MsS0FBSyxDQUFDLENBQ3pFLENBQUM7TUFDRCxNQUFNSyxZQUFZLEdBQUcsSUFBQTNDLGtCQUFXLEVBQUMwQyxPQUFPLENBQUM7TUFDekNGLFVBQVUsQ0FBQ0wsZUFBZSxHQUFHUSxZQUFZLENBQUNuSCxLQUFLO0lBQ2pEO0lBRUEsT0FBTztNQUNMa0MsRUFBRSxFQUFFLElBQUk7TUFDUmxDLEtBQUssRUFBRWdIO0lBQ1QsQ0FBQztFQUNIOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNSSxTQUFTQSxDQUFDOUQsT0FBZ0IsRUFBMEM7SUFDeEUsTUFBTW9CLFlBQVksR0FBRyxNQUFNLElBQUksQ0FBQ3JCLFlBQVksQ0FBQ0MsT0FBTyxDQUFDO0lBQ3JELElBQUksQ0FBQ29CLFlBQVksQ0FBQ3hDLEVBQUUsRUFBRTtNQUNwQixPQUFPd0MsWUFBWTtJQUNyQjs7SUFFQTtJQUNBO0lBQ0EsTUFBTWhCLE1BQU0sR0FBR2dCLFlBQVksQ0FBQzFFLEtBQThCO0lBRTFELE1BQU1xSCxnQkFBZ0IsR0FBRyxNQUFNbkQsT0FBTyxDQUFDQyxHQUFHLENBQ3hDVCxNQUFNLENBQUNtQyxVQUFVLENBQUN6QixHQUFHLENBQUV3QixTQUFTLElBQzlCLElBQUksQ0FBQ2hFLG1CQUFtQixDQUN0QmdFLFNBQVMsRUFDVDtNQUFFakQsUUFBUSxFQUFHLEdBQUVpRCxTQUFTLENBQUNwRSxJQUFLLElBQUdvRSxTQUFTLENBQUN0QyxPQUFRLGVBQWM7TUFBRVYsSUFBSSxFQUFFO0lBQVUsQ0FBQyxFQUNwRixNQUNGLENBQ0YsQ0FDRixDQUFDO0lBQ0QsTUFBTTBFLGdCQUFnQixHQUFHLElBQUE5QyxrQkFBVyxFQUFDNkMsZ0JBQWdCLENBQUM7SUFDdEQsSUFBSSxDQUFDQyxnQkFBZ0IsQ0FBQ3BGLEVBQUUsRUFBRTtNQUN4QixPQUFPb0YsZ0JBQWdCO0lBQ3pCO0lBQ0E1RCxNQUFNLENBQUNtQyxVQUFVLEdBQUduQyxNQUFNLENBQUNtQyxVQUFVLENBQUN6QixHQUFHLENBQUMsQ0FBQ3dCLFNBQVMsRUFBRTJCLEdBQUcsS0FBSztNQUM1RCxPQUFPO1FBQ0wsR0FBRzNCLFNBQVM7UUFDWjNELElBQUksRUFBRUksSUFBSSxDQUFDQyxTQUFTLENBQUNnRixnQkFBZ0IsQ0FBQ3RILEtBQUssQ0FBQ3VILEdBQUcsQ0FBQztNQUNsRCxDQUFDO0lBQ0gsQ0FBQyxDQUFDO0lBRUYsSUFBSTdELE1BQU0sQ0FBQ2tCLE1BQU0sQ0FBQ0MsWUFBWSxFQUFFO01BQzlCLE1BQU0yQyxVQUFVLEdBQUc5RCxNQUFNLENBQUNrQixNQUFNLENBQUNDLFlBQVk7TUFDN0MsTUFBTTRDLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQzdGLG1CQUFtQixDQUM3QzhCLE1BQU0sQ0FBQ2tCLE1BQU0sQ0FBQ0MsWUFBWSxFQUMxQjtRQUNFbEMsUUFBUSxFQUFHLEdBQUU2RSxVQUFVLENBQUNoRyxJQUFLLElBQUdnRyxVQUFVLENBQUNsRSxPQUFRLFNBQVE7UUFDM0RWLElBQUksRUFBRTtNQUNSLENBQUMsRUFDRCxNQUNGLENBQUM7TUFDRCxJQUFJLENBQUM2RSxRQUFRLENBQUN2RixFQUFFLEVBQUU7UUFDaEIsT0FBT3VGLFFBQVE7TUFDakI7TUFDQS9ELE1BQU0sQ0FBQ2tCLE1BQU0sQ0FBQ0MsWUFBWSxHQUFHO1FBQUUsR0FBRzJDLFVBQVU7UUFBRXZGLElBQUksRUFBRUksSUFBSSxDQUFDQyxTQUFTLENBQUNtRixRQUFRLENBQUN6SCxLQUFLO01BQUUsQ0FBQztJQUN0RjtJQUVBLElBQUkwRCxNQUFNLENBQUNrQixNQUFNLENBQUNYLE9BQU8sRUFBRTtNQUN6QixNQUFNeUQsWUFBWSxHQUFHLE1BQU14RCxPQUFPLENBQUNDLEdBQUcsQ0FDcENULE1BQU0sQ0FBQ2tCLE1BQU0sQ0FBQ1gsT0FBTyxDQUFDRyxHQUFHLENBQUVDLEtBQUssSUFDOUIsSUFBSSxDQUFDekMsbUJBQW1CLENBQ3RCeUMsS0FBSyxFQUNMO1FBQUUxQixRQUFRLEVBQUcsR0FBRTBCLEtBQUssQ0FBQzdDLElBQUssSUFBRzZDLEtBQUssQ0FBQ2YsT0FBUSxJQUFHZSxLQUFLLENBQUNDLFFBQVMsRUFBQztRQUFFMUIsSUFBSSxFQUFFO01BQVMsQ0FBQyxFQUNoRixRQUNGLENBQ0YsQ0FDRixDQUFDO01BQ0QsTUFBTStFLGFBQWEsR0FBRyxJQUFBbkQsa0JBQVcsRUFBQ2tELFlBQVksQ0FBQztNQUMvQyxJQUFJLENBQUNDLGFBQWEsQ0FBQ3pGLEVBQUUsRUFBRTtRQUNyQixPQUFPeUYsYUFBYTtNQUN0QjtNQUNBakUsTUFBTSxDQUFDa0IsTUFBTSxDQUFDWCxPQUFPLEdBQUdQLE1BQU0sQ0FBQ2tCLE1BQU0sQ0FBQ1gsT0FBTyxDQUFDRyxHQUFHLENBQUMsQ0FBQ0MsS0FBSyxFQUFFa0QsR0FBRyxLQUFLO1FBQ2hFLE9BQU87VUFDTCxHQUFHbEQsS0FBSztVQUNScEMsSUFBSSxFQUFFSSxJQUFJLENBQUNDLFNBQVMsQ0FBQ3FGLGFBQWEsQ0FBQzNILEtBQUssQ0FBQ3VILEdBQUcsQ0FBQyxDQUFDaEQsUUFBUSxDQUFDLE1BQU0sQ0FBQztRQUNoRSxDQUFDO01BQ0gsQ0FBQyxDQUFDO0lBQ0o7SUFFQSxJQUFJYixNQUFNLENBQUMwQyxPQUFPLEVBQUU7TUFDbEIsTUFBTXdCLGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQ2IsZ0JBQWdCLENBQUNyRCxNQUFNLENBQUMwQyxPQUFPLENBQUM7TUFDakUsSUFBSSxDQUFDd0IsYUFBYSxDQUFDMUYsRUFBRSxFQUFFO1FBQ3JCLE9BQU8wRixhQUFhO01BQ3RCO01BQ0FsRSxNQUFNLENBQUMwQyxPQUFPLEdBQUd3QixhQUFhLENBQUM1SCxLQUFLO0lBQ3RDO0lBRUEsSUFBSTBELE1BQU0sQ0FBQ3FCLFVBQVUsRUFBRTtNQUNyQixNQUFNOEMsVUFBVSxHQUFHLE1BQU0sSUFBSSxDQUFDL0MsYUFBYSxDQUFDeEIsT0FBTyxDQUFDO01BQ3BELElBQUksQ0FBQ3VFLFVBQVUsQ0FBQzNGLEVBQUUsRUFBRTtRQUNsQixPQUFPMkYsVUFBVTtNQUNuQjtNQUNBbkUsTUFBTSxDQUFDcUIsVUFBVSxHQUFHO1FBQ2xCLEdBQUdyQixNQUFNLENBQUNxQixVQUFVO1FBQ3BCOUMsSUFBSSxFQUFFSSxJQUFJLENBQUNDLFNBQVMsQ0FBQ3VGLFVBQVUsQ0FBQzdILEtBQUssQ0FBQytFLFVBQVU7TUFDbEQsQ0FBQztJQUNIO0lBRUEsT0FBTztNQUFFN0MsRUFBRSxFQUFFLElBQUk7TUFBRWxDLEtBQUssRUFBRTBEO0lBQU8sQ0FBQztFQUNwQztBQUNGO0FBQUNvRSxPQUFBLENBQUExRyxpQkFBQSxHQUFBQSxpQkFBQSJ9