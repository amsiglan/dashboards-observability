REFRESH MATERIALIZED VIEW {table_name}_mview;
