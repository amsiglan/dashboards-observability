"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.validateTemplate = exports.validateInstance = void 0;
var _ajv = _interopRequireDefault(require("ajv"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

const ajv = new _ajv.default();
const staticAsset = {
  type: 'object',
  properties: {
    path: {
      type: 'string'
    },
    annotation: {
      type: 'string',
      nullable: true
    }
  },
  required: ['path'],
  additionalProperties: false
};
const templateSchema = {
  type: 'object',
  properties: {
    name: {
      type: 'string'
    },
    version: {
      type: 'string'
    },
    displayName: {
      type: 'string',
      nullable: true
    },
    license: {
      type: 'string'
    },
    type: {
      type: 'string'
    },
    labels: {
      type: 'array',
      items: {
        type: 'string'
      },
      nullable: true
    },
    tags: {
      type: 'array',
      items: {
        type: 'string'
      },
      nullable: true
    },
    author: {
      type: 'string',
      nullable: true
    },
    description: {
      type: 'string',
      nullable: true
    },
    sourceUrl: {
      type: 'string',
      nullable: true
    },
    statics: {
      type: 'object',
      properties: {
        logo: {
          ...staticAsset,
          nullable: true
        },
        gallery: {
          type: 'array',
          items: staticAsset,
          nullable: true
        },
        darkModeLogo: {
          ...staticAsset,
          nullable: true
        },
        darkModeGallery: {
          type: 'array',
          items: staticAsset,
          nullable: true
        }
      },
      additionalProperties: false,
      nullable: true
    },
    components: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: {
            type: 'string'
          },
          version: {
            type: 'string'
          }
        },
        required: ['name', 'version']
      }
    },
    assets: {
      type: 'object',
      properties: {
        savedObjects: {
          type: 'object',
          properties: {
            name: {
              type: 'string'
            },
            version: {
              type: 'string'
            }
          },
          required: ['name', 'version'],
          nullable: true,
          additionalProperties: false
        },
        queries: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              name: {
                type: 'string'
              },
              version: {
                type: 'string'
              },
              language: {
                type: 'string'
              }
            },
            required: ['name', 'version', 'language']
          },
          nullable: true
        }
      },
      additionalProperties: false
    },
    sampleData: {
      type: 'object',
      properties: {
        path: {
          type: 'string'
        }
      },
      required: ['path'],
      additionalProperties: false,
      nullable: true
    }
  },
  required: ['name', 'version', 'license', 'type', 'components', 'assets'],
  additionalProperties: false
};
const instanceSchema = {
  type: 'object',
  properties: {
    name: {
      type: 'string'
    },
    templateName: {
      type: 'string'
    },
    dataSource: {
      type: 'string'
    },
    creationDate: {
      type: 'string'
    },
    assets: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          assetType: {
            type: 'string'
          },
          assetId: {
            type: 'string'
          },
          isDefaultAsset: {
            type: 'boolean'
          },
          description: {
            type: 'string'
          }
        },
        required: ['assetType', 'assetId', 'isDefaultAsset', 'description']
      }
    }
  },
  required: ['name', 'templateName', 'dataSource', 'creationDate', 'assets']
};
const templateValidator = ajv.compile(templateSchema);
const instanceValidator = ajv.compile(instanceSchema);

/**
 * Validates an integration template against a predefined schema using the AJV library.
 * Since AJV validators use side effects for errors,
 * this is a more conventional wrapper that simplifies calling.
 *
 * @param data The data to be validated as an IntegrationTemplate.
 * @return A Result indicating whether the validation was successful or not.
 *         If validation succeeds, returns an object with 'ok' set to true and the validated data.
 *         If validation fails, returns an object with 'ok' set to false and an Error object describing the validation error.
 */
const validateTemplate = data => {
  if (!templateValidator(data)) {
    return {
      ok: false,
      error: new Error(ajv.errorsText(templateValidator.errors))
    };
  }
  // We assume an invariant that the type of an integration is connected with its component.
  if (data.components.findIndex(x => x.name === data.type) < 0) {
    return {
      ok: false,
      error: new Error(`The integration type '${data.type}' must be included as a component`)
    };
  }
  return {
    ok: true,
    value: data
  };
};

/**
 * Validates an integration instance against a predefined schema using the AJV library.
 *
 * @param data The data to be validated as an IntegrationInstance.
 * @return A Result indicating whether the validation was successful or not.
 *         If validation succeeds, returns an object with 'ok' set to true and the validated data.
 *         If validation fails, returns an object with 'ok' set to false and an Error object describing the validation error.
 */
exports.validateTemplate = validateTemplate;
const validateInstance = data => {
  if (!instanceValidator(data)) {
    return {
      ok: false,
      error: new Error(ajv.errorsText(instanceValidator.errors))
    };
  }
  return {
    ok: true,
    value: data
  };
};
exports.validateInstance = validateInstance;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYWp2IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJvYmoiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImFqdiIsIkFqdiIsInN0YXRpY0Fzc2V0IiwidHlwZSIsInByb3BlcnRpZXMiLCJwYXRoIiwiYW5ub3RhdGlvbiIsIm51bGxhYmxlIiwicmVxdWlyZWQiLCJhZGRpdGlvbmFsUHJvcGVydGllcyIsInRlbXBsYXRlU2NoZW1hIiwibmFtZSIsInZlcnNpb24iLCJkaXNwbGF5TmFtZSIsImxpY2Vuc2UiLCJsYWJlbHMiLCJpdGVtcyIsInRhZ3MiLCJhdXRob3IiLCJkZXNjcmlwdGlvbiIsInNvdXJjZVVybCIsInN0YXRpY3MiLCJsb2dvIiwiZ2FsbGVyeSIsImRhcmtNb2RlTG9nbyIsImRhcmtNb2RlR2FsbGVyeSIsImNvbXBvbmVudHMiLCJhc3NldHMiLCJzYXZlZE9iamVjdHMiLCJxdWVyaWVzIiwibGFuZ3VhZ2UiLCJzYW1wbGVEYXRhIiwiaW5zdGFuY2VTY2hlbWEiLCJ0ZW1wbGF0ZU5hbWUiLCJkYXRhU291cmNlIiwiY3JlYXRpb25EYXRlIiwiYXNzZXRUeXBlIiwiYXNzZXRJZCIsImlzRGVmYXVsdEFzc2V0IiwidGVtcGxhdGVWYWxpZGF0b3IiLCJjb21waWxlIiwiaW5zdGFuY2VWYWxpZGF0b3IiLCJ2YWxpZGF0ZVRlbXBsYXRlIiwiZGF0YSIsIm9rIiwiZXJyb3IiLCJFcnJvciIsImVycm9yc1RleHQiLCJlcnJvcnMiLCJmaW5kSW5kZXgiLCJ4IiwidmFsdWUiLCJleHBvcnRzIiwidmFsaWRhdGVJbnN0YW5jZSJdLCJzb3VyY2VzIjpbInZhbGlkYXRvcnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5pbXBvcnQgQWp2LCB7IEpTT05TY2hlbWFUeXBlIH0gZnJvbSAnYWp2JztcblxuY29uc3QgYWp2ID0gbmV3IEFqdigpO1xuXG5jb25zdCBzdGF0aWNBc3NldDogSlNPTlNjaGVtYVR5cGU8U3RhdGljQXNzZXQ+ID0ge1xuICB0eXBlOiAnb2JqZWN0JyxcbiAgcHJvcGVydGllczoge1xuICAgIHBhdGg6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICBhbm5vdGF0aW9uOiB7IHR5cGU6ICdzdHJpbmcnLCBudWxsYWJsZTogdHJ1ZSB9LFxuICB9LFxuICByZXF1aXJlZDogWydwYXRoJ10sXG4gIGFkZGl0aW9uYWxQcm9wZXJ0aWVzOiBmYWxzZSxcbn07XG5cbmNvbnN0IHRlbXBsYXRlU2NoZW1hOiBKU09OU2NoZW1hVHlwZTxJbnRlZ3JhdGlvbkNvbmZpZz4gPSB7XG4gIHR5cGU6ICdvYmplY3QnLFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgbmFtZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgIHZlcnNpb246IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICBkaXNwbGF5TmFtZTogeyB0eXBlOiAnc3RyaW5nJywgbnVsbGFibGU6IHRydWUgfSxcbiAgICBsaWNlbnNlOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgdHlwZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgIGxhYmVsczogeyB0eXBlOiAnYXJyYXknLCBpdGVtczogeyB0eXBlOiAnc3RyaW5nJyB9LCBudWxsYWJsZTogdHJ1ZSB9LFxuICAgIHRhZ3M6IHsgdHlwZTogJ2FycmF5JywgaXRlbXM6IHsgdHlwZTogJ3N0cmluZycgfSwgbnVsbGFibGU6IHRydWUgfSxcbiAgICBhdXRob3I6IHsgdHlwZTogJ3N0cmluZycsIG51bGxhYmxlOiB0cnVlIH0sXG4gICAgZGVzY3JpcHRpb246IHsgdHlwZTogJ3N0cmluZycsIG51bGxhYmxlOiB0cnVlIH0sXG4gICAgc291cmNlVXJsOiB7IHR5cGU6ICdzdHJpbmcnLCBudWxsYWJsZTogdHJ1ZSB9LFxuICAgIHN0YXRpY3M6IHtcbiAgICAgIHR5cGU6ICdvYmplY3QnLFxuICAgICAgcHJvcGVydGllczoge1xuICAgICAgICBsb2dvOiB7IC4uLnN0YXRpY0Fzc2V0LCBudWxsYWJsZTogdHJ1ZSB9LFxuICAgICAgICBnYWxsZXJ5OiB7IHR5cGU6ICdhcnJheScsIGl0ZW1zOiBzdGF0aWNBc3NldCwgbnVsbGFibGU6IHRydWUgfSxcbiAgICAgICAgZGFya01vZGVMb2dvOiB7IC4uLnN0YXRpY0Fzc2V0LCBudWxsYWJsZTogdHJ1ZSB9LFxuICAgICAgICBkYXJrTW9kZUdhbGxlcnk6IHsgdHlwZTogJ2FycmF5JywgaXRlbXM6IHN0YXRpY0Fzc2V0LCBudWxsYWJsZTogdHJ1ZSB9LFxuICAgICAgfSxcbiAgICAgIGFkZGl0aW9uYWxQcm9wZXJ0aWVzOiBmYWxzZSxcbiAgICAgIG51bGxhYmxlOiB0cnVlLFxuICAgIH0sXG4gICAgY29tcG9uZW50czoge1xuICAgICAgdHlwZTogJ2FycmF5JyxcbiAgICAgIGl0ZW1zOiB7XG4gICAgICAgIHR5cGU6ICdvYmplY3QnLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgbmFtZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgICAgICAgIHZlcnNpb246IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICAgICAgfSxcbiAgICAgICAgcmVxdWlyZWQ6IFsnbmFtZScsICd2ZXJzaW9uJ10sXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXNzZXRzOiB7XG4gICAgICB0eXBlOiAnb2JqZWN0JyxcbiAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgc2F2ZWRPYmplY3RzOiB7XG4gICAgICAgICAgdHlwZTogJ29iamVjdCcsXG4gICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgbmFtZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgICAgICAgICAgdmVyc2lvbjogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcmVxdWlyZWQ6IFsnbmFtZScsICd2ZXJzaW9uJ10sXG4gICAgICAgICAgbnVsbGFibGU6IHRydWUsXG4gICAgICAgICAgYWRkaXRpb25hbFByb3BlcnRpZXM6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBxdWVyaWVzOiB7XG4gICAgICAgICAgdHlwZTogJ2FycmF5JyxcbiAgICAgICAgICBpdGVtczoge1xuICAgICAgICAgICAgdHlwZTogJ29iamVjdCcsXG4gICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgIG5hbWU6IHsgdHlwZTogJ3N0cmluZycgfSxcbiAgICAgICAgICAgICAgdmVyc2lvbjogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgICAgICAgICAgICBsYW5ndWFnZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlcXVpcmVkOiBbJ25hbWUnLCAndmVyc2lvbicsICdsYW5ndWFnZSddLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgbnVsbGFibGU6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgYWRkaXRpb25hbFByb3BlcnRpZXM6IGZhbHNlLFxuICAgIH0sXG4gICAgc2FtcGxlRGF0YToge1xuICAgICAgdHlwZTogJ29iamVjdCcsXG4gICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHBhdGg6IHtcbiAgICAgICAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICByZXF1aXJlZDogWydwYXRoJ10sXG4gICAgICBhZGRpdGlvbmFsUHJvcGVydGllczogZmFsc2UsXG4gICAgICBudWxsYWJsZTogdHJ1ZSxcbiAgICB9LFxuICB9LFxuICByZXF1aXJlZDogWyduYW1lJywgJ3ZlcnNpb24nLCAnbGljZW5zZScsICd0eXBlJywgJ2NvbXBvbmVudHMnLCAnYXNzZXRzJ10sXG4gIGFkZGl0aW9uYWxQcm9wZXJ0aWVzOiBmYWxzZSxcbn07XG5cbmNvbnN0IGluc3RhbmNlU2NoZW1hOiBKU09OU2NoZW1hVHlwZTxJbnRlZ3JhdGlvbkluc3RhbmNlPiA9IHtcbiAgdHlwZTogJ29iamVjdCcsXG4gIHByb3BlcnRpZXM6IHtcbiAgICBuYW1lOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgdGVtcGxhdGVOYW1lOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgZGF0YVNvdXJjZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgIGNyZWF0aW9uRGF0ZTogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgIGFzc2V0czoge1xuICAgICAgdHlwZTogJ2FycmF5JyxcbiAgICAgIGl0ZW1zOiB7XG4gICAgICAgIHR5cGU6ICdvYmplY3QnLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgYXNzZXRUeXBlOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgICAgICAgYXNzZXRJZDogeyB0eXBlOiAnc3RyaW5nJyB9LFxuICAgICAgICAgIGlzRGVmYXVsdEFzc2V0OiB7IHR5cGU6ICdib29sZWFuJyB9LFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiB7IHR5cGU6ICdzdHJpbmcnIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHJlcXVpcmVkOiBbJ2Fzc2V0VHlwZScsICdhc3NldElkJywgJ2lzRGVmYXVsdEFzc2V0JywgJ2Rlc2NyaXB0aW9uJ10sXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHJlcXVpcmVkOiBbJ25hbWUnLCAndGVtcGxhdGVOYW1lJywgJ2RhdGFTb3VyY2UnLCAnY3JlYXRpb25EYXRlJywgJ2Fzc2V0cyddLFxufTtcblxuY29uc3QgdGVtcGxhdGVWYWxpZGF0b3IgPSBhanYuY29tcGlsZSh0ZW1wbGF0ZVNjaGVtYSk7XG5jb25zdCBpbnN0YW5jZVZhbGlkYXRvciA9IGFqdi5jb21waWxlKGluc3RhbmNlU2NoZW1hKTtcblxuLyoqXG4gKiBWYWxpZGF0ZXMgYW4gaW50ZWdyYXRpb24gdGVtcGxhdGUgYWdhaW5zdCBhIHByZWRlZmluZWQgc2NoZW1hIHVzaW5nIHRoZSBBSlYgbGlicmFyeS5cbiAqIFNpbmNlIEFKViB2YWxpZGF0b3JzIHVzZSBzaWRlIGVmZmVjdHMgZm9yIGVycm9ycyxcbiAqIHRoaXMgaXMgYSBtb3JlIGNvbnZlbnRpb25hbCB3cmFwcGVyIHRoYXQgc2ltcGxpZmllcyBjYWxsaW5nLlxuICpcbiAqIEBwYXJhbSBkYXRhIFRoZSBkYXRhIHRvIGJlIHZhbGlkYXRlZCBhcyBhbiBJbnRlZ3JhdGlvblRlbXBsYXRlLlxuICogQHJldHVybiBBIFJlc3VsdCBpbmRpY2F0aW5nIHdoZXRoZXIgdGhlIHZhbGlkYXRpb24gd2FzIHN1Y2Nlc3NmdWwgb3Igbm90LlxuICogICAgICAgICBJZiB2YWxpZGF0aW9uIHN1Y2NlZWRzLCByZXR1cm5zIGFuIG9iamVjdCB3aXRoICdvaycgc2V0IHRvIHRydWUgYW5kIHRoZSB2YWxpZGF0ZWQgZGF0YS5cbiAqICAgICAgICAgSWYgdmFsaWRhdGlvbiBmYWlscywgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCAnb2snIHNldCB0byBmYWxzZSBhbmQgYW4gRXJyb3Igb2JqZWN0IGRlc2NyaWJpbmcgdGhlIHZhbGlkYXRpb24gZXJyb3IuXG4gKi9cbmV4cG9ydCBjb25zdCB2YWxpZGF0ZVRlbXBsYXRlID0gKGRhdGE6IHVua25vd24pOiBSZXN1bHQ8SW50ZWdyYXRpb25Db25maWc+ID0+IHtcbiAgaWYgKCF0ZW1wbGF0ZVZhbGlkYXRvcihkYXRhKSkge1xuICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6IG5ldyBFcnJvcihhanYuZXJyb3JzVGV4dCh0ZW1wbGF0ZVZhbGlkYXRvci5lcnJvcnMpKSB9O1xuICB9XG4gIC8vIFdlIGFzc3VtZSBhbiBpbnZhcmlhbnQgdGhhdCB0aGUgdHlwZSBvZiBhbiBpbnRlZ3JhdGlvbiBpcyBjb25uZWN0ZWQgd2l0aCBpdHMgY29tcG9uZW50LlxuICBpZiAoZGF0YS5jb21wb25lbnRzLmZpbmRJbmRleCgoeCkgPT4geC5uYW1lID09PSBkYXRhLnR5cGUpIDwgMCkge1xuICAgIHJldHVybiB7XG4gICAgICBvazogZmFsc2UsXG4gICAgICBlcnJvcjogbmV3IEVycm9yKGBUaGUgaW50ZWdyYXRpb24gdHlwZSAnJHtkYXRhLnR5cGV9JyBtdXN0IGJlIGluY2x1ZGVkIGFzIGEgY29tcG9uZW50YCksXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG9rOiB0cnVlLFxuICAgIHZhbHVlOiBkYXRhLFxuICB9O1xufTtcblxuLyoqXG4gKiBWYWxpZGF0ZXMgYW4gaW50ZWdyYXRpb24gaW5zdGFuY2UgYWdhaW5zdCBhIHByZWRlZmluZWQgc2NoZW1hIHVzaW5nIHRoZSBBSlYgbGlicmFyeS5cbiAqXG4gKiBAcGFyYW0gZGF0YSBUaGUgZGF0YSB0byBiZSB2YWxpZGF0ZWQgYXMgYW4gSW50ZWdyYXRpb25JbnN0YW5jZS5cbiAqIEByZXR1cm4gQSBSZXN1bHQgaW5kaWNhdGluZyB3aGV0aGVyIHRoZSB2YWxpZGF0aW9uIHdhcyBzdWNjZXNzZnVsIG9yIG5vdC5cbiAqICAgICAgICAgSWYgdmFsaWRhdGlvbiBzdWNjZWVkcywgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCAnb2snIHNldCB0byB0cnVlIGFuZCB0aGUgdmFsaWRhdGVkIGRhdGEuXG4gKiAgICAgICAgIElmIHZhbGlkYXRpb24gZmFpbHMsIHJldHVybnMgYW4gb2JqZWN0IHdpdGggJ29rJyBzZXQgdG8gZmFsc2UgYW5kIGFuIEVycm9yIG9iamVjdCBkZXNjcmliaW5nIHRoZSB2YWxpZGF0aW9uIGVycm9yLlxuICovXG5leHBvcnQgY29uc3QgdmFsaWRhdGVJbnN0YW5jZSA9IChkYXRhOiB1bmtub3duKTogUmVzdWx0PEludGVncmF0aW9uSW5zdGFuY2U+ID0+IHtcbiAgaWYgKCFpbnN0YW5jZVZhbGlkYXRvcihkYXRhKSkge1xuICAgIHJldHVybiB7XG4gICAgICBvazogZmFsc2UsXG4gICAgICBlcnJvcjogbmV3IEVycm9yKGFqdi5lcnJvcnNUZXh0KGluc3RhbmNlVmFsaWRhdG9yLmVycm9ycykpLFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBvazogdHJ1ZSxcbiAgICB2YWx1ZTogZGF0YSxcbiAgfTtcbn07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBLElBQUFBLElBQUEsR0FBQUMsc0JBQUEsQ0FBQUMsT0FBQTtBQUEwQyxTQUFBRCx1QkFBQUUsR0FBQSxXQUFBQSxHQUFBLElBQUFBLEdBQUEsQ0FBQUMsVUFBQSxHQUFBRCxHQUFBLEtBQUFFLE9BQUEsRUFBQUYsR0FBQTtBQUwxQztBQUNBO0FBQ0E7QUFDQTs7QUFJQSxNQUFNRyxHQUFHLEdBQUcsSUFBSUMsWUFBRyxDQUFDLENBQUM7QUFFckIsTUFBTUMsV0FBd0MsR0FBRztFQUMvQ0MsSUFBSSxFQUFFLFFBQVE7RUFDZEMsVUFBVSxFQUFFO0lBQ1ZDLElBQUksRUFBRTtNQUFFRixJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQ3hCRyxVQUFVLEVBQUU7TUFBRUgsSUFBSSxFQUFFLFFBQVE7TUFBRUksUUFBUSxFQUFFO0lBQUs7RUFDL0MsQ0FBQztFQUNEQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUM7RUFDbEJDLG9CQUFvQixFQUFFO0FBQ3hCLENBQUM7QUFFRCxNQUFNQyxjQUFpRCxHQUFHO0VBQ3hEUCxJQUFJLEVBQUUsUUFBUTtFQUNkQyxVQUFVLEVBQUU7SUFDVk8sSUFBSSxFQUFFO01BQUVSLElBQUksRUFBRTtJQUFTLENBQUM7SUFDeEJTLE9BQU8sRUFBRTtNQUFFVCxJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQzNCVSxXQUFXLEVBQUU7TUFBRVYsSUFBSSxFQUFFLFFBQVE7TUFBRUksUUFBUSxFQUFFO0lBQUssQ0FBQztJQUMvQ08sT0FBTyxFQUFFO01BQUVYLElBQUksRUFBRTtJQUFTLENBQUM7SUFDM0JBLElBQUksRUFBRTtNQUFFQSxJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQ3hCWSxNQUFNLEVBQUU7TUFBRVosSUFBSSxFQUFFLE9BQU87TUFBRWEsS0FBSyxFQUFFO1FBQUViLElBQUksRUFBRTtNQUFTLENBQUM7TUFBRUksUUFBUSxFQUFFO0lBQUssQ0FBQztJQUNwRVUsSUFBSSxFQUFFO01BQUVkLElBQUksRUFBRSxPQUFPO01BQUVhLEtBQUssRUFBRTtRQUFFYixJQUFJLEVBQUU7TUFBUyxDQUFDO01BQUVJLFFBQVEsRUFBRTtJQUFLLENBQUM7SUFDbEVXLE1BQU0sRUFBRTtNQUFFZixJQUFJLEVBQUUsUUFBUTtNQUFFSSxRQUFRLEVBQUU7SUFBSyxDQUFDO0lBQzFDWSxXQUFXLEVBQUU7TUFBRWhCLElBQUksRUFBRSxRQUFRO01BQUVJLFFBQVEsRUFBRTtJQUFLLENBQUM7SUFDL0NhLFNBQVMsRUFBRTtNQUFFakIsSUFBSSxFQUFFLFFBQVE7TUFBRUksUUFBUSxFQUFFO0lBQUssQ0FBQztJQUM3Q2MsT0FBTyxFQUFFO01BQ1BsQixJQUFJLEVBQUUsUUFBUTtNQUNkQyxVQUFVLEVBQUU7UUFDVmtCLElBQUksRUFBRTtVQUFFLEdBQUdwQixXQUFXO1VBQUVLLFFBQVEsRUFBRTtRQUFLLENBQUM7UUFDeENnQixPQUFPLEVBQUU7VUFBRXBCLElBQUksRUFBRSxPQUFPO1VBQUVhLEtBQUssRUFBRWQsV0FBVztVQUFFSyxRQUFRLEVBQUU7UUFBSyxDQUFDO1FBQzlEaUIsWUFBWSxFQUFFO1VBQUUsR0FBR3RCLFdBQVc7VUFBRUssUUFBUSxFQUFFO1FBQUssQ0FBQztRQUNoRGtCLGVBQWUsRUFBRTtVQUFFdEIsSUFBSSxFQUFFLE9BQU87VUFBRWEsS0FBSyxFQUFFZCxXQUFXO1VBQUVLLFFBQVEsRUFBRTtRQUFLO01BQ3ZFLENBQUM7TUFDREUsb0JBQW9CLEVBQUUsS0FBSztNQUMzQkYsUUFBUSxFQUFFO0lBQ1osQ0FBQztJQUNEbUIsVUFBVSxFQUFFO01BQ1Z2QixJQUFJLEVBQUUsT0FBTztNQUNiYSxLQUFLLEVBQUU7UUFDTGIsSUFBSSxFQUFFLFFBQVE7UUFDZEMsVUFBVSxFQUFFO1VBQ1ZPLElBQUksRUFBRTtZQUFFUixJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3hCUyxPQUFPLEVBQUU7WUFBRVQsSUFBSSxFQUFFO1VBQVM7UUFDNUIsQ0FBQztRQUNESyxRQUFRLEVBQUUsQ0FBQyxNQUFNLEVBQUUsU0FBUztNQUM5QjtJQUNGLENBQUM7SUFDRG1CLE1BQU0sRUFBRTtNQUNOeEIsSUFBSSxFQUFFLFFBQVE7TUFDZEMsVUFBVSxFQUFFO1FBQ1Z3QixZQUFZLEVBQUU7VUFDWnpCLElBQUksRUFBRSxRQUFRO1VBQ2RDLFVBQVUsRUFBRTtZQUNWTyxJQUFJLEVBQUU7Y0FBRVIsSUFBSSxFQUFFO1lBQVMsQ0FBQztZQUN4QlMsT0FBTyxFQUFFO2NBQUVULElBQUksRUFBRTtZQUFTO1VBQzVCLENBQUM7VUFDREssUUFBUSxFQUFFLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQztVQUM3QkQsUUFBUSxFQUFFLElBQUk7VUFDZEUsb0JBQW9CLEVBQUU7UUFDeEIsQ0FBQztRQUNEb0IsT0FBTyxFQUFFO1VBQ1AxQixJQUFJLEVBQUUsT0FBTztVQUNiYSxLQUFLLEVBQUU7WUFDTGIsSUFBSSxFQUFFLFFBQVE7WUFDZEMsVUFBVSxFQUFFO2NBQ1ZPLElBQUksRUFBRTtnQkFBRVIsSUFBSSxFQUFFO2NBQVMsQ0FBQztjQUN4QlMsT0FBTyxFQUFFO2dCQUFFVCxJQUFJLEVBQUU7Y0FBUyxDQUFDO2NBQzNCMkIsUUFBUSxFQUFFO2dCQUFFM0IsSUFBSSxFQUFFO2NBQVM7WUFDN0IsQ0FBQztZQUNESyxRQUFRLEVBQUUsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFVBQVU7VUFDMUMsQ0FBQztVQUNERCxRQUFRLEVBQUU7UUFDWjtNQUNGLENBQUM7TUFDREUsb0JBQW9CLEVBQUU7SUFDeEIsQ0FBQztJQUNEc0IsVUFBVSxFQUFFO01BQ1Y1QixJQUFJLEVBQUUsUUFBUTtNQUNkQyxVQUFVLEVBQUU7UUFDVkMsSUFBSSxFQUFFO1VBQ0pGLElBQUksRUFBRTtRQUNSO01BQ0YsQ0FBQztNQUNESyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUM7TUFDbEJDLG9CQUFvQixFQUFFLEtBQUs7TUFDM0JGLFFBQVEsRUFBRTtJQUNaO0VBQ0YsQ0FBQztFQUNEQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFFBQVEsQ0FBQztFQUN4RUMsb0JBQW9CLEVBQUU7QUFDeEIsQ0FBQztBQUVELE1BQU11QixjQUFtRCxHQUFHO0VBQzFEN0IsSUFBSSxFQUFFLFFBQVE7RUFDZEMsVUFBVSxFQUFFO0lBQ1ZPLElBQUksRUFBRTtNQUFFUixJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQ3hCOEIsWUFBWSxFQUFFO01BQUU5QixJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQ2hDK0IsVUFBVSxFQUFFO01BQUUvQixJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQzlCZ0MsWUFBWSxFQUFFO01BQUVoQyxJQUFJLEVBQUU7SUFBUyxDQUFDO0lBQ2hDd0IsTUFBTSxFQUFFO01BQ054QixJQUFJLEVBQUUsT0FBTztNQUNiYSxLQUFLLEVBQUU7UUFDTGIsSUFBSSxFQUFFLFFBQVE7UUFDZEMsVUFBVSxFQUFFO1VBQ1ZnQyxTQUFTLEVBQUU7WUFBRWpDLElBQUksRUFBRTtVQUFTLENBQUM7VUFDN0JrQyxPQUFPLEVBQUU7WUFBRWxDLElBQUksRUFBRTtVQUFTLENBQUM7VUFDM0JtQyxjQUFjLEVBQUU7WUFBRW5DLElBQUksRUFBRTtVQUFVLENBQUM7VUFDbkNnQixXQUFXLEVBQUU7WUFBRWhCLElBQUksRUFBRTtVQUFTO1FBQ2hDLENBQUM7UUFDREssUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxhQUFhO01BQ3BFO0lBQ0Y7RUFDRixDQUFDO0VBQ0RBLFFBQVEsRUFBRSxDQUFDLE1BQU0sRUFBRSxjQUFjLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxRQUFRO0FBQzNFLENBQUM7QUFFRCxNQUFNK0IsaUJBQWlCLEdBQUd2QyxHQUFHLENBQUN3QyxPQUFPLENBQUM5QixjQUFjLENBQUM7QUFDckQsTUFBTStCLGlCQUFpQixHQUFHekMsR0FBRyxDQUFDd0MsT0FBTyxDQUFDUixjQUFjLENBQUM7O0FBRXJEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTVUsZ0JBQWdCLEdBQUlDLElBQWEsSUFBZ0M7RUFDNUUsSUFBSSxDQUFDSixpQkFBaUIsQ0FBQ0ksSUFBSSxDQUFDLEVBQUU7SUFDNUIsT0FBTztNQUFFQyxFQUFFLEVBQUUsS0FBSztNQUFFQyxLQUFLLEVBQUUsSUFBSUMsS0FBSyxDQUFDOUMsR0FBRyxDQUFDK0MsVUFBVSxDQUFDUixpQkFBaUIsQ0FBQ1MsTUFBTSxDQUFDO0lBQUUsQ0FBQztFQUNsRjtFQUNBO0VBQ0EsSUFBSUwsSUFBSSxDQUFDakIsVUFBVSxDQUFDdUIsU0FBUyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3ZDLElBQUksS0FBS2dDLElBQUksQ0FBQ3hDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtJQUM5RCxPQUFPO01BQ0x5QyxFQUFFLEVBQUUsS0FBSztNQUNUQyxLQUFLLEVBQUUsSUFBSUMsS0FBSyxDQUFFLHlCQUF3QkgsSUFBSSxDQUFDeEMsSUFBSyxtQ0FBa0M7SUFDeEYsQ0FBQztFQUNIO0VBQ0EsT0FBTztJQUNMeUMsRUFBRSxFQUFFLElBQUk7SUFDUk8sS0FBSyxFQUFFUjtFQUNULENBQUM7QUFDSCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQQVMsT0FBQSxDQUFBVixnQkFBQSxHQUFBQSxnQkFBQTtBQVFPLE1BQU1XLGdCQUFnQixHQUFJVixJQUFhLElBQWtDO0VBQzlFLElBQUksQ0FBQ0YsaUJBQWlCLENBQUNFLElBQUksQ0FBQyxFQUFFO0lBQzVCLE9BQU87TUFDTEMsRUFBRSxFQUFFLEtBQUs7TUFDVEMsS0FBSyxFQUFFLElBQUlDLEtBQUssQ0FBQzlDLEdBQUcsQ0FBQytDLFVBQVUsQ0FBQ04saUJBQWlCLENBQUNPLE1BQU0sQ0FBQztJQUMzRCxDQUFDO0VBQ0g7RUFDQSxPQUFPO0lBQ0xKLEVBQUUsRUFBRSxJQUFJO0lBQ1JPLEtBQUssRUFBRVI7RUFDVCxDQUFDO0FBQ0gsQ0FBQztBQUFDUyxPQUFBLENBQUFDLGdCQUFBLEdBQUFBLGdCQUFBIn0=