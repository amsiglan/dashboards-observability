"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _zeppelin_backend = require("./zeppelin_backend");

var _default_backend = require("./default_backend");

var _notebooks = require("../../../common/constants/notebooks");

/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
// Selects backend based on config
let BACKEND = new _default_backend.DefaultBackend();

if (_notebooks.NOTEBOOKS_SELECTED_BACKEND == 'ZEPPELIN') {
  BACKEND = new _zeppelin_backend.ZeppelinBackend();
}

var _default = BACKEND;
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIkJBQ0tFTkQiLCJEZWZhdWx0QmFja2VuZCIsIk5PVEVCT09LU19TRUxFQ1RFRF9CQUNLRU5EIiwiWmVwcGVsaW5CYWNrZW5kIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBS0E7O0FBQ0E7O0FBQ0E7O0FBUEE7QUFDQTtBQUNBO0FBQ0E7QUFNQTtBQUNBLElBQUlBLE9BQU8sR0FBRyxJQUFJQywrQkFBSixFQUFkOztBQUVBLElBQUlDLHlDQUE4QixVQUFsQyxFQUE4QztBQUM1Q0YsRUFBQUEsT0FBTyxHQUFHLElBQUlHLGlDQUFKLEVBQVY7QUFDRDs7ZUFFY0gsTyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IHsgWmVwcGVsaW5CYWNrZW5kIH0gZnJvbSAnLi96ZXBwZWxpbl9iYWNrZW5kJztcbmltcG9ydCB7IERlZmF1bHRCYWNrZW5kIH0gZnJvbSAnLi9kZWZhdWx0X2JhY2tlbmQnO1xuaW1wb3J0IHsgTk9URUJPT0tTX1NFTEVDVEVEX0JBQ0tFTkQgfSBmcm9tICcuLi8uLi8uLi9jb21tb24vY29uc3RhbnRzL25vdGVib29rcyc7XG5cbi8vIFNlbGVjdHMgYmFja2VuZCBiYXNlZCBvbiBjb25maWdcbmxldCBCQUNLRU5EID0gbmV3IERlZmF1bHRCYWNrZW5kKCk7XG5cbmlmIChOT1RFQk9PS1NfU0VMRUNURURfQkFDS0VORCA9PSAnWkVQUEVMSU4nKSB7XG4gIEJBQ0tFTkQgPSBuZXcgWmVwcGVsaW5CYWNrZW5kKCk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEJBQ0tFTkQ7XG4iXX0=